<!DOCTYPE html>
<html xmlns:wicket="http://www.w3.org/1999/xhtml" style="--col-count:4;" data-content-login="" data-static-fallback="">
<head>
<script>
/*<![CDATA[*/

const urlParams = new URLSearchParams(window.location.search);
const noScriptParam = urlParams.get('status');
if (noScriptParam && noScriptParam === 'no-script') {
window.location.href = window.location.href.split('?')[0];
}
window.startupTS = new Date().getTime();
document.querySelector('html').classList.add('withjs');
document.addEventListener('pageStartup', () => {
// IntersectionObserver check to only support new-ish browsers (we had some probs with older iOS browsers and animations)
if (('IntersectionObserver' in window) || ('IntersectionObserverEntry' in window) || ('intersectionRatio' in window.IntersectionObserverEntry.prototype)) {
document.querySelector('html').classList.add('ce-available');
}
});
const event = new CustomEvent('pageStartup', { bubbles: true, cancelable: true, detail: { source: 'index.html' } });
document.dispatchEvent(event);

/*]]>*/
</script>
<meta charset="utf-8" />
<title>WEB.DE - kostenlose E-Mail-Adresse, FreeMail & Nachrichten</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

<link rel="shortcut icon" type="image/x-icon" href="https://img.ui-portal.de/webde/favicon.ico"/>

<meta name="description" content="Sichere Kommunikation, aktuelle Nachrichten und nützliche Online-Services - alles an einem Ort. Einfach, kostenlos und zuverlässig."/>
<meta name="applicationVersion" content="12.43.5"/>
<meta name="robots" content="index, follow"/>
<meta name="google-adsense-account" content="sites-7654151434925350"/>
<link rel="canonical" href="https://web.de/"/>
<link rel="search" type="application/opensearchdescription+xml" href="https://img.ui-portal.de/search-int/osd/web/ff_webde_opensearch.xml" title="WEB.DE Suche"/>

<noscript>
<meta http-equiv="refresh" content="0;url=/?status=no-script" />
</noscript>

<style>
/*<![CDATA[*/
[data-part=logo]{height:40px;width:40px;display:block}[data-part=logo] svg{width:100%;height:100%}[data-pre-icon] svg{width:24px;height:24px}[data-layer],[data-layout-name=viewport]>:nth-child(n+4){display:none}[data-importance=iconTopper] svg,[aria-label=netid] svg{width:32px;height:32px}[data-component=login]>div:first-child [data-component=icon] svg{height:32px;width:auto}[data-layout-columns]{display:grid;grid-template-columns:repeat(auto-fill,300px)}[data-layout-name=viewport]>:first-child{grid-area:1/span 2}[data-component=slider] [data-wrapper]{overflow:hidden}[data-animation-type=fade] [data-wrapper]>div>*{position:absolute;opacity:0}[data-component=slider] [data-wrapper]>div {position: relative;}
/*]]>*/
</style>



<link rel="preload" as="style" href="https://js.ui-portal.de/homepage/res/live/1.90/webde/chunk-common.css">
<link rel="stylesheet" href="https://js.ui-portal.de/homepage/res/live/1.90/webde/chunk-common.css">





<script>
window.PageConfig = {
  "shopping" : false,
  "pageidentifier" : "homepage",
  "reco" : "optout",
  "box1Enabled" : true,
  "country" : "de",
  "webVitals" : {
    "page" : "HOMEPAGE",
    "url" : "https://web.de/rest/webvitals"
  },
  "maxCols" : 5,
  "adConnectorUrl" : "https://dl.web.de/uim/connector/live/v2",
  "stage" : "live",
  "tcf" : false,
  "site" : "hp",
  "vorteilswelt" : true,
  "cont_tcflayer" : "0",
  "brain" : {
    "prio" : "undefined"
  },
  "unitedFallback" : 100
};
</script>

<script>/*<![CDATA[*/
window.initialData = {
  "serviceResponse" : {
    "response" : {
      "requestUrl" : "https://united.uimserv.net/lt?prf%5Bspecial%5D=&nw=42&prf%5Btcf_pub%5D=,,&prf%5Blayoutclass%5D=b&prf%5Bdeviceclient%5D=browser&prf%5Btcf_pur%5D=,,&prf%5Bsysv%5D=&prf%5Bwi%5D=302520653&prf%5Boptout%5D=1&prf%5Bhid%5D=&prf%5Bnet%5D=&ac=1&prf%5Bsection%5D=homepage&prf%5Bvpw%5D=&prf%5Bcategorytype%5D=errorpage&prf%5Bnguserid%5D=&prf%5Bclv%5D=&uid_stable=0&wi=302520653&prf%5Buids%5D=0&prf%5Bportal%5D=webde&optout=1&ref=https://web.de&userid=&prf%5Bcl%5D=&prf%5Bweather_temp%5D=&prf%5Btcf_spe%5D=,,&prf%5Bweather_condition%5D=&prf%5Bbusterid%5D=7347404&prf%5Bbrandedbrowser%5D=&iframe=1&prf%5Bpos%5D=1&prf%5Baddefend%5D=1&prf%5Bpagev%5D=2&lt=portal(webde)category(homepage)section(homepage)tagid(initial)layoutclass(b)&prf%5Bcategory%5D=homepage&prf%5Btcf_pcp%5D=,,&prf%5Bexternal_uid%5D=&os=&browser=&prf%5Btagid%5D=initial&prf%5Bsys%5D=&external_uid=&wpt=h&prf%5Bdnt%5D=0&prf%5Bbrowser%5D=&prf%5Biframe%5D=1&prf%5Bdeviceclass%5D=&prf%5Bclktype%5D=&prf%5Bos%5D=",
      "requestHeaders" : {
        "User-Agent" : "curl/7.74.0"
      },
      "ad" : "<HTML><HEAD><TITLE><\/TITLE><\/HEAD><BODY topmargin=\"0\" leftmargin=\"0\" style=\"background-color:transparent;overflow:hidden;margin:0;padding:0;\"><\/BODY><\/HTML>"
    },
    "agent" : {
      "browserVersion" : "",
      "browser" : "",
      "osVersion" : "",
      "os" : ""
    },
    "_params" : {
      "ac" : "1",
      "browser" : "",
      "category" : "homepage",
      "external_uid" : "",
      "iframe" : "1",
      "layoutclass" : "b",
      "lt" : "portal(webde)category(homepage)section(homepage)tagid(initial)layoutclass(b)",
      "nguserid" : "",
      "nw" : "42",
      "optout" : "1",
      "os" : "",
      "portal" : "webde",
      "prf[addefend]" : "1",
      "prf[brandedbrowser]" : "",
      "prf[browser]" : "",
      "prf[busterid]" : "7347404",
      "prf[category]" : "homepage",
      "prf[categorytype]" : "errorpage",
      "prf[cl]" : "",
      "prf[clktype]" : "",
      "prf[clv]" : "",
      "prf[deviceclass]" : "",
      "prf[deviceclient]" : "browser",
      "prf[dnt]" : "0",
      "prf[external_uid]" : "",
      "prf[hid]" : "",
      "prf[iframe]" : "1",
      "prf[layoutclass]" : "b",
      "prf[net]" : "",
      "prf[nguserid]" : "",
      "prf[optout]" : "1",
      "prf[os]" : "",
      "prf[pagev]" : "2",
      "prf[portal]" : "webde",
      "prf[pos]" : "1",
      "prf[section]" : "homepage",
      "prf[special]" : "",
      "prf[sys]" : "",
      "prf[sysv]" : "",
      "prf[tagid]" : "initial",
      "prf[tcf_pcp]" : ",,",
      "prf[tcf_pub]" : ",,",
      "prf[tcf_pur]" : ",,",
      "prf[tcf_spe]" : ",,",
      "prf[uids]" : "0",
      "prf[vpw]" : "",
      "prf[weather_condition]" : "",
      "prf[weather_temp]" : "",
      "prf[wi]" : "302520653",
      "ref" : "https://web.de",
      "section" : "homepage",
      "uid_stable" : "0",
      "userid" : "",
      "wi" : "302520653",
      "wpt" : "h"
    }
  },
  "logins" : [ {
    "icon" : "email",
    "text" : "E-Mail",
    "loginUrl" : "https://login.web.de/login",
    "formHiddenParams" : {
      "loginFailedURL" : "https://web.de/logoutlounge/?status=login-failed",
      "loginErrorURL" : "https://web.de/?status=nologin",
      "server" : "https://freemail.web.de",
      "service" : "freemail",
      "statistics" : "kR8BWaubR5/vA1KhqEY3LOBuNIy/0UiyKfW8gXUbkE9ajaE5dqAorbuXCwUU2zxykOEv9JD/9AWh+zAJ//a2WMHWIInMjKb8hXoy+K0iQyeWYypnCpnWoUOpQvJbItZGvle7mgDbprFKgW+XoPP4IpcUuEqAWHDTB1pM3aH/wNA=",
      "successURL" : "https://bap.navigator.web.de/login"
    },
    "credentials" : [ {
      "input" : {
        "name" : "username",
        "placeholder" : "E-Mail-Adresse"
      },
      "link" : {
        "href" : "https://web.de/email/tarifvergleich/#.pc_page.homepage.index.loginbox.tarifvergleich",
        "text" : "Kostenlos registrieren!"
      }
    }, {
      "input" : {
        "name" : "password",
        "placeholder" : "Passwort"
      },
      "link" : {
        "href" : "https://passwort.web.de/",
        "text" : "Passwort vergessen?"
      }
    } ]
  }, {
    "icon" : "cloud",
    "text" : "Online-Speicher",
    "loginUrl" : "https://login.web.de/login",
    "formHiddenParams" : {
      "goto" : "nl_smartdrive",
      "loginFailedURL" : "https://web.de/online-speicher/login/?error=true",
      "loginErrorURL" : "https://status.web.de",
      "service" : "freemail",
      "statistics" : "mW7nxYShT5atP3HYXD1C0zWJ0if2bwIc_nCCdjXc1XvdkO5tPAlgI5aBhSVyxQdqq5o6uiVb2VRf8nUZzqO7MZSFHroM7-zUwivwtVFHKXrkbDte4tCFL5Dud44dACPUH1a3sgCmUGH2otLSN0cUDJVik2rH1IZHAN7w6xNd1pQVAE8kRAe3EopfDTq4Y3hJ",
      "successURL" : "https://bap.navigator.web.de/login"
    },
    "credentials" : [ {
      "input" : {
        "name" : "username",
        "placeholder" : "E-Mail-Adresse"
      },
      "link" : {
        "href" : "https://web.de/email/tarifvergleich/#.pc_page.homepage.index.loginbox.tarifvergleich",
        "text" : "Kostenlos registrieren!"
      }
    }, {
      "input" : {
        "name" : "password",
        "placeholder" : "Passwort"
      },
      "link" : {
        "href" : "https://passwort.web.de/",
        "text" : "Passwort vergessen?"
      }
    } ]
  }, {
    "icon" : "domain",
    "text" : "Domain",
    "loginUrl" : "https://login.web.de/login",
    "formHiddenParams" : {
      "goto" : "mdh",
      "loginFailedURL" : "https://web.de/logoutlounge/?status=login-failed",
      "loginErrorURL" : "https://web.de/?status=nologin",
      "service" : "freemail",
      "statistics" : "xNGbf2F5E-0aNjuYuM4HvHFcMs1cm219fuHLACxwXwIMsSvXYwcS5sQIXgWBQKldu1vW9LqQuCWFyUPnoZTJiFTVYYtq5P7lnuF5wHZSljDqeBEbsMlY_EWAyOq_0ksO_6W1_tHxVd8VbB-NV8imqXLXpgfPVN9icqCSRfWOKAQ=",
      "successURL" : "https://bap.navigator.web.de/login"
    },
    "credentials" : [ {
      "input" : {
        "name" : "username",
        "placeholder" : "E-Mail-Adresse"
      },
      "link" : {
        "href" : "https://web.de/email/tarifvergleich/#.pc_page.homepage.index.loginbox.tarifvergleich",
        "text" : "Kostenlos registrieren!"
      }
    }, {
      "input" : {
        "name" : "password",
        "placeholder" : "Passwort"
      },
      "link" : {
        "href" : "https://passwort.web.de/",
        "text" : "Passwort vergessen?"
      }
    } ]
  }, {
    "icon" : "webcent",
    "text" : "WEB.Cent",
    "loginUrl" : "https://login.web.de/login",
    "formHiddenParams" : {
      "loginFailedURL" : "https://vorteile.web.de/webcent/halogin/bad_password?goto=sammeln&isInterstitialLoginAndProcess=false&isStaticPageLogin=true",
      "loginErrorURL" : "https://vorteile.web.de/webcent/halogin/failure?goto=sammeln&isInterstitialLoginAndProcess=false&isStaticPageLogin=true",
      "partnerdata" : "goto=sammeln&isInterstitialLoginAndProcess=false&isStaticPageLogin=true",
      "service" : "cbkwebde",
      "statistics" : "SD7VNiwmYEo762DeZQs2mzIcOW6-qGafDQ5ZfcUR43mehdbFCNcgRQI0kqiS8VDKpAe3Xe-jiapq8qDaL0j72ZJK8esuCPEPP49U2Sp86Od2ZbcpT5YpqCNvkhppdnm9sG0RRqT_VsLRPMdXgX-uy3Adk_m984-Yz7x-Y9bbvHFE83wmGJBtslOxYJRkIKFe",
      "successURL" : "https://vorteile.web.de/webcent/halogin/success?goto=sammeln&isInterstitialLoginAndProcess=false&isStaticPageLogin=true"
    },
    "credentials" : [ {
      "input" : {
        "name" : "username",
        "placeholder" : "E-Mail-Adresse"
      },
      "link" : {
        "href" : "https://web.de/email/tarifvergleich/#.pc_page.homepage.index.loginbox.tarifvergleich",
        "text" : "Kostenlos registrieren!"
      }
    }, {
      "input" : {
        "name" : "password",
        "placeholder" : "Passwort"
      },
      "link" : {
        "href" : "https://passwort.web.de/",
        "text" : "Passwort vergessen?"
      }
    } ]
  }, {
    "icon" : "customer-center",
    "text" : "Kundencenter",
    "loginUrl" : "https://login.web.de/login",
    "formHiddenParams" : {
      "loginErrorURL" : "https://mein.web.de/?errorCodes=7100",
      "statistics" : "MHp-fN8RYftCpmxpMkV0TQA0VsMKPnsFRsDPgYq1JaLZb07lK71HrOtvNrlsAZrJpoNlz9w7kaQ7EvT_CHIFZ_KIFgFVkvPa0sOx_AiK-03G07jvOZVFWiOXVfC85vXK5SmLyyIewiG_0wNoqqNVob8DuP8oaEh6gjUV79MG1LvdvTibl6FdIY0ifJqPKyyu",
      "goto" : "csc_ha",
      "loginFailedURL" : "https://mein.web.de/?errorCodes=7002",
      "server" : "https://produkte.web.de",
      "successURL" : "https://bap.navigator.web.de/login",
      "service" : "freemail"
    },
    "credentials" : [ {
      "input" : {
        "name" : "username",
        "placeholder" : "E-Mail-Adresse"
      },
      "link" : {
        "href" : "https://web.de/email/tarifvergleich/#.pc_page.homepage.index.loginbox.tarifvergleich",
        "text" : "Kostenlos registrieren!"
      }
    }, {
      "input" : {
        "name" : "password",
        "placeholder" : "Passwort"
      },
      "link" : {
        "href" : "https://passwort.web.de/",
        "text" : "Passwort vergessen?"
      }
    } ]
  } ],
  "bentoFooter" : [ {
    "href" : "https://passwort.web.de/",
    "text" : "Passwort vergessen"
  }, {
    "href" : "https://web.de/datenschutz/",
    "text" : "Datenschutz"
  }, {
    "href" : "https://hilfe.web.de/",
    "text" : "Hilfe"
  }, {
    "href" : "https://web.de/netid/",
    "text" : "netID mit WEB.DE"
  } ],
  "searchbar" : {
    "suggestContainerId" : "suggestions",
    "trackParams" : {
      "layer" : "wbl_mono_sf",
      "suggest" : "HP_sg",
      "default" : "HP"
    },
    "suggestAPI" : "https://web.de/msuggest/v1?brand=webde&count=10&device=tablet&hl=on&q=",
    "searchURL" : "https://suche.web.de/web/result"
  }
};
/*]]>*/
</script>

<script>/*<![CDATA[*/
window.tr_config = {events: {userAction: [{sel: "[data-component='burger'] [data-layer] [data-close-button]"},{sel: "[data-component='burger'] > label"},{sel: "[data-component='burger'] ul li div[data-component='icon']"},{sel: "[data-component='navigation'] > ul li a"},{sel: "[data-component='burger'] [data-part='scrollable-container'] nav ul li a p"},{sel: "form[data-form-login] button[type='submit']"},{sel: "[data-component='login'] a[data-component='button']"},{sel: "[data-component='weather'] a"},{sel: "section[data-footer-section='2'] a"}],expose: [{sel: "[data-component='burger'] [data-layer]"},{sel: "section[data-footer-section='5']"},{sel: "section [data-component='login'][data-grid-row]"}]},replacements: {componentPath: ['component', 'componentSub']},viewEventLoad: ['layerOpened'], uuidEvents: ['layerOpened']};

utag_data = window.utag_data || {};
utag_data["agof"]="264";
utag_data["appEnvironment"]="standalone";
utag_data["applicationArea"]="homepage";
utag_data["brain.prefix"]="homepage";
utag_data["brand"]="webde";
utag_data["contentCountry"]="DE";
utag_data["contentName"]="404";
utag_data["pageType"]="error";
utag_data["softwareName"]="hpll";
utag_data["softwareVersion"]="12.43.5";

/*]]>*/
</script>

<script src="https://s.uicdn.com/t/prod/iq/mam/purple/daq.js"></script>



<script src="https://dl.web.de/tcf/live/v1/js/tcf-api.js"></script>


<script src="https://img.ui-portal.de/pos-cdn/tracklib/4.7.3/tracklib.min.js"></script>



<script src="https://js.ui-portal.de/homepage/res/live/1.90/webde/js/piNctTracking.js"></script>



<script src="https://dl.web.de/uim/connector/live/v2/service.min.js"></script>

<script>/*<![CDATA[*/
if (!window.AdService) {
    window.AdService = []
}
const paramsObject = {
    'wi': window.initialData.serviceResponse?._params?.wi,
    'section': window.initialData.serviceResponse?._params?.section,
    'portal': window.initialData.serviceResponse?._params?.portal,
    'category': window.initialData.serviceResponse?._params?.category,
    'layoutclass': window.initialData.serviceResponse?._params?.layoutclass,
    'consentlevel': window.initialData.serviceResponse?._params?.['prf[consentlevel]'],
    'weather_condition': window.initialData.serviceResponse?._params?.['prf[weather_condition]'],
    'weather_temp': window.initialData.serviceResponse?._params?.['prf[weather_temp]'],
    'hpeventid': window.initialData.serviceResponse?._params?.['prf[busterid]'],
    'addefend': window.initialData.serviceResponse?._params?.['prf[addefend]'],
    'special': window.PageConfig?.sitespect?.special
}
window.AdService.push(() => {
    window.AdService.setParam(paramsObject);
});
/*]]>*/</script>

<script src="https://dl.web.de/uim/live/config_homepage.js" defer=""></script>



<link rel="modulepreload" as="script" href="https://js.ui-portal.de/homepage/res/live/1.90/webde/page.bundle.js">

<link rel="modulepreload" as="script" href="https://js.ui-portal.de/homepage/res/live/1.90/webde/chunk-vendors.bundle.js">



</head>
<body data-col-count="4">
<div data-available></div>
<div id="app" tabindex="0">
<hp-app>
<Page v-slot="{ adHandler, contentDataStore, brand, bentoData }">
<div class="main" :data-fallback="adHandler.fallback" :data-variant="adHandler.adVariant">

<div class="main-content">
<div data-service-slot="notification"></div>



<div data-component="notification" data-notification-type="error-light">
<hp-icon data-pre-icon="" type="failure"></hp-icon>

<div data-text>
<strong>Seite nicht gefunden</strong>
Die gewünschte Seite wurde leider nicht gefunden.<br>Wählen Sie bitte einen anderen Beitrag aus unserem vielfältigen Angebot.
</div>
<div data-buttons="">
<a data-component="button" data-importance="primary" href="https://web.de/">Zurück zur Homepage</a>
</div>
</div>








<hp-header>
<header data-component="header">
<div data-wrapper>

<a data-part="logo" href="https://web.de/">
<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 56 56">
<path fill="#FFD800" d="M49 56H7c-3.85 0-7-3.15-7-7V7c0-3.85 3.15-7 7-7h42c3.85 0 7 3.15 7 7v42c0 3.85-3.15 7-7 7z"></path>
<path fill="#333333" d="M12.628 17.196c.45.166 1.048-.134 1.481-.211.43-.075 2.19-.47 1.857-.069-.187.226-.67.227-1.1.353-.597.176-1.555.275-1.592 1.043-.085 1.827 2.755.612 3.587.315 2.255-.785 4.84-.92 7.122-1.301 2.532-.421 5.135-.46 7.691-.558 2.69-.103 5.584-.216 8.227.157.704.099 1.37.177 2.086.252.62.064 1.928.633 2.48.372.501-.237.274-.83.533-1.133.373-.435 1.108-.36.597-1.29-.389-.708-1.808-.938-2.542-.794-.073-.447.269-.249.359-.481.13-.335.13-.852-.088-1.224-.394-.677-2.266-.917-2.267-.916-4.491-.723-12.572-1.503-21.173-.5-1.427.167-3.931.345-5.393.937-.647.262-.637.268-.717.692-.077.603.213 1.306.938 1.156 1.389-.286 3.843-.683 4.546-.862 3.469-.883 15.015-.711 16.502-.358.919.196 5.968.362 6.089 1.286-11.782-.488-16.28-.483-26.859.774-.884.146-1.415.339-2.112.575-.859.289-1.44 1.346-.252 1.785z"></path>
<path fill="#333333" d="M28.208 9.892c.412.036 3.667.133 3.854-1.14.106-.722-.608-1.894-.813-2.106-.27-.223-.865 1.722-1.015-.191-.024-.312-.104-.795-.251-1.09-.074-.148-.165-.256-.275-.256a.388.388 0 0 0-.18.062c-.094.061-.228.259-.295.425-.184.454-.265 2.209-.72 2.238-.495.032-.48-1.124-.414-1.46.011-.055-.001-.068-.023-.063-.047.013-.062.022-.1.035-.297.114-.636.459-.661.484-.466.478-1.096 1.725-.778 2.299.331.593 1.323.732 1.671.763zM50.887 34.98c-.035-.249-.108-.402-.277-.631-.613-.839-3.495-1.401-3.496-1.391-1.447-.316-3.114-.588-4.975-.815.265-1.258-.012-3.579-.019-4.386.037-1.441.007-5.166-.102-6.108-.083-.885-.201-1.272-.686-2.004-.348-.523-.455-1.034-1.257-.953-.73.073-.999 1.086-.874 1.702l.314 1.253c.131.259.485 8.386.405 9.094.007.343-.025.785-.035 1.159-1.897-.18-3.96-.319-6.169-.416l.087-.069c1.057-.822.691-1.914.514-3.104-.241-1.905-.057-7.311-.284-7.962-.154-.51-.588-.804-.966-1.193-.466-.48-1.051-.627-1.588-.076-.527.478.132 7.304.169 10.302.048.628-.092 1.415.158 2.022-.204-.008-5.628-.121-6.084-.113.006-.106-.065-.241-.116-.344-.136-.275-.328-.917-.383-1.217a12.788 12.788 0 0 1-.187-1.729c-.041-1.24.074-5.076.212-6.08.155-1.11.746-3.068-1.179-2.637-.208.047-1.228.173-1.501.388-.317.249-.286.873-.298 1.218-.045 1.31-.19 5.438-.182 6.43.01.833.159 1.905.464 2.718.186.494.737.986 1.313 1.297-1.059.029-2.079.063-2.441.083-1.788.1-3.159.199-4.495.33l-.017-.064c-.224-.69.098-3.538.718-8.879.15-1.288-.077-1.339-.861-2.065-.45-.417-.831-.698-1.613-.071-.496.398-.367.909-.452 1.483-.297 2.003-.73 5.149-.914 7.188-.052.563.027 1.851.171 2.632.013.037.008.078.026.118-.776.104-1.557.218-2.438.353-2.146.333-4.043.415-5.332.993-.792.357-.837.475-1.024.764a.752.752 0 0 0-.099.341c-.002.022.016.307.038.391a1.056 1.056 0 0 0 .715.76c.098.031.695.081.758.087 1.44.145 2.233-.205 3.641-.76 6.975-2.783 26.934-1.94 31.33-1.109 1.909.38 4.856.778 6.683 1.825.298.163.577.282.832.359.128.039.251.058.364.085.28.066.578.006.628-.004.1-.019.197-.048.285-.086.177-.075.32-.184.388-.316.049-.095.11-.278.139-.429a1.518 1.518 0 0 0-.008-.364z"></path>
<path fill="#333333" d="M9.143 40.979H7.29l1.632 8.332h2.144l1.247-5.64 1.259 5.64h2.144l1.713-8.332h-1.736l-1.049 6.375-1.364-6.375h-1.806l-1.387 6.351-.944-6.351zm14.609 0h-5.209v8.332h5.326v-1.399h-3.566v-2.074h3.042V44.44h-3.042v-2.063h3.45v-1.398h-.001zm1.485 0v8.332h3.1c1.958 0 2.89-.932 2.89-2.331 0-1.783-1.573-1.981-1.573-1.981s1.119-.478 1.119-1.865c0-1.399-.897-2.156-2.75-2.156h-2.786v.001zm1.76 3.508v-2.203h.583c1.037 0 1.457.349 1.457 1.084 0 .746-.42 1.119-1.282 1.119h-.758zm0 3.52v-2.249h1.072c.897 0 1.387.35 1.387 1.095 0 .746-.454 1.154-1.492 1.154h-.967zm6.258 1.421c.536 0 .909-.373.909-.897 0-.536-.373-.862-.886-.862-.536 0-.921.338-.921.886.001.489.304.873.898.873zm2.419-8.449v8.332h2.074c2.867 0 4.335-1.631 4.335-4.242 0-2.552-1.294-4.091-4.16-4.091h-2.249v.001zm1.76 6.934v-5.536h.478c1.608 0 2.389.956 2.389 2.808 0 1.841-.757 2.727-2.377 2.727h-.49v.001zm11.18-6.934h-5.209v8.332h5.326v-1.399h-3.566v-2.074h3.042V44.44h-3.042v-2.063h3.449v-1.398z"></path>
</svg>
</a>


<hp-searchbar v-slot="{ clearInput, searchbarInput, setSuggestResponse, setSuggestIndex, buttonImportance, searchSubmit }">
<form method="get" novalidate="novalidate" action="https://suche.web.de/web/result" autocomplete="off">
<input type="hidden" name="origin" value="HP"/>
<label data-accessibility :for="searchbarInput.htmlId">
<span></span>
</label>
<hp-input v-model="searchbarInput" @update-suggest-response="setSuggestResponse" @clear-input-data="clearInput" @suggest-index="setSuggestIndex">
</hp-input>
<hp-button @click="searchSubmit($event)" :data-importance="buttonImportance" data-component="button" data-type="icon" data-size="l" type="submit">
<hp-icon type="search"></hp-icon>
</hp-button>
</form>
</hp-searchbar>


<div data-grid-row="" data-help-area="">
<a data-component="button" data-importance="iconTopper" href="https://hilfe.web.de/#.homepage_header-button">
<div data-component="icon">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
<path d="M16.19,3c-7.18,0-13,5.82-13,13s5.82,13,13,13,13-5.82,13-13S23.37,3,16.19,3Zm-.33,20.46c-.99,0-1.5-.65-1.5-1.5,0-.93,.63-1.5,1.56-1.5,.85,0,1.48,.55,1.48,1.46s-.63,1.54-1.54,1.54Zm1.3-5.59v.83h-2.59v-.85c0-3.24,2.69-3.5,2.69-5.41,0-.81-.55-1.28-1.54-1.28-1.7,0-2.67,.65-2.67,.65l-.41-1.99s1.22-.89,3.3-.89c2.61,0,3.99,1.26,3.99,3.28,0,3.06-2.77,2.82-2.77,5.67Z"/>
</svg>
</div>
Hilfe
</a>
</div>
<div data-grid-row="" data-login-area="">
<a data-component="button" data-hidden-in="1col" data-importance="ghost" href="https://web.de/email/tarifvergleich/#.pc_page.homepage.index.header_account.tarifvergleich">
Mail-Account anlegen
</a>
</div>


</div>
<hp-navigation data-component="navigation" :brand="brand" >

<hp-burger data-component="burger" v-slot="{ setPaddingTop, close }">
<input type="checkbox" data-hidden="true" id="burgerMenuPanelBottom"/>
<label @click="setPaddingTop" for="burgerMenuPanelBottom">
<span></span>
<span><div></div></span>
<span></span>
</label>
<div data-layer data-tr-component-path="burger-layer">
<div data-part="scrollable-container">
<div data-part="logo">

<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 56 56">
<path fill=#FFD800 d="M49 56H7c-3.85 0-7-3.15-7-7V7c0-3.85 3.15-7 7-7h42c3.85 0 7 3.15 7 7v42c0 3.85-3.15 7-7 7z"/>
<path fill=#333333 d="M12.628 17.196c.45.166 1.048-.134 1.481-.211.43-.075 2.19-.47 1.857-.069-.187.226-.67.227-1.1.353-.597.176-1.555.275-1.592 1.043-.085 1.827 2.755.612 3.587.315 2.255-.785 4.84-.92 7.122-1.301 2.532-.421 5.135-.46 7.691-.558 2.69-.103 5.584-.216 8.227.157.704.099 1.37.177 2.086.252.62.064 1.928.633 2.48.372.501-.237.274-.83.533-1.133.373-.435 1.108-.36.597-1.29-.389-.708-1.808-.938-2.542-.794-.073-.447.269-.249.359-.481.13-.335.13-.852-.088-1.224-.394-.677-2.266-.917-2.267-.916-4.491-.723-12.572-1.503-21.173-.5-1.427.167-3.931.345-5.393.937-.647.262-.637.268-.717.692-.077.603.213 1.306.938 1.156 1.389-.286 3.843-.683 4.546-.862 3.469-.883 15.015-.711 16.502-.358.919.196 5.968.362 6.089 1.286-11.782-.488-16.28-.483-26.859.774-.884.146-1.415.339-2.112.575-.859.289-1.44 1.346-.252 1.785z"/>
<path fill=#333333 d="M28.208 9.892c.412.036 3.667.133 3.854-1.14.106-.722-.608-1.894-.813-2.106-.27-.223-.865 1.722-1.015-.191-.024-.312-.104-.795-.251-1.09-.074-.148-.165-.256-.275-.256a.388.388 0 0 0-.18.062c-.094.061-.228.259-.295.425-.184.454-.265 2.209-.72 2.238-.495.032-.48-1.124-.414-1.46.011-.055-.001-.068-.023-.063-.047.013-.062.022-.1.035-.297.114-.636.459-.661.484-.466.478-1.096 1.725-.778 2.299.331.593 1.323.732 1.671.763zM50.887 34.98c-.035-.249-.108-.402-.277-.631-.613-.839-3.495-1.401-3.496-1.391-1.447-.316-3.114-.588-4.975-.815.265-1.258-.012-3.579-.019-4.386.037-1.441.007-5.166-.102-6.108-.083-.885-.201-1.272-.686-2.004-.348-.523-.455-1.034-1.257-.953-.73.073-.999 1.086-.874 1.702l.314 1.253c.131.259.485 8.386.405 9.094.007.343-.025.785-.035 1.159-1.897-.18-3.96-.319-6.169-.416l.087-.069c1.057-.822.691-1.914.514-3.104-.241-1.905-.057-7.311-.284-7.962-.154-.51-.588-.804-.966-1.193-.466-.48-1.051-.627-1.588-.076-.527.478.132 7.304.169 10.302.048.628-.092 1.415.158 2.022-.204-.008-5.628-.121-6.084-.113.006-.106-.065-.241-.116-.344-.136-.275-.328-.917-.383-1.217a12.788 12.788 0 0 1-.187-1.729c-.041-1.24.074-5.076.212-6.08.155-1.11.746-3.068-1.179-2.637-.208.047-1.228.173-1.501.388-.317.249-.286.873-.298 1.218-.045 1.31-.19 5.438-.182 6.43.01.833.159 1.905.464 2.718.186.494.737.986 1.313 1.297-1.059.029-2.079.063-2.441.083-1.788.1-3.159.199-4.495.33l-.017-.064c-.224-.69.098-3.538.718-8.879.15-1.288-.077-1.339-.861-2.065-.45-.417-.831-.698-1.613-.071-.496.398-.367.909-.452 1.483-.297 2.003-.73 5.149-.914 7.188-.052.563.027 1.851.171 2.632.013.037.008.078.026.118-.776.104-1.557.218-2.438.353-2.146.333-4.043.415-5.332.993-.792.357-.837.475-1.024.764a.752.752 0 0 0-.099.341c-.002.022.016.307.038.391a1.056 1.056 0 0 0 .715.76c.098.031.695.081.758.087 1.44.145 2.233-.205 3.641-.76 6.975-2.783 26.934-1.94 31.33-1.109 1.909.38 4.856.778 6.683 1.825.298.163.577.282.832.359.128.039.251.058.364.085.28.066.578.006.628-.004.1-.019.197-.048.285-.086.177-.075.32-.184.388-.316.049-.095.11-.278.139-.429a1.518 1.518 0 0 0-.008-.364z"/>
<path fill=#333333 d="M9.143 40.979H7.29l1.632 8.332h2.144l1.247-5.64 1.259 5.64h2.144l1.713-8.332h-1.736l-1.049 6.375-1.364-6.375h-1.806l-1.387 6.351-.944-6.351zm14.609 0h-5.209v8.332h5.326v-1.399h-3.566v-2.074h3.042V44.44h-3.042v-2.063h3.45v-1.398h-.001zm1.485 0v8.332h3.1c1.958 0 2.89-.932 2.89-2.331 0-1.783-1.573-1.981-1.573-1.981s1.119-.478 1.119-1.865c0-1.399-.897-2.156-2.75-2.156h-2.786v.001zm1.76 3.508v-2.203h.583c1.037 0 1.457.349 1.457 1.084 0 .746-.42 1.119-1.282 1.119h-.758zm0 3.52v-2.249h1.072c.897 0 1.387.35 1.387 1.095 0 .746-.454 1.154-1.492 1.154h-.967zm6.258 1.421c.536 0 .909-.373.909-.897 0-.536-.373-.862-.886-.862-.536 0-.921.338-.921.886.001.489.304.873.898.873zm2.419-8.449v8.332h2.074c2.867 0 4.335-1.631 4.335-4.242 0-2.552-1.294-4.091-4.16-4.091h-2.249v.001zm1.76 6.934v-5.536h.478c1.608 0 2.389.956 2.389 2.808 0 1.841-.757 2.727-2.377 2.727h-.49v.001zm11.18-6.934h-5.209v8.332h5.326v-1.399h-3.566v-2.074h3.042V44.44h-3.042v-2.063h3.449v-1.398z"/>
</svg>

</div>
<div data-part="close-button">
<label data-close-button="" data-tr-component-path="close-button" for="burgerMenuPanelBottom">
<span></span>
<span></span>
</label>
</div>
<div data-part="content">
<header>Alle Inhalte</header>
<nav>
<ul>

<li data-component="TreeList" >
<a href="https://produkte.web.de/apps/mail/#.pc_page.homepage.mobil.nav.registrierung">
<p>App herunterladen &amp; registrieren</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://www.mail-and-media.com/jobs.html">
<p>Jobs bei WEB.DE</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/email/#.pc_page.homepage.mobil.nav.email">
<p>E-Mail</p>
<span data-arrow-down="">
<div data-component="icon" data-tr-event-type="userAction">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
</a>
<ul>


<li data-component="TreeList" >
<a href="https://web.de/email/#.pc_page.homepage.mobil.nav.freemail">
<p>FreeMail</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/email/neue-email-adresse/#.pc_page.homepage.mobil.nav.freemail_neue-email-adresse">
<p>E-Mail-Adresse erstellen</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://produkte.web.de/premium/?mc=03961172">
<p>WEB.DE Club</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://produkte.web.de/apps/mail/#.hp.int.nav.apps">
<p>Mail App</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://produkte.web.de/homepage-mail/persoenliche-domains/e-mail-adressen-anlegen/?mc=01993544">
<p>Wunsch-Mail-Adresse</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/netid/#.pc_page.homepage.mobil.nav.netid">
<p>netID</p>

</a>

</li>


</ul>
</li>

<li data-component="TreeList" >
<a href="https://web.de/online-speicher/#.pc_page.homepage.mobil.nav.online-speicher">
<p>Cloud</p>
<span data-arrow-down="">
<div data-component="icon" data-tr-event-type="userAction">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
</a>
<ul>


<li data-component="TreeList" >
<a href="https://produkte.web.de/onlinespeicher_erweitern/?mc=03961165">
<p>Cloud-Speicher erweitern</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://produkte.web.de/apps/cloud/#.hp_mobile.int.nav.apps">
<p>Cloud App</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/online-speicher/windows/#.pc_page.homepage.mobil.nav.online-speicher">
<p>Cloud für PC</p>

</a>

</li>


</ul>
</li>

<li data-component="TreeList" >
<a href="https://web.de/handy/?mc=05503703">
<p>Mobilfunk &amp; DSL</p>
<span data-arrow-down="">
<div data-component="icon" data-tr-event-type="userAction">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
</a>
<ul>


<li data-component="TreeList" >
<a href="https://web.de/allnet/tarife/handy/?mc=05503748">
<p>All-Net-Tarife mit Smartphone</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/allnet/ratgeber/#mc=05503749">
<p>All-Net Ratgeber</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/handy/?mc=05503703">
<p>Handytarif-Vergleich</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/dsl/?mc=06000000">
<p>DSL Vergleich</p>

</a>

</li>


</ul>
</li>

<li data-component="TreeList" >
<a href="https://vorteile.web.de/webcent/#.hp_mobile.int.nav.webcent  ">
<p>WEB.Cent Cashback</p>
<span data-arrow-down="">
<div data-component="icon" data-tr-event-type="userAction">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
</a>
<ul>


<li data-component="TreeList" >
<a href="https://vorteile.web.de/webcent/sammeln/#.hp_mobile.int.nav.webcent  ">
<p>Cashback Sammeln</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://vorteile.web.de/webcent/sammeln/kategorien/#.hp_mobile.int.nav.webcent">
<p>Shop Kategorien</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://vorteile.web.de/webcent/sammeln/shops/browse/#.hp_mobile.int.nav.webcent">
<p>Shops A-Z</p>

</a>

</li>


</ul>
</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/">
<p>News</p>
<span data-arrow-down="">
<div data-component="icon" data-tr-event-type="userAction">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
</a>
<ul>


<li data-component="TreeList" >
<a href="https://web.de/magazine/thema/">
<p>Alle Themen von A-Z</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/regio/">
<p>Regionales</p>
<span data-arrow-down="">
<div data-component="icon" data-tr-event-type="userAction">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
</a>
<ul>


<li data-component="TreeList" >
<a href="https://web.de/magazine/regio/baden-wuerttemberg/">
<p>Baden-Württemberg</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/regio/bayern/">
<p>Bayern</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/regio/berlin/">
<p>Berlin</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/regio/brandenburg/">
<p>Brandenburg</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/regio/bremen/">
<p>Bremen</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/regio/hamburg/">
<p>Hamburg</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/regio/hessen/">
<p>Hessen</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/regio/mecklenburg-vorpommern/">
<p>Mecklenburg-Vorpommern</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/regio/niedersachsen/">
<p>Niedersachsen</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/regio/nordrhein-westfalen/">
<p>Nordrhein-Westfalen</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/regio/rheinland-pfalz/">
<p>Rheinland-Pfalz</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/regio/saarland/">
<p>Saarland</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/regio/sachsen/">
<p>Sachsen</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/regio/sachsen-anhalt/">
<p>Sachsen-Anhalt</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/regio/schleswig-holstein/">
<p>Schleswig-Holstein</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/regio/thueringen/">
<p>Thüringen</p>

</a>

</li>


</ul>
</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/politik/">
<p>Politik</p>
<span data-arrow-down="">
<div data-component="icon" data-tr-event-type="userAction">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
</a>
<ul>


<li data-component="TreeList" >
<a href="https://web.de/magazine/politik/wahlen/bundestagswahl/">
<p>Bundestagswahl 2025</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/politik/politische-talkshows/">
<p>Politische Talkshows</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/politik/krieg-in-syrien/">
<p>Umbruch in Syrien</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/politik/russland-krieg-ukraine/">
<p>Krieg gegen die Ukraine</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/politik/nahostkonflikt/">
<p>Krieg in Nahost</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/politik/us-politik/">
<p>US-Politik</p>

</a>

</li>


</ul>
</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/wirtschaft/">
<p>Wirtschaft</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/panorama/">
<p>Panorama</p>
<span data-arrow-down="">
<div data-component="icon" data-tr-event-type="userAction">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
</a>
<ul>


<li data-component="TreeList" >
<a href="https://web.de/magazine/panorama/thema/">
<p>Panorama von A-Z</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/panorama/lotto/">
<p>Lottozahlen</p>

</a>

</li>


</ul>
</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/unterhaltung/">
<p>Unterhaltung</p>
<span data-arrow-down="">
<div data-component="icon" data-tr-event-type="userAction">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
</a>
<ul>


<li data-component="TreeList" >
<a href="https://web.de/magazine/unterhaltung/stars/">
<p>Stars</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/unterhaltung/adel/">
<p>Adel</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/unterhaltung/tv-shows/">
<p>TV-Shows</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/unterhaltung/tv-shows/germanys-next-topmodel/">
<p>GNTM</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/unterhaltung/tv-shows/lets-dance/">
<p>Let&#039;s Dance</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/unterhaltung/tv-shows/wwm/">
<p>Wer wird Millionär?</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/unterhaltung/tv-shows/bares-fuer-rares/">
<p>Bares für Rares im ZDF</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/unterhaltung/filme-serien-kino/">
<p>Filme und Serien</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/unterhaltung/comic/">
<p>Comics</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/unterhaltung/musik/">
<p>Musik</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/unterhaltung/musik/schlager/">
<p>Schlager</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/unterhaltung/lifestyle/">
<p>Lifestyle</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/unterhaltung/gaming/">
<p>Gaming</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/unterhaltung/internet/">
<p>Internet</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/unterhaltung/kultur/">
<p>Kultur</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/unterhaltung/thema/quiz">
<p>Quiz </p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/services/partnersuche/">
<p>Partnersuche</p>

</a>

</li>


</ul>
</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/sport/">
<p>Sport</p>
<span data-arrow-down="">
<div data-component="icon" data-tr-event-type="userAction">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
</a>
<ul>


<li data-component="TreeList" >
<a href="https://web.de/magazine/sport/fussball/">
<p>Fußball</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/sport/fussball/bundesliga/">
<p>Bundesliga</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/sport/fussball/2-liga/">
<p>2. Bundesliga</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/sport/fussball/dfb-pokal/">
<p>DFB-Pokal</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/sport/fussball/champions-league/">
<p>Champions League</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/sport/tennis/">
<p>Tennis</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/sport/formel-1/">
<p>Formel 1</p>

</a>

</li>


</ul>
</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/ratgeber/">
<p>Ratgeber</p>
<span data-arrow-down="">
<div data-component="icon" data-tr-event-type="userAction">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
</a>
<ul>


<li data-component="TreeList" >
<a href="https://web.de/magazine/gesundheit/">
<p>Gesundheit</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/ratgeber/essen-trinken/">
<p>Essen &amp; Trinken</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/auto/">
<p>Auto &amp; Mobilität</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/digital/">
<p>Digital</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/ratgeber/finanzen-verbraucher/">
<p>Finanzen &amp; Verbraucher</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/reise/">
<p>Reise</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/ratgeber/beauty-lifestyle/">
<p>Beauty &amp; Lifestyle</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/ratgeber/kind-familie/">
<p>Kind &amp; Familie</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/liebe-partnerschaft/">
<p>Liebe &amp; Partnerschaft</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/ratgeber/job-gehalt/">
<p>Job &amp; Gehalt</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/ratgeber/haus-garten/">
<p>Haus &amp; Garten</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/ratgeber/haustiere/">
<p>Haustiere</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/ratgeber/utopia/">
<p>Utopia</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/partner/smartphones/">
<p>Smartphones</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/partner/webcent/">
<p>Cashback</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/partner/haftpflichtversicherung/">
<p>Haftpflichtversicherung</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/partner/webcent_2/">
<p>Cashback auf Reisen</p>

</a>

</li>


</ul>
</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/wissen/">
<p>Wissen</p>
<span data-arrow-down="">
<div data-component="icon" data-tr-event-type="userAction">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
</a>
<ul>


<li data-component="TreeList" >
<a href="https://web.de/magazine/wissen/klima/">
<p>Klima - News und Hintergründe</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/wissen/psychologie/">
<p>Psychologie</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/wissen/geschichte/">
<p>Geschichte</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/wissen/natur-umwelt/">
<p>Natur &amp; Umwelt</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/wissen/tiere/">
<p>Tiere</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/wissen/wissenschaft-technik/">
<p>Wissenschaft &amp; Technik</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/wissen/weltraum/">
<p>Weltraum</p>

</a>

</li>


</ul>
</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/gesundheit/">
<p>Gesundheit</p>
<span data-arrow-down="">
<div data-component="icon" data-tr-event-type="userAction">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
</a>
<ul>


<li data-component="TreeList" >
<a href="https://web.de/magazine/gesundheit/abnehmen/">
<p>Abnehmen</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/gesundheit/hausmittel/">
<p>Hausmittel</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/gesundheit/bmi-rechner/">
<p>BMI-Rechner</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/gesundheit/thema/">
<p>Gesundheit von A-Z</p>

</a>

</li>


</ul>
</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/video/">
<p>Videos</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/video/shorts/">
<p>Shorts</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/kolumnen/">
<p>Kolumnen</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/services/">
<p>Service</p>
<span data-arrow-down="">
<div data-component="icon" data-tr-event-type="userAction">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
</a>
<ul>


<li data-component="TreeList" >
<a href="https://web.de/wetter/">
<p>Wetter</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/unterhaltung/lifestyle/horoskop/">
<p>Horoskop</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://route.web.de/">
<p>Routenplaner</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/reise/ferientermine/">
<p>Ferientermine</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/reise/feiertage/">
<p>Feiertage</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/gesundheit/bmi-rechner/">
<p>BMI-Rechner</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/partner/immobilienboerse/">
<p>Immobilienbörse</p>

</a>

</li>


</ul>
</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/in-eigener-sache/">
<p>In eigener Sache</p>
<span data-arrow-down="">
<div data-component="icon" data-tr-event-type="userAction">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
</a>
<ul>


<li data-component="TreeList" >
<a href="https://web.de/magazine/in-eigener-sache/externe-inhalte/">
<p>Zustimmungen</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/in-eigener-sache/jugendschutz/">
<p>Jugendschutz</p>

</a>

</li>


</ul>
</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/unicef/">
<p>United Internet for UNICEF</p>

</a>

</li>


</ul>
</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/so-arbeitet-die-redaktion/">
<p>So arbeitet die Redaktion</p>
<span data-arrow-down="">
<div data-component="icon" data-tr-event-type="userAction">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
</a>
<ul>


<li data-component="TreeList" >
<a href="https://web.de/magazine/autor/">
<p>Unsere Redaktion</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/so-arbeitet-die-redaktion/mails-news-redaktionelles-leitbild-34463152">
<p>Unser Leitbild</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/so-arbeitet-die-redaktion/entstehen-inhalte-inhalte-32384734">
<p>Quellenauswahl</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/so-arbeitet-die-redaktion/autoren-vollem-namen-nennen-kuerzel-angeben-36780394">
<p>Transparenz</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/so-arbeitet-die-redaktion/sicherstellen-inhalte-stimmen-35584004">
<p>Faktencheck</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/so-arbeitet-die-redaktion/kuenstliche-intelligenz-einsetzen-grenzen-38389056">
<p>Künstliche Intellligenz</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/so-arbeitet-die-redaktion/fehler-redaktionsalltag-passieren-umgehen-32423700">
<p>Korrekturen</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/so-arbeitet-die-redaktion/feedback-erreicht-redaktion-35644470">
<p>Feedback</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/magazine/so-arbeitet-die-redaktion/redaktion-diversitaet-gleichberechtigung-ermoeglichen-36395376">
<p>Diversität</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://www.jti-app.com/report/XMwAnrR3PGj985Zq" rel="nofollow">
<p>Zertifikate</p>

</a>

</li>


</ul>
</li>

<li data-component="TreeList" >
<a href="https://t.uimserv.net/drp_r/?md=uid&amp;et=WR&amp;evtid=864&amp;mediaID=929&amp;mpID=4&amp;site=webde&amp;region=de&amp;sc=vw_uebersichtsseite/vw_startseite&amp;lpos=text_link&amp;att1=webde_hp&amp;durl=https%3A%2F%2Fvorteile.web.de%2F">
<p>Vorteilswelt</p>
<span data-arrow-down="">
<div data-component="icon" data-tr-event-type="userAction">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
</a>
<ul>


<li data-component="TreeList" >
<a href="https://vorteile.web.de/software-mobile/#.hp_mobile.int.nav.vorteilswelt">
<p>Software &amp; Mobile</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://vorteile.web.de/finanzen/#.hp_mobile.int.nav.vorteilswelt">
<p>Finanzen</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://vorteile.web.de/unterhaltung/#.hp_mobile.int.nav.vorteilswelt">
<p>Unterhaltung</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://produkte.web.de/homepage-mail/?mc=01993406">
<p>Ihre Webseite</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://produkte.web.de/musik-flatrate/?mc=03960650">
<p>Musik-Streaming</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://produkte.web.de/zattoo/?mc=03960653">
<p>TV-Streaming</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://produkte.web.de/gymondo/?mc=05577154">
<p>Gymondo</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://produkte.web.de/sprachen-lernen/?mc=03961835">
<p>Online-Sprachkurse</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://produkte.web.de/readly/?mc=05577156">
<p>Readly</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://shopping.web.de/?origin=magazine_nav">
<p>Shopping</p>

</a>

</li>


</ul>
</li>

<li data-component="TreeList" >
<a href="https://produkte.web.de/apps/#.hp_mobile.int.nav.apps">
<p>Apps</p>
<span data-arrow-down="">
<div data-component="icon" data-tr-event-type="userAction">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
</a>
<ul>


<li data-component="TreeList" >
<a href="https://produkte.web.de/browser/firefox/#.hp_mobile.int.nav.browser">
<p>Firefox Browser</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://produkte.web.de/apps/mail/#.hp_mobile.int.nav.mailapp">
<p>Mail App</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://produkte.web.de/mailcheck/#.hp_mobile.int.nav.mailcheck">
<p>MailCheck</p>

</a>

</li>


</ul>
</li>

<li data-component="TreeList" >
<a href="https://web.de/versicherung/?mc=01881490">
<p>Versicherung</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://lotto.web.de/?partnerId=1WEMOBHNAV&amp;advertisementId=0NAVIGA000000000LOTTOSERVI0007700mobilehome">
<p>Lotto</p>
<span data-arrow-down="">
<div data-component="icon" data-tr-event-type="userAction">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
</a>
<ul>


<li data-component="TreeList" >
<a href="https://lotto.web.de/lotto-6-aus-49?partnerId=1WEMOBHNAV&amp;advertisementId=0NAVIGA000000000LOTTO6AU490001000mobilehome">
<p>6aus49</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://lotto.web.de/eurojackpot?partnerId=1WEMOBHNAV&amp;advertisementId=0NAVIGA000000000EUROJACKPO0002000mobilehome">
<p>Eurojackpot</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://lotto.web.de/spielgemeinschaft/uebersicht?partnerId=1WEMOBHNAV&amp;advertisementId=0NAVIGA000000000SPIELGEMEI0005500mobilehome">
<p>Spielgemeinschaften</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://lotto.web.de/traumhausverlosung?partnerId=1WEMOBHNAV&amp;advertisementId=0NAVIGL000000000TRAUMHAUSV0000900mobilehome">
<p>Traumhausverlosung</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://lotto.web.de/freiheitplus?partnerId=1WEMOBHNAV&amp;advertisementId=0NAVIGL000000000FREIHEITPL0006900mobilehome">
<p>freiheit+</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://lotto.web.de/gluecksspirale?partnerId=1WEMOBHNAV&amp;advertisementId=0NAVIGA000000000GLUSPIRALE0003000mobilehome">
<p>Glücksspirale</p>

</a>

</li>


</ul>
</li>

<li data-component="TreeList" >
<a href="https://games.web.de?mc=05577160">
<p>Games</p>
<span data-arrow-down="">
<div data-component="icon" data-tr-event-type="userAction">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
</a>
<ul>


<li data-component="TreeList" >
<a href="https://games.web.de/jackpot-spiele?mc=05577160">
<p>Jackpot-Spiele</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://games.web.de/pausen-spiele?mc=05577161">
<p>Pausen-Spiele</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://games.web.de/simulation?mc=05577162">
<p>Simulations-Spiele</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://games.web.de/strategie?mc=05577163">
<p>Strategie-Spiele</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://games.web.de/abenteuer?mc=05577164">
<p>Abenteuer-Spiele</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://games.web.de/rollenspiele?mc=05577165">
<p>Rollenspiele</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://millionenklick.web.de/#C0101110b01010101   ">
<p>MillionenKlick</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://gewinnspiel.web.de/">
<p>Gewinnspiel</p>

</a>

</li>


</ul>
</li>

<li data-component="TreeList" >
<a href="https://web.de/vergleichswelt/finanzen/?mc=80000081">
<p>Finanzen</p>
<span data-arrow-down="">
<div data-component="icon" data-tr-event-type="userAction">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
</a>
<ul>


<li data-component="TreeList" >
<a href="https://web.de/vergleichswelt/finanzen/konto-und-karte/girokonto/?mc=80000365">
<p>Girokonto</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/vergleichswelt/finanzen/konto-und-karte/kreditkarte/?mc=80000401">
<p>Kreditkarte</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/vergleichswelt/finanzen/geldanlage/tagesgeldkonto/?mc=80000366">
<p>Tagesgeldkonto</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/vergleichswelt/finanzen/geldanlage/bausparvertrag/?mc=80000367">
<p>Bausparvertrag</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/vergleichswelt/finanzen/geldanlage/depot/?mc=80000368">
<p>Depot</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/vergleichswelt/finanzen/geldanlage/festgeld/?mc=80000369">
<p>Festgeld</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/vergleichswelt/finanzen/kredite-und-finanzierung/ratenkredit/?mc=80000370">
<p>Ratenkredit</p>

</a>

</li>


</ul>
</li>

<li data-component="TreeList" >
<a href="https://web.de/vergleichswelt/?mc=80000080 ">
<p>Vergleichswelt</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/impressum/">
<p>Impressum</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://web.de/sitemap/">
<p>WEB.DE im Überblick</p>
<span data-arrow-down="">
<div data-component="icon" data-tr-event-type="userAction">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
</a>
<ul>


<li data-component="TreeList" >
<a href="https://hilfe.web.de/index.html">
<p>WEB.DE Hilfe</p>

</a>

</li>

<li data-component="TreeList" >
<a href="https://newsroom.web.de/">
<p>WEB.DE Presse</p>

</a>

</li>


</ul>
</li>

</ul>
</nav>
</div>
</div>
</div>
<div data-burger-layer @click="close"></div>
</hp-burger>


<ul>
<li data-component-sub="li">
<a href="https://web.de/email/#.pc_page.homepage.index.nav.mail">E-Mail &amp; Cloud</a>

</li><li data-component-sub="li">
<a href="https://web.de/handy/?mc=05504539">Mobilfunk &amp; DSL</a>

</li><li data-component-sub="li">
<a href="https://www.mail-and-media.com/jobs.html">Jobs bei WEB.DE</a>

</li><li data-component-sub="li">
<a href="https://www.energie.web.de/strom/?mc=05576077">Strom &amp; Gas</a>

</li><li data-component-sub="li" class="sup">
<a href="https://lotto.web.de?partnerId=1WEHOMHNAV&amp;advertisementId=0REITER000000000TEXTLINKXX00000001234567891">Lotto</a>
<sup>120 Mio</sup>
</li><li data-component-sub="li">
<a href="https://vorteile.web.de/?mc=05581985">Vorteilswelt</a>

</li><li data-component-sub="li">
<a href="https://produkte.web.de/premium/?mc=03963798">PremiumMail</a>

</li><li data-component-sub="li">
<a href="https://vorteile.web.de/webcent/#.hp.int.navi">Cashback</a>

</li><li data-component-sub="li">
<a href="https://games.web.de/?mc=05576605">Games</a>

</li>
</ul>


<div class="partner-links">
<div data-service-slot="promo_1"></div>
<div data-service-slot="promo_2"></div>
<div data-service-slot="promo_3"></div>
</div>

</hp-navigation>
</header>
</hp-header>




<div data-content>


<section data-layout-columns="4col" data-layout-name="viewport" data-name="viewport" data-tracking-name="viewport">

<hp-slider v-slot="{ goTo, goPrev, goNext }" data-component="slider" :indicator-position="&#039;right&#039;" :interval="5000" :animation-type="&#039;fade&#039;" data-tr-component-path="hero" data-slide-indicator-position="left" data-animation-type="fade">
<div data-part="indicators">
<ul>
<li data-tr-component-path="thumbnails" @click="goTo" data-indicator="0">
<a href="https://web.de/magazine/panorama/news-konklave-papst-gewaehlt-schwarzer-rauch-vatikan-40955428" @mouseenter="goTo">
<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/056/40956056,pd=1,h=56,w=95/benediktionsloggia-petersdoms.webp 95w, https://i0.web.de/image/056/40956056,pd=1,h=84,w=142/benediktionsloggia-petersdoms.webp 142w, https://i0.web.de/image/056/40956056,pd=1,h=112,w=190/benediktionsloggia-petersdoms.webp 190w" sizes="95px">
<img alt="Die Benediktionsloggia des Petersdoms" fetchpriority="high" src="https://i0.web.de/image/056/40956056,pd=1,h=56,w=95/benediktionsloggia-petersdoms.jpg" width="95" height="56">
</picture>


<figcaption>Papstwahl</figcaption>
</figure>
</a>

</li><li data-tr-component-path="thumbnails" @click="goTo" data-indicator="1">
<a href="https://web.de/magazine/politik/us-politik/us-vize-umschmeichelt-europa-40955516" @mouseenter="goTo">
<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/778/40955778,pd=1,h=56,w=95.webp 95w, https://i0.web.de/image/778/40955778,pd=1,h=84,w=142.webp 142w, https://i0.web.de/image/778/40955778,pd=1,h=112,w=190.webp 190w" sizes="95px">
<img alt="" fetchpriority="high" src="https://i0.web.de/image/778/40955778,pd=1,h=56,w=95.jpg" width="95" height="56">
</picture>


<figcaption>Erstaunlicher Vance-Auftritt </figcaption>
</figure>
</a>

</li><li data-tr-component-path="thumbnails" @click="goTo" data-indicator="2">
<a href="https://web.de/magazine/politik/afd-verbieten-hasselmann-erheblich-gesteigerten-handlungsdruck-40952672" @mouseenter="goTo">
<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/716/40952716,pd=3,h=56,w=95/britta-hasselmann-interview.webp 95w, https://i0.web.de/image/716/40952716,pd=3,h=84,w=142/britta-hasselmann-interview.webp 142w, https://i0.web.de/image/716/40952716,pd=3,h=112,w=190/britta-hasselmann-interview.webp 190w" sizes="95px">
<img alt="Britta Haßelmann Interview" fetchpriority="high" src="https://i0.web.de/image/716/40952716,pd=3,h=56,w=95/britta-hasselmann-interview.jpg" width="95" height="56">
</picture>


<figcaption>Grünen-Fraktionsvorsitzende</figcaption>
</figure>
</a>

</li><li data-tr-component-path="thumbnails" @click="goTo" data-indicator="3">
<a href="https://web.de/magazine/sport/fussball/champions-league/witz-herbe-kritik-deutschem-schiedsrichter-zwayer-40955936" @mouseenter="goTo">
<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/938/40955938,pd=2,h=56,w=95/paris-saint-germain-fc-arsenal.webp 95w, https://i0.web.de/image/938/40955938,pd=2,h=84,w=142/paris-saint-germain-fc-arsenal.webp 142w, https://i0.web.de/image/938/40955938,pd=2,h=112,w=190/paris-saint-germain-fc-arsenal.webp 190w" sizes="95px">
<img alt="Paris Saint-Germain - FC Arsenal" fetchpriority="high" src="https://i0.web.de/image/938/40955938,pd=2,h=56,w=95/paris-saint-germain-fc-arsenal.jpg" width="95" height="56">
</picture>


<figcaption>&quot;Ein Witz&quot;</figcaption>
</figure>
</a>

</li><li data-tr-component-path="thumbnails" @click="goTo" data-indicator="4">
<a href="https://web.de/magazine/ratgeber/videos/haus-garten/moos-rasen-los-40922710" @mouseenter="goTo">
<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/758/40955758,pd=2,h=56,w=95.webp 95w, https://i0.web.de/image/758/40955758,pd=2,h=84,w=142.webp 142w, https://i0.web.de/image/758/40955758,pd=2,h=112,w=190.webp 190w" sizes="95px">
<img alt="" fetchpriority="high" src="https://i0.web.de/image/758/40955758,pd=2,h=56,w=95.jpg" width="95" height="56">
</picture>


<figcaption>Ungeliebtes Grün</figcaption>
</figure>
</a>

</li>
</ul>
</div>

<div data-wrapper>
<div>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/panorama/news-konklave-papst-gewaehlt-schwarzer-rauch-vatikan-40955428" data-headline="Noch kein neuer Papst gewählt – schwarzer Rauch über dem Vatikan" data-teaser-id="40955428" data-article-overlay="bottomfull" data-current="">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/056/40956056,pd=1,h=300,w=530/benediktionsloggia-petersdoms.webp 530w, https://i0.web.de/image/056/40956056,pd=1,h=450,w=795/benediktionsloggia-petersdoms.webp 795w, https://i0.web.de/image/056/40956056,pd=1,h=600,w=1060/benediktionsloggia-petersdoms.webp 1060w" sizes="530px">
<img alt="Die Benediktionsloggia des Petersdoms" fetchpriority="high" src="https://i0.web.de/image/056/40956056,pd=1,h=300,w=530/benediktionsloggia-petersdoms.jpg" width="530" height="300">
</picture>





</figure>

<article>
<header>
<span>
<label data-color="error">Live-Blog</label>


Papstwahl
</span>
<h3>Noch kein neuer Papst gewählt – schwarzer Rauch über dem Vatikan</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/politik/us-politik/us-vize-umschmeichelt-europa-40955516" data-headline="US-Vize umschmeichelt auf einmal Europa" data-teaser-id="40955516" data-article-overlay="bottomfull">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/778/40955778,pd=1,h=300,w=530.webp 530w, https://i0.web.de/image/778/40955778,pd=1,h=450,w=795.webp 795w, https://i0.web.de/image/778/40955778,pd=1,h=600,w=1060.webp 1060w" sizes="530px">
<img alt="" fetchpriority="high" src="https://i0.web.de/image/778/40955778,pd=1,h=300,w=530.jpg" width="530" height="300">
</picture>





</figure>

<article>
<header>
<span>



Erstaunlicher Vance-Auftritt 
</span>
<h3>US-Vize umschmeichelt auf einmal Europa</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/politik/afd-verbieten-hasselmann-erheblich-gesteigerten-handlungsdruck-40952672" data-headline="AfD verbieten? Haßelmann sieht &quot;erheblich gesteigerten Handlungsdruck&quot;" data-teaser-id="40952672" data-article-overlay="bottomfull">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/716/40952716,pd=3,h=300,w=530/britta-hasselmann-interview.webp 530w, https://i0.web.de/image/716/40952716,pd=3,h=450,w=795/britta-hasselmann-interview.webp 795w, https://i0.web.de/image/716/40952716,pd=3,h=600,w=1060/britta-hasselmann-interview.webp 1060w" sizes="530px">
<img alt="Britta Haßelmann Interview" fetchpriority="high" src="https://i0.web.de/image/716/40952716,pd=3,h=300,w=530/britta-hasselmann-interview.jpg" width="530" height="300">
</picture>





</figure>

<article>
<header>
<span>
<label>Interview</label>


Grünen-Fraktionsvorsitzende
</span>
<h3>AfD verbieten? Haßelmann sieht &quot;erheblich gesteigerten Handlungsdruck&quot;</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/sport/fussball/champions-league/witz-herbe-kritik-deutschem-schiedsrichter-zwayer-40955936" data-headline="Herbe Kritik an deutschem Schiedsrichter" data-teaser-id="40955936" data-article-overlay="bottomfull">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/938/40955938,pd=2,h=300,w=530/paris-saint-germain-fc-arsenal.webp 530w, https://i0.web.de/image/938/40955938,pd=2,h=450,w=795/paris-saint-germain-fc-arsenal.webp 795w, https://i0.web.de/image/938/40955938,pd=2,h=600,w=1060/paris-saint-germain-fc-arsenal.webp 1060w" sizes="530px">
<img alt="Paris Saint-Germain - FC Arsenal" fetchpriority="high" src="https://i0.web.de/image/938/40955938,pd=2,h=300,w=530/paris-saint-germain-fc-arsenal.jpg" width="530" height="300">
</picture>





</figure>

<article>
<header>
<span>



&quot;Ein Witz&quot;
</span>
<h3>Herbe Kritik an deutschem Schiedsrichter</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/ratgeber/videos/haus-garten/moos-rasen-los-40922710" data-headline="So werden Sie Moos im Rasen wieder los" data-teaser-id="40922710" data-article-overlay="bottomfull">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/758/40955758,pd=2,h=300,w=530.webp 530w, https://i0.web.de/image/758/40955758,pd=2,h=450,w=795.webp 795w, https://i0.web.de/image/758/40955758,pd=2,h=600,w=1060.webp 1060w" sizes="530px">
<img alt="" fetchpriority="high" src="https://i0.web.de/image/758/40955758,pd=2,h=300,w=530.jpg" width="530" height="300">
</picture>





</figure>

<article>
<header>
<span>

<label data-color="grey">Video</label>

Ungeliebtes Grün
</span>
<h3>So werden Sie Moos im Rasen wieder los</h3>

</header>



</article>
</a>

</div>
</div>
</hp-slider>

<div data-component="list" data-visible-in="3col" data-tr-component-path="pointOfView">


<ul>
<li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/sport/fussball/bundesliga/vereinen-sandro-wagner-kurs-stehen-40955746" data-separator="top" data-headline="Die Wagner-Gerüchte werden heißer" data-teaser-id="40955746">



<article>
<header>
<span>



Vom DFB in die Bundesliga
</span>
<h3>Die Wagner-Gerüchte werden heißer</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/ratgeber/finanzen-verbraucher/abzocke-einreisegenehmigung-thailand-40914184" data-separator="top" data-headline="Vorsicht: Abzocke mit neuer Einreisegenehmigung für Thailand" data-teaser-id="40914184">



<article>
<header>
<span>



Verbraucher
</span>
<h3>Vorsicht: Abzocke mit neuer Einreisegenehmigung für Thailand</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/sport/fussball/bundesliga/fc-bayern/ex-teamkollege-gosens-lockt-bayern-star-mueller-italien-40955010" data-separator="top" data-headline="Ex-Teamkollege lockt Müller nach Italien" data-teaser-id="40955010">



<article>
<header>
<span>



&quot;Toskana ist sehr schön&quot;
</span>
<h3>Ex-Teamkollege lockt Müller nach Italien</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/politik/videos/russland-krieg-ukraine/jd-vance-attackiert-kreml-forderungen-friedensverhandlungen-40955652" data-separator="top" data-headline="JD Vance attackiert Kreml-Forderungen bei Friedensverhandlungen" data-teaser-id="40955652">



<article>
<header>
<span>

<label data-color="grey">Video</label>

Trump zeigt sich ahnungslos
</span>
<h3>JD Vance attackiert Kreml-Forderungen bei Friedensverhandlungen</h3>

</header>



</article>
</a>

</li>
</ul>
</div>

<div data-component="list" data-visible-in="4col" data-tr-component-path="pointOfView">


<ul>
<li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/sport/fussball/bundesliga/vereinen-sandro-wagner-kurs-stehen-40955746" data-separator="top" data-headline="Die Wagner-Gerüchte werden heißer" data-teaser-id="40955746">



<article>
<header>
<span>



Vom DFB in die Bundesliga
</span>
<h3>Die Wagner-Gerüchte werden heißer</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/ratgeber/finanzen-verbraucher/abzocke-einreisegenehmigung-thailand-40914184" data-separator="top" data-headline="Vorsicht: Abzocke mit neuer Einreisegenehmigung für Thailand" data-teaser-id="40914184">



<article>
<header>
<span>



Verbraucher
</span>
<h3>Vorsicht: Abzocke mit neuer Einreisegenehmigung für Thailand</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/sport/fussball/bundesliga/fc-bayern/ex-teamkollege-gosens-lockt-bayern-star-mueller-italien-40955010" data-separator="top" data-headline="Ex-Teamkollege lockt Müller nach Italien" data-teaser-id="40955010">



<article>
<header>
<span>



&quot;Toskana ist sehr schön&quot;
</span>
<h3>Ex-Teamkollege lockt Müller nach Italien</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/politik/videos/russland-krieg-ukraine/jd-vance-attackiert-kreml-forderungen-friedensverhandlungen-40955652" data-separator="top" data-headline="JD Vance attackiert Kreml-Forderungen bei Friedensverhandlungen" data-teaser-id="40955652">



<article>
<header>
<span>

<label data-color="grey">Video</label>

Trump zeigt sich ahnungslos
</span>
<h3>JD Vance attackiert Kreml-Forderungen bei Friedensverhandlungen</h3>

</header>



</article>
</a>

</li>
</ul>
</div>

<div data-component="list" data-visible-in="5col" data-tr-component-path="pointOfView">


<ul>
<li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/ratgeber/finanzen-verbraucher/abzocke-einreisegenehmigung-thailand-40914184" data-separator="top" data-headline="Vorsicht: Abzocke mit neuer Einreisegenehmigung für Thailand" data-teaser-id="40914184">



<article>
<header>
<span>



Verbraucher
</span>
<h3>Vorsicht: Abzocke mit neuer Einreisegenehmigung für Thailand</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/sport/fussball/bundesliga/fc-bayern/ex-teamkollege-gosens-lockt-bayern-star-mueller-italien-40955010" data-separator="top" data-headline="Ex-Teamkollege lockt Müller nach Italien" data-teaser-id="40955010">



<article>
<header>
<span>



&quot;Toskana ist sehr schön&quot;
</span>
<h3>Ex-Teamkollege lockt Müller nach Italien</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/politik/videos/russland-krieg-ukraine/jd-vance-attackiert-kreml-forderungen-friedensverhandlungen-40955652" data-separator="top" data-headline="JD Vance attackiert Kreml-Forderungen bei Friedensverhandlungen" data-teaser-id="40955652">



<article>
<header>
<span>

<label data-color="grey">Video</label>

Trump zeigt sich ahnungslos
</span>
<h3>JD Vance attackiert Kreml-Forderungen bei Friedensverhandlungen</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/musik/schlager/patricia-kelly-erklaert-jugendsuende-40955494" data-separator="top" data-headline="Patricia Kelly erklärt ihre Jugendsünde" data-teaser-id="40955494">



<article>
<header>
<span>



Vor 25 Jahren Auto demoliert
</span>
<h3>Patricia Kelly erklärt ihre Jugendsünde</h3>

</header>



</article>
</a>

</li>
</ul>
</div>

<div data-service-slot="box_1" data-tr-component-path="box_1" data-visible-in="4,5"></div>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/sport/fussball/bundesliga/vereinen-sandro-wagner-kurs-stehen-40955746" data-visible-in="5col" data-headline="Die Wagner-Gerüchte werden heißer" data-teaser-id="40955746" data-tr-component-path="pointOfView">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/748/40955748,pd=3,h=170,w=300/sandro-wagner.webp 300w, https://i0.web.de/image/748/40955748,pd=3,h=255,w=450/sandro-wagner.webp 450w, https://i0.web.de/image/748/40955748,pd=3,h=340,w=600/sandro-wagner.webp 600w" sizes="300px">
<img alt="Sandro Wagner" fetchpriority="high" src="https://i0.web.de/image/748/40955748,pd=3,h=170,w=300/sandro-wagner.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Vom DFB in die Bundesliga
</span>
<h3>Die Wagner-Gerüchte werden heißer</h3>

</header>


<footer>
<span>vor 44 Minuten</span>


</footer>
</article>
</a>

</section>

<section data-layout-columns="4col" data-layout-name="teasers" data-name="Recommendation" data-tr-component-path="Recommendation" data-tracking-name="threeList">

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/tv-shows/bachelor/bachelors-rosenkavaliere-uebernehmen-stefan-raabs-sendeplatz-40951208" data-visible-in="5col" data-headline="Zwei Rosenkavaliere übernehmen Stefan Raabs Sendeplatz" data-teaser-id="40951208">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/602/40955602,pd=1,h=170,w=300/stefan-raab.webp 300w, https://i0.web.de/image/602/40955602,pd=1,h=255,w=450/stefan-raab.webp 450w, https://i0.web.de/image/602/40955602,pd=1,h=340,w=600/stefan-raab.webp 600w" sizes="300px">
<img alt="Stefan Raab" fetchpriority="high" src="https://i0.web.de/image/602/40955602,pd=1,h=170,w=300/stefan-raab.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



RTL zeigt ab Juni &quot;Bachelors&quot;
</span>
<h3>Zwei Rosenkavaliere übernehmen Stefan Raabs Sendeplatz</h3>

</header>


<footer>
<span>vor 2 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/panorama/sexuelle-gewalt-minderjaehrige-bleibt-weltweit-ungeloestes-problem-40955308" data-visible-in="5col" data-headline="Sexuelle Gewalt gegen Minderjährige bleibt weltweit ungelöstes Problem" data-teaser-id="40955308">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/380/40955380,pd=2,h=170,w=300/illustration-gewalt-kindern.webp 300w, https://i0.web.de/image/380/40955380,pd=2,h=255,w=450/illustration-gewalt-kindern.webp 450w, https://i0.web.de/image/380/40955380,pd=2,h=340,w=600/illustration-gewalt-kindern.webp 600w" sizes="300px">
<img alt="Illustration - Gewalt an Kindern" fetchpriority="high" src="https://i0.web.de/image/380/40955380,pd=2,h=170,w=300/illustration-gewalt-kindern.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Globale Studie veröffentlicht
</span>
<h3>Sexuelle Gewalt gegen Minderjährige bleibt weltweit ungelöstes Problem</h3>

</header>


<footer>
<span>vor 2 Stunden</span>


</footer>
</article>
</a>

<div data-component="list" data-visible-in="5col">


<ul>
<li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/politik/us-politik/trump-ernennt-influencerin-obersten-us-aerztin-40955112" data-separator="top" data-headline="Trump ernennt Influencerin zur obersten US-Ärztin" data-teaser-id="40955112">



<article>
<header>
<span>



Entscheidung nach Protest
</span>
<h3>Trump ernennt Influencerin zur obersten US-Ärztin</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/stars/liebe-blick-alexandra-maria-lara-sam-riley-40954710" data-separator="top" data-headline="Zwischen Alexandra Maria Lara und Sam Riley war es Liebe auf den ersten Blick" data-teaser-id="40954710">



<article>
<header>
<span>



Seit 15 Jahren verheiratet
</span>
<h3>Zwischen Alexandra Maria Lara und Sam Riley war es Liebe auf den ersten Blick</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/politik/videos/inland/umfrage-mehrheit-deutschen-haelt-afd-rechtsextrem-40955300" data-separator="top" data-headline="Umfrage: Mehrheit der Deutschen hält AfD für rechtsextrem" data-teaser-id="40955300">



<article>
<header>
<span>

<label data-color="grey">Video</label>

Anders als AfD-Anhänger selbst
</span>
<h3>Umfrage: Mehrheit der Deutschen hält AfD für rechtsextrem</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/musik/3-doors-down-frontmann-brad-arnold-krebs-endstadium-40955440" data-separator="top" data-headline="&quot;3 Doors Down&quot;-Frontmann hat Krebs im Endstadium" data-teaser-id="40955440">



<article>
<header>
<span>



Tour abgesagt
</span>
<h3>&quot;3 Doors Down&quot;-Frontmann hat Krebs im Endstadium</h3>

</header>



</article>
</a>

</li>
</ul>
</div>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/wissen/geschichte/zeitzeugin-schaemen-deutsche-40951372" data-visible-in="5col" data-headline="Zeitzeugin: &quot;Jetzt muss ich mich schämen, dass ich eine Deutsche bin&quot;" data-teaser-id="40951372">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/382/40951382,pd=3,h=170,w=300/kapitualationserklaerung-zweiten-weltkriegs-europa.webp 300w, https://i0.web.de/image/382/40951382,pd=3,h=255,w=450/kapitualationserklaerung-zweiten-weltkriegs-europa.webp 450w, https://i0.web.de/image/382/40951382,pd=3,h=340,w=600/kapitualationserklaerung-zweiten-weltkriegs-europa.webp 600w" sizes="300px">
<img alt="Kapitualationserklärung, Ende des Zweiten Weltkriegs in Europa" fetchpriority="high" src="https://i0.web.de/image/382/40951382,pd=3,h=170,w=300/kapitualationserklaerung-zweiten-weltkriegs-europa.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Kriegsende vor 80 Jahren
</span>
<h3>Zeitzeugin: &quot;Jetzt muss ich mich schämen, dass ich eine Deutsche bin&quot;</h3>

</header>


<footer>
<span>vor 6 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/politik/russland-krieg-ukraine/feuerpause-ukraine-russland-melden-angriffe-40954986" data-visible-in="5col" data-headline="Doch keine Feuerpause? Ukraine und Russland melden Angriffe" data-teaser-id="40954986">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/322/40955322,pd=1,h=170,w=300.webp 300w, https://i0.web.de/image/322/40955322,pd=1,h=255,w=450.webp 450w, https://i0.web.de/image/322/40955322,pd=1,h=340,w=600.webp 600w" sizes="300px">
<img alt="" fetchpriority="high" src="https://i0.web.de/image/322/40955322,pd=1,h=170,w=300.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Krieg in der Ukraine
</span>
<h3>Doch keine Feuerpause? Ukraine und Russland melden Angriffe</h3>

</header>


<footer>
<span>vor 4 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/musik/schlager/patricia-kelly-erklaert-jugendsuende-40955494" data-visible-in="4col" data-headline="Patricia Kelly erklärt ihre Jugendsünde" data-teaser-id="40955494">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/488/40955488,pd=1,h=170,w=300/patricia-kelly.webp 300w, https://i0.web.de/image/488/40955488,pd=1,h=255,w=450/patricia-kelly.webp 450w, https://i0.web.de/image/488/40955488,pd=1,h=340,w=600/patricia-kelly.webp 600w" sizes="300px">
<img alt="Patricia Kelly" fetchpriority="high" src="https://i0.web.de/image/488/40955488,pd=1,h=170,w=300/patricia-kelly.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Vor 25 Jahren Auto demoliert
</span>
<h3>Patricia Kelly erklärt ihre Jugendsünde</h3>

</header>


<footer>
<span>vor 1 Stunde</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/tv-shows/bachelor/bachelors-rosenkavaliere-uebernehmen-stefan-raabs-sendeplatz-40951208" data-visible-in="4col" data-headline="Zwei Rosenkavaliere übernehmen Stefan Raabs Sendeplatz" data-teaser-id="40951208">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/602/40955602,pd=1,h=170,w=300/stefan-raab.webp 300w, https://i0.web.de/image/602/40955602,pd=1,h=255,w=450/stefan-raab.webp 450w, https://i0.web.de/image/602/40955602,pd=1,h=340,w=600/stefan-raab.webp 600w" sizes="300px">
<img alt="Stefan Raab" fetchpriority="high" src="https://i0.web.de/image/602/40955602,pd=1,h=170,w=300/stefan-raab.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



RTL zeigt ab Juni &quot;Bachelors&quot;
</span>
<h3>Zwei Rosenkavaliere übernehmen Stefan Raabs Sendeplatz</h3>

</header>


<footer>
<span>vor 2 Stunden</span>


</footer>
</article>
</a>

<div data-component="list" data-visible-in="4col">


<ul>
<li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/panorama/sexuelle-gewalt-minderjaehrige-bleibt-weltweit-ungeloestes-problem-40955308" data-separator="top" data-headline="Sexuelle Gewalt gegen Minderjährige bleibt weltweit ungelöstes Problem" data-teaser-id="40955308">



<article>
<header>
<span>



Globale Studie veröffentlicht
</span>
<h3>Sexuelle Gewalt gegen Minderjährige bleibt weltweit ungelöstes Problem</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/politik/us-politik/trump-ernennt-influencerin-obersten-us-aerztin-40955112" data-separator="top" data-headline="Trump ernennt Influencerin zur obersten US-Ärztin" data-teaser-id="40955112">



<article>
<header>
<span>



Entscheidung nach Protest
</span>
<h3>Trump ernennt Influencerin zur obersten US-Ärztin</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/stars/liebe-blick-alexandra-maria-lara-sam-riley-40954710" data-separator="top" data-headline="Zwischen Alexandra Maria Lara und Sam Riley war es Liebe auf den ersten Blick" data-teaser-id="40954710">



<article>
<header>
<span>



Seit 15 Jahren verheiratet
</span>
<h3>Zwischen Alexandra Maria Lara und Sam Riley war es Liebe auf den ersten Blick</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/politik/videos/inland/umfrage-mehrheit-deutschen-haelt-afd-rechtsextrem-40955300" data-separator="top" data-headline="Umfrage: Mehrheit der Deutschen hält AfD für rechtsextrem" data-teaser-id="40955300">



<article>
<header>
<span>

<label data-color="grey">Video</label>

Anders als AfD-Anhänger selbst
</span>
<h3>Umfrage: Mehrheit der Deutschen hält AfD für rechtsextrem</h3>

</header>



</article>
</a>

</li>
</ul>
</div>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/musik/3-doors-down-frontmann-brad-arnold-krebs-endstadium-40955440" data-visible-in="4col" data-headline="&quot;3 Doors Down&quot;-Frontmann hat Krebs im Endstadium" data-teaser-id="40955440">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/448/40955448,pd=1,h=170,w=300/brad-arnold.webp 300w, https://i0.web.de/image/448/40955448,pd=1,h=255,w=450/brad-arnold.webp 450w, https://i0.web.de/image/448/40955448,pd=1,h=340,w=600/brad-arnold.webp 600w" sizes="300px">
<img alt="Brad Arnold" fetchpriority="high" src="https://i0.web.de/image/448/40955448,pd=1,h=170,w=300/brad-arnold.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Tour abgesagt
</span>
<h3>&quot;3 Doors Down&quot;-Frontmann hat Krebs im Endstadium</h3>

</header>


<footer>
<span>vor 2 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/musik/schlager/patricia-kelly-erklaert-jugendsuende-40955494" data-visible-in="3col" data-headline="Patricia Kelly erklärt ihre Jugendsünde" data-teaser-id="40955494">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/488/40955488,pd=1,h=170,w=300/patricia-kelly.webp 300w, https://i0.web.de/image/488/40955488,pd=1,h=255,w=450/patricia-kelly.webp 450w, https://i0.web.de/image/488/40955488,pd=1,h=340,w=600/patricia-kelly.webp 600w" sizes="300px">
<img alt="Patricia Kelly" fetchpriority="high" src="https://i0.web.de/image/488/40955488,pd=1,h=170,w=300/patricia-kelly.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Vor 25 Jahren Auto demoliert
</span>
<h3>Patricia Kelly erklärt ihre Jugendsünde</h3>

</header>


<footer>
<span>vor 1 Stunde</span>


</footer>
</article>
</a>

<div data-component="list" data-visible-in="3col">


<ul>
<li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/tv-shows/bachelor/bachelors-rosenkavaliere-uebernehmen-stefan-raabs-sendeplatz-40951208" data-separator="top" data-headline="Zwei Rosenkavaliere übernehmen Stefan Raabs Sendeplatz" data-teaser-id="40951208">



<article>
<header>
<span>



RTL zeigt ab Juni &quot;Bachelors&quot;
</span>
<h3>Zwei Rosenkavaliere übernehmen Stefan Raabs Sendeplatz</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/panorama/sexuelle-gewalt-minderjaehrige-bleibt-weltweit-ungeloestes-problem-40955308" data-separator="top" data-headline="Sexuelle Gewalt gegen Minderjährige bleibt weltweit ungelöstes Problem" data-teaser-id="40955308">



<article>
<header>
<span>



Globale Studie veröffentlicht
</span>
<h3>Sexuelle Gewalt gegen Minderjährige bleibt weltweit ungelöstes Problem</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/politik/us-politik/trump-ernennt-influencerin-obersten-us-aerztin-40955112" data-separator="top" data-headline="Trump ernennt Influencerin zur obersten US-Ärztin" data-teaser-id="40955112">



<article>
<header>
<span>



Entscheidung nach Protest
</span>
<h3>Trump ernennt Influencerin zur obersten US-Ärztin</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/stars/liebe-blick-alexandra-maria-lara-sam-riley-40954710" data-separator="top" data-headline="Zwischen Alexandra Maria Lara und Sam Riley war es Liebe auf den ersten Blick" data-teaser-id="40954710">



<article>
<header>
<span>



Seit 15 Jahren verheiratet
</span>
<h3>Zwischen Alexandra Maria Lara und Sam Riley war es Liebe auf den ersten Blick</h3>

</header>



</article>
</a>

</li>
</ul>
</div>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/politik/videos/inland/umfrage-mehrheit-deutschen-haelt-afd-rechtsextrem-40955300" data-visible-in="3col" data-headline="Umfrage: Mehrheit der Deutschen hält AfD für rechtsextrem" data-teaser-id="40955300">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/298/40955298,pd=1,h=170,w=300/umfrage-mehrheit-haelt-afd-rechtsextrem.webp 300w, https://i0.web.de/image/298/40955298,pd=1,h=255,w=450/umfrage-mehrheit-haelt-afd-rechtsextrem.webp 450w, https://i0.web.de/image/298/40955298,pd=1,h=340,w=600/umfrage-mehrheit-haelt-afd-rechtsextrem.webp 600w" sizes="300px">
<img alt="Umfrage: Mehrheit hält AfD für rechtsextrem" fetchpriority="high" src="https://i0.web.de/image/298/40955298,pd=1,h=170,w=300/umfrage-mehrheit-haelt-afd-rechtsextrem.jpg" width="300" height="170">
</picture>




<figcaption>

<div data-component="icon">























<svg width="20" height="20" viewBox="0 0 20 20">
<path d="M16.76,10.74,4.08,17.89a.85.85,0,0,1-1.16-.33.87.87,0,0,1-.11-.41V2.85A.86.86,0,0,1,3.67,2a.84.84,0,0,1,.41.11L16.76,9.26a.85.85,0,0,1,.32,1.16A.82.82,0,0,1,16.76,10.74Z"/>
</svg>



</div>


</figcaption>
</figure>

<article>
<header>
<span>



Anders als AfD-Anhänger selbst
</span>
<h3>Umfrage: Mehrheit der Deutschen hält AfD für rechtsextrem</h3>

</header>


<footer>
<span>vor 3 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/sport/fussball/bundesliga/vereinen-sandro-wagner-kurs-stehen-40955746" data-visible-in="2col" data-headline="Die Wagner-Gerüchte werden heißer" data-teaser-id="40955746">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/748/40955748,pd=3,h=170,w=300/sandro-wagner.webp 300w, https://i0.web.de/image/748/40955748,pd=3,h=255,w=450/sandro-wagner.webp 450w, https://i0.web.de/image/748/40955748,pd=3,h=340,w=600/sandro-wagner.webp 600w" sizes="300px">
<img alt="Sandro Wagner" fetchpriority="high" src="https://i0.web.de/image/748/40955748,pd=3,h=170,w=300/sandro-wagner.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Vom DFB in die Bundesliga
</span>
<h3>Die Wagner-Gerüchte werden heißer</h3>

</header>


<footer>
<span>vor 44 Minuten</span>


</footer>
</article>
</a>

<div data-component="list" data-visible-in="2col">


<ul>
<li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/ratgeber/finanzen-verbraucher/abzocke-einreisegenehmigung-thailand-40914184" data-separator="top" data-headline="Vorsicht: Abzocke mit neuer Einreisegenehmigung für Thailand" data-teaser-id="40914184">



<article>
<header>
<span>



Verbraucher
</span>
<h3>Vorsicht: Abzocke mit neuer Einreisegenehmigung für Thailand</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/sport/fussball/bundesliga/fc-bayern/ex-teamkollege-gosens-lockt-bayern-star-mueller-italien-40955010" data-separator="top" data-headline="Ex-Teamkollege lockt Müller nach Italien" data-teaser-id="40955010">



<article>
<header>
<span>



&quot;Toskana ist sehr schön&quot;
</span>
<h3>Ex-Teamkollege lockt Müller nach Italien</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/politik/videos/russland-krieg-ukraine/jd-vance-attackiert-kreml-forderungen-friedensverhandlungen-40955652" data-separator="top" data-headline="JD Vance attackiert Kreml-Forderungen bei Friedensverhandlungen" data-teaser-id="40955652">



<article>
<header>
<span>

<label data-color="grey">Video</label>

Trump zeigt sich ahnungslos
</span>
<h3>JD Vance attackiert Kreml-Forderungen bei Friedensverhandlungen</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">


<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/musik/schlager/patricia-kelly-erklaert-jugendsuende-40955494" data-separator="top" data-headline="Patricia Kelly erklärt ihre Jugendsünde" data-teaser-id="40955494">



<article>
<header>
<span>



Vor 25 Jahren Auto demoliert
</span>
<h3>Patricia Kelly erklärt ihre Jugendsünde</h3>

</header>



</article>
</a>

</li>
</ul>
</div>

</section>

<section data-layout-columns="4col" data-layout-name="teasers" data-name="Mobilfunk" data-tr-component-path="Mobilfunk" data-tracking-name="fourWithText">

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/sport/mehr-sport/schreck-wm-tischtennis-hoffnung-annett-kaufmann-training-verletzt-40953574" data-visible-in="5col" data-headline="Schreck vor WM: Tischtennis-Hoffnung Kaufmann im Training verletzt" data-teaser-id="40953574">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/196/40955196,pd=1,h=170,w=300.webp 300w, https://i0.web.de/image/196/40955196,pd=1,h=255,w=450.webp 450w, https://i0.web.de/image/196/40955196,pd=1,h=340,w=600.webp 600w" sizes="300px">
<img alt="" fetchpriority="high" src="https://i0.web.de/image/196/40955196,pd=1,h=170,w=300.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Diagnose steht bereits fest
</span>
<h3>Schreck vor WM: Tischtennis-Hoffnung Kaufmann im Training verletzt</h3>

</header>


<footer>
<span>vor 4 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/panorama/oefen-schornstein-entsteht-rauchsignal-40955244" data-visible-in="5col" data-headline="Zwei Öfen, ein Schornstein: Wie entsteht das Rauchsignal?" data-teaser-id="40955244">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/246/40955246,pd=4,h=170,w=300/schornstein-dach-sixtinischen-kapelle.webp 300w, https://i0.web.de/image/246/40955246,pd=4,h=255,w=450/schornstein-dach-sixtinischen-kapelle.webp 450w, https://i0.web.de/image/246/40955246,pd=4,h=340,w=600/schornstein-dach-sixtinischen-kapelle.webp 600w" sizes="300px">
<img alt="Der Schornstein auf dem Dach der Sixtinischen Kapelle" fetchpriority="high" src="https://i0.web.de/image/246/40955246,pd=4,h=170,w=300/schornstein-dach-sixtinischen-kapelle.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Zeichen aus dem Vatikan
</span>
<h3>Zwei Öfen, ein Schornstein: Wie entsteht das Rauchsignal?</h3>

</header>


<footer>
<span>vor 4 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/wissen/geschichte/zeitzeugin-schaemen-deutsche-40951372" data-visible-in="4col" data-headline="Zeitzeugin: &quot;Jetzt muss ich mich schämen, dass ich eine Deutsche bin&quot;" data-teaser-id="40951372">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/382/40951382,pd=3,h=170,w=300/kapitualationserklaerung-zweiten-weltkriegs-europa.webp 300w, https://i0.web.de/image/382/40951382,pd=3,h=255,w=450/kapitualationserklaerung-zweiten-weltkriegs-europa.webp 450w, https://i0.web.de/image/382/40951382,pd=3,h=340,w=600/kapitualationserklaerung-zweiten-weltkriegs-europa.webp 600w" sizes="300px">
<img alt="Kapitualationserklärung, Ende des Zweiten Weltkriegs in Europa" fetchpriority="high" src="https://i0.web.de/image/382/40951382,pd=3,h=170,w=300/kapitualationserklaerung-zweiten-weltkriegs-europa.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Kriegsende vor 80 Jahren
</span>
<h3>Zeitzeugin: &quot;Jetzt muss ich mich schämen, dass ich eine Deutsche bin&quot;</h3>

</header>


<footer>
<span>vor 6 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/politik/russland-krieg-ukraine/feuerpause-ukraine-russland-melden-angriffe-40954986" data-visible-in="4col" data-headline="Doch keine Feuerpause? Ukraine und Russland melden Angriffe" data-teaser-id="40954986">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/322/40955322,pd=1,h=170,w=300.webp 300w, https://i0.web.de/image/322/40955322,pd=1,h=255,w=450.webp 450w, https://i0.web.de/image/322/40955322,pd=1,h=340,w=600.webp 600w" sizes="300px">
<img alt="" fetchpriority="high" src="https://i0.web.de/image/322/40955322,pd=1,h=170,w=300.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Krieg in der Ukraine
</span>
<h3>Doch keine Feuerpause? Ukraine und Russland melden Angriffe</h3>

</header>


<footer>
<span>vor 4 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/musik/3-doors-down-frontmann-brad-arnold-krebs-endstadium-40955440" data-visible-in="3col" data-headline="&quot;3 Doors Down&quot;-Frontmann hat Krebs im Endstadium" data-teaser-id="40955440">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/448/40955448,pd=1,h=170,w=300/brad-arnold.webp 300w, https://i0.web.de/image/448/40955448,pd=1,h=255,w=450/brad-arnold.webp 450w, https://i0.web.de/image/448/40955448,pd=1,h=340,w=600/brad-arnold.webp 600w" sizes="300px">
<img alt="Brad Arnold" fetchpriority="high" src="https://i0.web.de/image/448/40955448,pd=1,h=170,w=300/brad-arnold.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Tour abgesagt
</span>
<h3>&quot;3 Doors Down&quot;-Frontmann hat Krebs im Endstadium</h3>

</header>


<footer>
<span>vor 2 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/wissen/geschichte/zeitzeugin-schaemen-deutsche-40951372" data-visible-in="3col" data-headline="Zeitzeugin: &quot;Jetzt muss ich mich schämen, dass ich eine Deutsche bin&quot;" data-teaser-id="40951372">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/382/40951382,pd=3,h=170,w=300/kapitualationserklaerung-zweiten-weltkriegs-europa.webp 300w, https://i0.web.de/image/382/40951382,pd=3,h=255,w=450/kapitualationserklaerung-zweiten-weltkriegs-europa.webp 450w, https://i0.web.de/image/382/40951382,pd=3,h=340,w=600/kapitualationserklaerung-zweiten-weltkriegs-europa.webp 600w" sizes="300px">
<img alt="Kapitualationserklärung, Ende des Zweiten Weltkriegs in Europa" fetchpriority="high" src="https://i0.web.de/image/382/40951382,pd=3,h=170,w=300/kapitualationserklaerung-zweiten-weltkriegs-europa.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Kriegsende vor 80 Jahren
</span>
<h3>Zeitzeugin: &quot;Jetzt muss ich mich schämen, dass ich eine Deutsche bin&quot;</h3>

</header>


<footer>
<span>vor 6 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/panorama/sexuelle-gewalt-minderjaehrige-bleibt-weltweit-ungeloestes-problem-40955308" data-visible-in="2col" data-headline="Sexuelle Gewalt gegen Minderjährige bleibt weltweit ungelöstes Problem" data-teaser-id="40955308">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/380/40955380,pd=2,h=170,w=300/illustration-gewalt-kindern.webp 300w, https://i0.web.de/image/380/40955380,pd=2,h=255,w=450/illustration-gewalt-kindern.webp 450w, https://i0.web.de/image/380/40955380,pd=2,h=340,w=600/illustration-gewalt-kindern.webp 600w" sizes="300px">
<img alt="Illustration - Gewalt an Kindern" fetchpriority="high" src="https://i0.web.de/image/380/40955380,pd=2,h=170,w=300/illustration-gewalt-kindern.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Globale Studie veröffentlicht
</span>
<h3>Sexuelle Gewalt gegen Minderjährige bleibt weltweit ungelöstes Problem</h3>

</header>


<footer>
<span>vor 2 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/politik/us-politik/trump-ernennt-influencerin-obersten-us-aerztin-40955112" data-visible-in="2col" data-headline="Trump ernennt Influencerin zur obersten US-Ärztin" data-teaser-id="40955112">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/472/40955472,pd=2,h=170,w=300/bildkombo-donald-trumpcasey-means.webp 300w, https://i0.web.de/image/472/40955472,pd=2,h=255,w=450/bildkombo-donald-trumpcasey-means.webp 450w, https://i0.web.de/image/472/40955472,pd=2,h=340,w=600/bildkombo-donald-trumpcasey-means.webp 600w" sizes="300px">
<img alt="Bildkombo: Donald Trump/Casey Means" fetchpriority="high" src="https://i0.web.de/image/472/40955472,pd=2,h=170,w=300/bildkombo-donald-trumpcasey-means.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Entscheidung nach Protest
</span>
<h3>Trump ernennt Influencerin zur obersten US-Ärztin</h3>

</header>


<footer>
<span>vor 4 Stunden</span>


</footer>
</article>
</a>

<div data-service-slot="recobox_1" data-tr-component-path="recobox_1" data-visible-in="3,4,5"></div>

<div data-service-slot="recobox_2" data-tr-component-path="recobox_2" data-visible-in="4,5"></div>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/stars/kylie-jenner-timothee-chalamet-erstmals-rotem-teppich-paar-40954604" data-visible-in="5col" data-headline="Erster gemeinsamer Red-Carpet-Auftritt von Kylie Jenner und Timothée Chalamet" data-teaser-id="40954604">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/606/40954606,pd=1,h=170,w=300/italien-kylie-jenner-timothee-chalamet-schaulaufen.webp 300w, https://i0.web.de/image/606/40954606,pd=1,h=255,w=450/italien-kylie-jenner-timothee-chalamet-schaulaufen.webp 450w, https://i0.web.de/image/606/40954606,pd=1,h=340,w=600/italien-kylie-jenner-timothee-chalamet-schaulaufen.webp 600w" sizes="300px">
<img alt="In Italien: Kylie Jenner und Timothée Chalamet beim ihrem ersten Schaulaufen als Paar für die ..." fetchpriority="high" src="https://i0.web.de/image/606/40954606,pd=1,h=170,w=300/italien-kylie-jenner-timothee-chalamet-schaulaufen.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Kaum gemeinsame Auftritte
</span>
<h3>Erster gemeinsamer Red-Carpet-Auftritt von Kylie Jenner und Timothée Chalamet</h3>

</header>


<footer>
<span>vor 4 Stunden</span>


</footer>
</article>
</a>

</section>

<div data-component="block-navigation" data-grid-row="" data-tracking-name="channelHeader" data-name="Politik" data-tr-component-path="Politik">
<h2 data-tr-component-path="titleChannelHeader">
<a href="https://web.de/magazine/politik/">Politik</a>
</h2>
<nav>
<ul>
<li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/politik/inland/">Innenpolitik</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/politik/us-politik/">US-Politik</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/politik/russland-krieg-ukraine/">Krieg gegen die Ukraine</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/politik/politische-talkshows/">Politische Talkshows</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/news/">Weitere News</a>
</li>
</ul>
</nav>

</div>

<section data-layout-columns="4col" data-layout-name="fiveBigLeft" data-name="Politik" data-tr-component-path="Politik" data-tracking-name="fiveBig">

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/politik/schusswechsel-indien-pakistan-grenze-40956044" data-headline="Schusswechsel zwischen Indien und Pakistan an der Grenze" data-teaser-id="40956044">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/178/40956178,pd=2,h=360,w=630.webp 630w, https://i0.web.de/image/178/40956178,pd=2,h=540,w=945.webp 945w, https://i0.web.de/image/178/40956178,pd=2,h=720,w=1260.webp 1260w" sizes="630px">
<img alt="" loading="lazy" src="https://i0.web.de/image/178/40956178,pd=2,h=360,w=630.jpg" width="630" height="360">
</picture>





</figure>

<article>
<header>
<span>



Neue Eskalation
</span>
<h3>Schusswechsel zwischen Indien und Pakistan an der Grenze</h3>

</header>
<p>Im Konflikt zwischen den Atommächten ist keine Entspannung in Sicht. Indien meldet Artilleriefeuer, Pakistan den Abschuss indischer Drohnen.</p>

<footer>
<span>vor 14 Minuten</span>


</footer>
</article>
</a>

<div data-service-slot="box_3" data-tr-component-path="box_3"></div>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/politik/inland/regeln-grenzen-40954282" data-headline="Neue Regeln an den Grenzen" data-teaser-id="40954282">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/338/40954338,pd=3,h=170,w=300/ausweitung-grenzkontrollen-deutschland.webp 300w, https://i0.web.de/image/338/40954338,pd=3,h=255,w=450/ausweitung-grenzkontrollen-deutschland.webp 450w, https://i0.web.de/image/338/40954338,pd=3,h=340,w=600/ausweitung-grenzkontrollen-deutschland.webp 600w" sizes="300px">
<img alt="Ausweitung der Grenzkontrollen in Deutschland" loading="lazy" src="https://i0.web.de/image/338/40954338,pd=3,h=170,w=300/ausweitung-grenzkontrollen-deutschland.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Unerlaubte Einreise
</span>
<h3>Neue Regeln an den Grenzen</h3>

</header>


<footer>
<span>vor 2 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/wirtschaft/trump-verspricht-bedeutendes-handelsabkommen-40954928" data-headline="Trump verspricht &quot;bedeutendes Handelsabkommen&quot;" data-teaser-id="40954928">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/930/40954930,pd=4,h=170,w=300/us-praesident-trump.webp 300w, https://i0.web.de/image/930/40954930,pd=4,h=255,w=450/us-praesident-trump.webp 450w, https://i0.web.de/image/930/40954930,pd=4,h=340,w=600/us-praesident-trump.webp 600w" sizes="300px">
<img alt="US-Präsident Trump" loading="lazy" src="https://i0.web.de/image/930/40954930,pd=4,h=170,w=300/us-praesident-trump.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Post auf Truth Social
</span>
<h3>Trump verspricht &quot;bedeutendes Handelsabkommen&quot;</h3>

</header>


<footer>
<span>vor 5 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/politik/videos/dutzende-palaestinensische-aktivisten-elite-uni-festgenommen-40955818" data-headline="Dutzende pro-palästinensische Aktivisten an Elite-Uni festgenommen" data-teaser-id="40955818">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/820/40955820,pd=1,h=170,w=300/columbia-university-palaestinensische-demonstratio.webp 300w, https://i0.web.de/image/820/40955820,pd=1,h=255,w=450/columbia-university-palaestinensische-demonstratio.webp 450w, https://i0.web.de/image/820/40955820,pd=1,h=340,w=600/columbia-university-palaestinensische-demonstratio.webp 600w" sizes="300px">
<img alt="Columbia University: Erneut pro-palästinensische Demonstration" loading="lazy" src="https://i0.web.de/image/820/40955820,pd=1,h=170,w=300/columbia-university-palaestinensische-demonstratio.jpg" width="300" height="170">
</picture>




<figcaption>

<div data-component="icon">























<svg width="20" height="20" viewBox="0 0 20 20">
<path d="M16.76,10.74,4.08,17.89a.85.85,0,0,1-1.16-.33.87.87,0,0,1-.11-.41V2.85A.86.86,0,0,1,3.67,2a.84.84,0,0,1,.41.11L16.76,9.26a.85.85,0,0,1,.32,1.16A.82.82,0,0,1,16.76,10.74Z"/>
</svg>



</div>


</figcaption>
</figure>

<article>
<header>
<span>



Erneut Proteste an Columbia
</span>
<h3>Dutzende pro-palästinensische Aktivisten an Elite-Uni festgenommen</h3>

</header>


<footer>
<span>vor 41 Minuten</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/politik/inland/weltkrieg-gedenken-beginnt-gottesdienst-40956006" data-headline="Weltkrieg-Gedenken beginnt mit Gottesdienst" data-teaser-id="40956006">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/008/40956008,pd=2,h=170,w=300/80-jahrestag-zweiter-weltkrieg-gottesdienst.webp 300w, https://i0.web.de/image/008/40956008,pd=2,h=255,w=450/80-jahrestag-zweiter-weltkrieg-gottesdienst.webp 450w, https://i0.web.de/image/008/40956008,pd=2,h=340,w=600/80-jahrestag-zweiter-weltkrieg-gottesdienst.webp 600w" sizes="300px">
<img alt="80. Jahrestag Ende Zweiter Weltkrieg – Gottesdienst" loading="lazy" src="https://i0.web.de/image/008/40956008,pd=2,h=170,w=300/80-jahrestag-zweiter-weltkrieg-gottesdienst.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Inland
</span>
<h3>Weltkrieg-Gedenken beginnt mit Gottesdienst</h3>

</header>


<footer>
<span>vor 51 Minuten</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/politik/videos/us-vize-gegenueber-europa-versoehnlich-40955888" data-headline="US-Vize gibt sich gegenüber Europa versöhnlich" data-teaser-id="40955888">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/890/40955890,pd=1,h=170,w=300.webp 300w, https://i0.web.de/image/890/40955890,pd=1,h=255,w=450.webp 450w, https://i0.web.de/image/890/40955890,pd=1,h=340,w=600.webp 600w" sizes="300px">
<img alt="" loading="lazy" src="https://i0.web.de/image/890/40955890,pd=1,h=170,w=300.jpg" width="300" height="170">
</picture>




<figcaption>

<div data-component="icon">























<svg width="20" height="20" viewBox="0 0 20 20">
<path d="M16.76,10.74,4.08,17.89a.85.85,0,0,1-1.16-.33.87.87,0,0,1-.11-.41V2.85A.86.86,0,0,1,3.67,2a.84.84,0,0,1,.41.11L16.76,9.26a.85.85,0,0,1,.32,1.16A.82.82,0,0,1,16.76,10.74Z"/>
</svg>



</div>


</figcaption>
</figure>

<article>
<header>
<span>



Schmeichelnde Worte
</span>
<h3>US-Vize gibt sich gegenüber Europa versöhnlich</h3>

</header>


<footer>
<span>vor 59 Minuten</span>


</footer>
</article>
</a>

</section>

<div data-component="block-navigation" data-grid-row="" data-tracking-name="channelHeader" data-name="Unterhaltung" data-tr-component-path="Unterhaltung">
<h2 data-tr-component-path="titleChannelHeader">
<a href="https://web.de/magazine/unterhaltung/">Unterhaltung</a>
</h2>
<nav>
<ul>
<li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/unterhaltung/stars/">Stars</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/unterhaltung/tv-shows/">TV-Shows</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/unterhaltung/musik/schlager/">Schlager</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/unterhaltung/adel/">Adel</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/unterhaltung/tv-shows/germanys-next-topmodel/">GNTM 2025</a>
</li>
</ul>
</nav>

</div>

<section data-layout-columns="4col" data-layout-name="fiveBigLeft" data-name="Unterhaltung" data-tr-component-path="Unterhaltung" data-tracking-name="fiveBig">

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/stars/mutmasslicher-stalker-jennifer-aniston-angeklagt-40955048" data-headline="Mutmaßlicher Stalker von Jennifer Aniston angeklagt" data-teaser-id="40955048">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/094/40955094,pd=1,h=360,w=630/jennifer-aniston.webp 630w, https://i0.web.de/image/094/40955094,pd=1,h=540,w=945/jennifer-aniston.webp 945w, https://i0.web.de/image/094/40955094,pd=1,h=720,w=1260/jennifer-aniston.webp 1260w" sizes="630px">
<img alt="Jennifer Aniston" loading="lazy" src="https://i0.web.de/image/094/40955094,pd=1,h=360,w=630/jennifer-aniston.jpg" width="630" height="360">
</picture>





</figure>

<article>
<header>
<span>



Belästigt sie seit Jahren
</span>
<h3>Mutmaßlicher Stalker von Jennifer Aniston angeklagt</h3>

</header>
<p>In Los Angeles wurde nun ein Mann angeklagt, der die Schauspielerin Jennifer Aniston seit über zwei Jahren stalken soll. Als er ihre Villa beschädigte, konnte der Angeklagte festgenommen werden.</p>

<footer>
<span>vor 5 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/stars/enrique-iglesias-50-grosses-idol-vater-40955254" data-headline="Enrique Iglesias wird 50: Sein großes Idol war nicht sein berühmter Vater" data-teaser-id="40955254">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/256/40955256,pd=1,h=170,w=300/enrique-iglesias-weiss-fans-begeistern.webp 300w, https://i0.web.de/image/256/40955256,pd=1,h=255,w=450/enrique-iglesias-weiss-fans-begeistern.webp 450w, https://i0.web.de/image/256/40955256,pd=1,h=340,w=600/enrique-iglesias-weiss-fans-begeistern.webp 600w" sizes="300px">
<img alt="Enrique Iglesias weiß seine Fans noch immer zu begeistern." loading="lazy" src="https://i0.web.de/image/256/40955256,pd=1,h=170,w=300/enrique-iglesias-weiss-fans-begeistern.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



&quot;Ich werde nie in Rente gehen&quot;
</span>
<h3>Enrique Iglesias wird 50: Sein großes Idol war nicht sein berühmter Vater</h3>

</header>


<footer>
<span>vor 4 Stunden</span>


</footer>
</article>
</a>

<div data-service-slot="box_4" data-tr-component-path="box_4"></div>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/stars/liam-paynes-ex-freundin-cheryl-cole-verwaltet-millionenerbe-40955228" data-headline="Liam Paynes Ex-Freundin verwaltet sein Millionenerbe" data-teaser-id="40955228">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/230/40955230,pd=3,h=170,w=300/liam-payne-cheryl-cole-2016-2018-paar-gemeinsamen-.webp 300w, https://i0.web.de/image/230/40955230,pd=3,h=255,w=450/liam-payne-cheryl-cole-2016-2018-paar-gemeinsamen-.webp 450w, https://i0.web.de/image/230/40955230,pd=3,h=340,w=600/liam-payne-cheryl-cole-2016-2018-paar-gemeinsamen-.webp 600w" sizes="300px">
<img alt="Liam Payne und Cheryl Cole waren von 2016 bis 2018 ein Paar und haben einen gemeinsamen Sohn." loading="lazy" src="https://i0.web.de/image/230/40955230,pd=3,h=170,w=300/liam-payne-cheryl-cole-2016-2018-paar-gemeinsamen-.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Verstorbener Sänger
</span>
<h3>Liam Paynes Ex-Freundin verwaltet sein Millionenerbe</h3>

</header>


<footer>
<span>vor 4 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/stars/jennifer-aniston-angreifer-jahre-lang-belaestigt-40956134" data-headline="Jennifer Aniston: Angreifer soll sie zwei Jahre lang belästigt haben" data-teaser-id="40956134">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/136/40956136,pd=1,h=170,w=300/jennifer-aniston-offenbar-ziel-mutmasslichen-stalk.webp 300w, https://i0.web.de/image/136/40956136,pd=1,h=255,w=450/jennifer-aniston-offenbar-ziel-mutmasslichen-stalk.webp 450w, https://i0.web.de/image/136/40956136,pd=1,h=340,w=600/jennifer-aniston-offenbar-ziel-mutmasslichen-stalk.webp 600w" sizes="300px">
<img alt="Jennifer Aniston wurde offenbar Ziel eines mutmaßlichen Stalkers." loading="lazy" src="https://i0.web.de/image/136/40956136,pd=1,h=170,w=300/jennifer-aniston-offenbar-ziel-mutmasslichen-stalk.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Stars
</span>
<h3>Jennifer Aniston: Angreifer soll sie zwei Jahre lang belästigt haben</h3>

</header>


<footer>
<span>vor 26 Minuten</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/stars/sex-sylvie-meis-ueberrascht-intimen-gestaendnissen-40956070" data-headline="Sex mit einer Frau? Sylvie Meis überrascht mit intimen Geständnissen" data-teaser-id="40956070">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/072/40956072,pd=1,h=170,w=300/moderatorin-werbegesicht-sylvie-meis-ueberrascht-p.webp 300w, https://i0.web.de/image/072/40956072,pd=1,h=255,w=450/moderatorin-werbegesicht-sylvie-meis-ueberrascht-p.webp 450w, https://i0.web.de/image/072/40956072,pd=1,h=340,w=600/moderatorin-werbegesicht-sylvie-meis-ueberrascht-p.webp 600w" sizes="300px">
<img alt="Moderatorin und Werbegesicht Sylvie Meis überrascht im &quot;Playboy&quot;-Interview mit intimen ..." loading="lazy" src="https://i0.web.de/image/072/40956072,pd=1,h=170,w=300/moderatorin-werbegesicht-sylvie-meis-ueberrascht-p.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Stars
</span>
<h3>Sex mit einer Frau? Sylvie Meis überrascht mit intimen Geständnissen</h3>

</header>


<footer>
<span>vor 34 Minuten</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/filme-serien-kino/sneaks-tritt-grossen-fussstapfen-cars-toy-story-40955988" data-headline="&quot;Sneaks&quot; tritt in die großen Fußstapfen von &quot;Cars&quot; und &quot;Toy Story&quot;" data-teaser-id="40955988">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/990/40955990,pd=1,h=170,w=300/sneaks-dreht-schuh-geschwisterpaar-ty-maxine.webp 300w, https://i0.web.de/image/990/40955990,pd=1,h=255,w=450/sneaks-dreht-schuh-geschwisterpaar-ty-maxine.webp 450w, https://i0.web.de/image/990/40955990,pd=1,h=340,w=600/sneaks-dreht-schuh-geschwisterpaar-ty-maxine.webp 600w" sizes="300px">
<img alt="&quot;Sneaks&quot; dreht sich um das Schuh-Geschwisterpaar Ty und Maxine." loading="lazy" src="https://i0.web.de/image/990/40955990,pd=1,h=170,w=300/sneaks-dreht-schuh-geschwisterpaar-ty-maxine.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Filme und Serien
</span>
<h3>&quot;Sneaks&quot; tritt in die großen Fußstapfen von &quot;Cars&quot; und &quot;Toy Story&quot;</h3>

</header>


<footer>
<span>vor 52 Minuten</span>


</footer>
</article>
</a>

</section>

<div data-component="block-navigation" data-grid-row="" data-tracking-name="channelHeader" data-background="blue" data-name="Service" data-tr-component-path="Service">
<h2 data-tr-component-path="titleChannelHeader">
<a href="https://web.de/magazine/services/">Services im Überblick</a>
</h2>
<nav>
<ul>
<li data-tr-component-path="optionChannelHeader">
<a href="https://route.web.de/">Routenplaner</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/reise/feiertage/">Gesetzliche Feiertage</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/reise/ferientermine/">Schulferien</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/gesundheit/bmi-rechner/">BMI-Rechner</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/wetter">Wetter</a>
</li>
</ul>
</nav>

</div>

<section data-layout-columns="4col" data-layout-name="teasers" data-background="blue" data-name="Service_A" data-tr-component-path="Service_A" data-tracking-name="fourBullets">

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/lifestyle/horoskop/" data-headline="So stehen Ihre Sterne heute! Horoskop für alle Sternzeichen" data-teaser-id="34266178">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/278/34340278,pd=3,h=170,w=300.webp 300w, https://i0.web.de/image/278/34340278,pd=3,h=255,w=450.webp 450w, https://i0.web.de/image/278/34340278,pd=3,h=340,w=600.webp 600w" sizes="300px">
<img alt="" loading="lazy" src="https://i0.web.de/image/278/34340278,pd=3,h=170,w=300.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Horoskope
</span>
<h3>So stehen Ihre Sterne heute! Horoskop für alle Sternzeichen</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://lotto.web.de/eurojackpot?partnerId=1WEHOMHPMD&amp;advertisementId=4000000000000000EUROJACKPO00020NI1234567891" data-headline="Knacken Sie den Eurojackpot einfach online mit Ihrem Tipp!" data-teaser-id="38517020">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/912/38528912,pd=3,h=170,w=300.webp 300w, https://i0.web.de/image/912/38528912,pd=3,h=255,w=450.webp 450w, https://i0.web.de/image/912/38528912,pd=3,h=340,w=600.webp 600w" sizes="300px">
<img alt="" loading="lazy" src="https://i0.web.de/image/912/38528912,pd=3,h=170,w=300.jpg" width="300" height="170">
</picture>



<figcaption class="innerText" data-product="euroJackpot">
<span class="bothJackpotText">
120
<span class="jackpot2">MIO. €</span>
</span>
<span class="chance">Chance 1:140 Mio.</span>
</figcaption>


<figcaption data-position="bottom">

<span>Ab 18. Glücksspielsucht. Hilfe unter buwei.de.<br/>Vermittler gem. Whitelist. Ein Service von LOTTO24.</span>
</figcaption>
</figure>

<article>
<header>
<span>



Eurojackpot
</span>
<h3>Knacken Sie den Eurojackpot einfach online mit Ihrem Tipp!</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/regio/" data-headline="Hier finden Sie alle Nachrichten aus Ihrer Region." data-teaser-id="38366044">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/556/38420556,pd=3,h=170,w=300/nachrichten-bundesland.webp 300w, https://i0.web.de/image/556/38420556,pd=3,h=255,w=450/nachrichten-bundesland.webp 450w, https://i0.web.de/image/556/38420556,pd=3,h=340,w=600/nachrichten-bundesland.webp 600w" sizes="300px">
<img alt="Hier finden Sie alle Nachrichten aus Ihrem Bundesland" loading="lazy" src="https://i0.web.de/image/556/38420556,pd=3,h=170,w=300/nachrichten-bundesland.png" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Regionale Nachrichten
</span>
<h3>Hier finden Sie alle Nachrichten aus Ihrer Region.</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://millionenklick.web.de/#C0101041109010101" data-headline="Ihre tägliche Millionen-Chance und das kostenlos!" data-teaser-id="37145150">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/132/37145132,pd=5,h=170,w=300/taegliche-millionen-chance-kostenlos.webp 300w, https://i0.web.de/image/132/37145132,pd=5,h=255,w=450/taegliche-millionen-chance-kostenlos.webp 450w, https://i0.web.de/image/132/37145132,pd=5,h=340,w=600/taegliche-millionen-chance-kostenlos.webp 600w" sizes="300px">
<img alt="Ihre tägliche Millionen-Chance und das kostenlos!" loading="lazy" src="https://i0.web.de/image/132/37145132,pd=5,h=170,w=300/taegliche-millionen-chance-kostenlos.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



MillionenKlick
</span>
<h3>Ihre tägliche Millionen-Chance und das kostenlos!</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://route.web.de/" data-headline="Kostenloser Service für Ihre Reiseplanung - europaweit" data-teaser-id="34273258">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/270/34340270,pd=3,h=170,w=300.webp 300w, https://i0.web.de/image/270/34340270,pd=3,h=255,w=450.webp 450w, https://i0.web.de/image/270/34340270,pd=3,h=340,w=600.webp 600w" sizes="300px">
<img alt="" loading="lazy" src="https://i0.web.de/image/270/34340270,pd=3,h=170,w=300.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Routenplaner
</span>
<h3>Kostenloser Service für Ihre Reiseplanung - europaweit</h3>

</header>



</article>
</a>

</section>

<section data-layout-columns="fullCol" data-layout-name="weather" data-background="blue" data-name="Service_B" data-tr-component-path="Service_B" data-tracking-name="fourBullets">

<hp-weather>
<div data-component="weather" type="hp-weather">
<div class="weatherHeadline">
<h2>Wetter -
Berlin
</h2>
<span><a href="https://web.de/wetter/">Nicht ihr Ort?</a></span>
</div>
<div class="weatherDate">Donnerstag 08.05.</div>
<a class="weatherInfo" href="https://web.de/wetter/">
<div class="big">
<div data-component="icon">
<svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 64 64">
<path fill="#D8E6F6" stroke="#FFFFFF" stroke-width="3" stroke-miterlimit="10"
d="M38.2,15.5h-0.6c-0.4-3-3.3-6.2-6.9-6.2c-1.9,0-3.7,0.6-4.9,1.9C24.3,8,21.4,5.8,18,5.8c-4.8,0-8.7,4.4-8.7,9.9c0,0.1,0,0.2,0,0.3C7.5,17,6.2,19,6.2,21.3c0,3.4,2.9,6.2,6.4,6.2h25.6c3.5,0,6.4-2.6,6.4-6C44.5,18.1,41.7,15.5,38.2,15.5z"/>
<g display="none">
<g display="inline">
<path fill="#F8CA3D"
d="M24.9,2.1c-9.4,0-17,7.6-17,17c0,9.4,7.6,17,17,17c9.4,0,17-7.6,17-17C41.9,9.7,34.3,2.1,24.9,2.1z"/>
</g>
<g display="inline">
<path fill="none" stroke="#FFFFFF" stroke-width="3" stroke-miterlimit="10"
d="M24.9,2.1c-9.4,0-17,7.6-17,17c0,9.4,7.6,17,17,17c9.4,0,17-7.6,17-17C41.9,9.7,34.3,2.1,24.9,2.1z"/>
</g>
</g>
<path fill="#D8E6F6" stroke="#FFFFFF" stroke-width="3" stroke-miterlimit="10"
d="M55.4,29.8c0-0.1,0-0.3,0-0.4c0-8-5.7-14.5-12.7-14.5c-4.9,0-9.2,3.2-11.3,7.9c-1.8-1.8-4.4-1.4-7.2-1.4c-5.2,0-9.5,5.2-10,10.2h-0.9c-5.2,0-9.4,4-9.4,9c0,5,4.2,9,9.4,9h37.4C55.9,49.5,60,44,60,39C60,35.7,58.2,31.4,55.4,29.8z"/>
</svg>
</div>
<div class="bigInfo">Max.
<span class="bigText">15<sup>°C</sup></span>
<span class="description">Stark bewölkt</span>
</div>
</div>
<div class="small">
Morgens
<div data-component="icon">
<svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 64 64">
<path fill="#B7BCC1" stroke="#FFFFFF" stroke-width="3" stroke-miterlimit="10"
d="M38.2,15.5h-0.6c-0.4-3-3.3-6.2-6.9-6.2c-1.9,0-3.7,0.6-4.9,1.9C24.3,8,21.4,5.8,18,5.8c-4.8,0-8.7,4.4-8.7,9.9c0,0.1,0,0.2,0,0.3C7.5,17,6.2,19,6.2,21.3c0,3.4,2.9,6.2,6.4,6.2h25.6c3.5,0,6.4-2.6,6.4-6C44.5,18.1,41.7,15.5,38.2,15.5z"/>
<path fill="#B7BCC1" stroke="#FFFFFF" stroke-width="3" stroke-miterlimit="10"
d="M55.4,29.8c0-0.1,0-0.3,0-0.4c0-8-5.7-14.5-12.7-14.5c-4.9,0-9.2,3.2-11.3,7.9c-1.8-1.8-4.4-1.4-7.2-1.4c-5.2,0-9.5,5.2-10,10.2h-0.9c-5.2,0-9.4,4-9.4,9c0,5,4.2,9,9.4,9h37.4C55.9,49.5,60,44,60,39C60,35.7,58.2,31.4,55.4,29.8z"/>
</svg>
</div>
<span class="description">9°C</span>
</div>
<div class="small">
Mittags
<div data-component="icon">
<svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 64 64">
<path fill="#D8E6F6" stroke="#FFFFFF" stroke-width="3" stroke-miterlimit="10"
d="M38.2,15.5h-0.6c-0.4-3-3.3-6.2-6.9-6.2c-1.9,0-3.7,0.6-4.9,1.9C24.3,8,21.4,5.8,18,5.8c-4.8,0-8.7,4.4-8.7,9.9c0,0.1,0,0.2,0,0.3C7.5,17,6.2,19,6.2,21.3c0,3.4,2.9,6.2,6.4,6.2h25.6c3.5,0,6.4-2.6,6.4-6C44.5,18.1,41.7,15.5,38.2,15.5z"/>
<g display="none">
<g display="inline">
<path fill="#F8CA3D"
d="M24.9,2.1c-9.4,0-17,7.6-17,17c0,9.4,7.6,17,17,17c9.4,0,17-7.6,17-17C41.9,9.7,34.3,2.1,24.9,2.1z"/>
</g>
<g display="inline">
<path fill="none" stroke="#FFFFFF" stroke-width="3" stroke-miterlimit="10"
d="M24.9,2.1c-9.4,0-17,7.6-17,17c0,9.4,7.6,17,17,17c9.4,0,17-7.6,17-17C41.9,9.7,34.3,2.1,24.9,2.1z"/>
</g>
</g>
<path fill="#D8E6F6" stroke="#FFFFFF" stroke-width="3" stroke-miterlimit="10"
d="M55.4,29.8c0-0.1,0-0.3,0-0.4c0-8-5.7-14.5-12.7-14.5c-4.9,0-9.2,3.2-11.3,7.9c-1.8-1.8-4.4-1.4-7.2-1.4c-5.2,0-9.5,5.2-10,10.2h-0.9c-5.2,0-9.4,4-9.4,9c0,5,4.2,9,9.4,9h37.4C55.9,49.5,60,44,60,39C60,35.7,58.2,31.4,55.4,29.8z"/>
</svg>
</div>
<span class="description">15°C</span>
</div>
<div class="small">
Abends
<div data-component="icon">
<svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 64 64">
<path fill="#D8E6F6" stroke="#FFFFFF" stroke-width="3" stroke-miterlimit="10"
d="M38.2,15.5h-0.6c-0.4-3-3.3-6.2-6.9-6.2c-1.9,0-3.7,0.6-4.9,1.9C24.3,8,21.4,5.8,18,5.8c-4.8,0-8.7,4.4-8.7,9.9c0,0.1,0,0.2,0,0.3C7.5,17,6.2,19,6.2,21.3c0,3.4,2.9,6.2,6.4,6.2h25.6c3.5,0,6.4-2.6,6.4-6C44.5,18.1,41.7,15.5,38.2,15.5z"/>
<g display="none">
<g display="inline">
<path fill="#F8CA3D"
d="M24.9,2.1c-9.4,0-17,7.6-17,17c0,9.4,7.6,17,17,17c9.4,0,17-7.6,17-17C41.9,9.7,34.3,2.1,24.9,2.1z"/>
</g>
<g display="inline">
<path fill="none" stroke="#FFFFFF" stroke-width="3" stroke-miterlimit="10"
d="M24.9,2.1c-9.4,0-17,7.6-17,17c0,9.4,7.6,17,17,17c9.4,0,17-7.6,17-17C41.9,9.7,34.3,2.1,24.9,2.1z"/>
</g>
</g>
<path fill="#D8E6F6" stroke="#FFFFFF" stroke-width="3" stroke-miterlimit="10"
d="M55.4,29.8c0-0.1,0-0.3,0-0.4c0-8-5.7-14.5-12.7-14.5c-4.9,0-9.2,3.2-11.3,7.9c-1.8-1.8-4.4-1.4-7.2-1.4c-5.2,0-9.5,5.2-10,10.2h-0.9c-5.2,0-9.4,4-9.4,9c0,5,4.2,9,9.4,9h37.4C55.9,49.5,60,44,60,39C60,35.7,58.2,31.4,55.4,29.8z"/>
</svg>
</div>
<span class="description">12°C</span>
</div>
<div class="small">
Nachts
<div data-component="icon">
<svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 64 64">
<path fill="#D8E6F6" stroke="#FFFFFF" stroke-width="3" stroke-miterlimit="10"
d="M55.4,29.8c0-0.1,0-0.3,0-0.4c0-8-5.7-14.5-12.7-14.5c-4.9,0-9.2,3.2-11.3,7.9c-1.8-1.8-4.4-1.4-7.2-1.4c-5.2,0-9.5,5.2-10,10.2h-0.9c-5.2,0-9.4,4-9.4,9c0,5,4.2,9,9.4,9h37.4C55.9,49.5,60,44,60,39C60,35.7,58.2,31.4,55.4,29.8z"/>
<path fill="#F8CA3D" stroke="#FFFFFF" stroke-width="3" stroke-miterlimit="10"
d="M24,19.5c0-7.1,3.7-13.4,9.2-17c-1.2-0.2-2.4-0.3-3.6-0.3c-11.2,0-20.4,9.1-20.4,20.4c0,11.2,9.1,20.4,20.4,20.4c4.1,0,8-1.2,11.2-3.3C31.2,37.8,24,29.5,24,19.5z"/>
</svg>
</div>
<span class="description">9°C</span>
</div>
</a>
<div>
<a data-component="button" data-importance="ghost" data-size="l" href="https://web.de/wetter/">Mehr zum Wetter</a>
</div>
</div>
</hp-weather>





















</section>

<div data-component="block-navigation" data-grid-row="" data-tracking-name="channelHeader" data-name="Sport" data-tr-component-path="Sport">
<h2 data-tr-component-path="titleChannelHeader">
<a href="https://web.de/magazine/sport/">Sport</a>
</h2>
<nav>
<ul>
<li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/sport/fussball/">Fußball</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/sport/fussball/bundesliga/">Bundesliga</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/sport/basketball/">Basketball</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/sport/tennis/">Tennis</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/sport/formel-1/">Formel 1</a>
</li>
</ul>
</nav>

</div>

<section data-layout-columns="4col" data-layout-name="fiveBigLeft" data-name="Sport" data-tr-component-path="Sport" data-tracking-name="fiveBig">

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/sport/fussball/champions-league/psg-keeper-verteilt-seitenhieb-mbappe-40955546" data-headline="PSG-Keeper verteilt kleinen Seitenhieb an Mbappé" data-teaser-id="40955546">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/564/40955564,pd=1,h=360,w=630.webp 630w, https://i0.web.de/image/564/40955564,pd=1,h=540,w=945.webp 945w, https://i0.web.de/image/564/40955564,pd=1,h=720,w=1260.webp 1260w" sizes="630px">
<img alt="" loading="lazy" src="https://i0.web.de/image/564/40955564,pd=1,h=360,w=630.jpg" width="630" height="360">
</picture>





</figure>

<article>
<header>
<span>



CL-Finale ohne Superstars
</span>
<h3>PSG-Keeper verteilt kleinen Seitenhieb an Mbappé</h3>

</header>
<p>Bei Paris Saint-Germain läuft es so richtig – und das ohne die ganz großen Superstars. Torwart Gianluigi Donnarumma erklärt das Geheimnis und kann sich dabei einen kleinen Seitenhieb gegen Ex-Pariser Kylian Mbappé nicht verkneifen.</p>

<footer>
<span>vor 37 Minuten</span>


</footer>
</article>
</a>

<div data-service-slot="box_5" data-tr-component-path="box_5"></div>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/sport/fussball/bundesliga/fc-bayern/fc-bayern-vincent-kompany-irrer-flugeinlage-bayern-training-40956050" data-headline="Kompany mit irrer Flugeinlage im Training" data-teaser-id="40956050">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/158/40956158,pd=1,h=170,w=300/vincent-kompany.webp 300w, https://i0.web.de/image/158/40956158,pd=1,h=255,w=450/vincent-kompany.webp 450w, https://i0.web.de/image/158/40956158,pd=1,h=340,w=600/vincent-kompany.webp 600w" sizes="300px">
<img alt="Vincent Kompany" loading="lazy" src="https://i0.web.de/image/158/40956158,pd=1,h=170,w=300/vincent-kompany.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



FC Bayern
</span>
<h3>Kompany mit irrer Flugeinlage im Training</h3>

</header>


<footer>
<span>vor 14 Minuten</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/sport/fussball/2-liga/zweitliga-trainer-fliegt-regensburg-trennt-patz-40956052" data-headline="Der Nächste, bitte! Weiterer Zweitliga-Trainer fliegt" data-teaser-id="40956052">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/054/40956054,pd=2,h=170,w=300/andreas-patz.webp 300w, https://i0.web.de/image/054/40956054,pd=2,h=255,w=450/andreas-patz.webp 450w, https://i0.web.de/image/054/40956054,pd=2,h=340,w=600/andreas-patz.webp 600w" sizes="300px">
<img alt="Andreas Patz" loading="lazy" src="https://i0.web.de/image/054/40956054,pd=2,h=170,w=300/andreas-patz.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Irrsinn im Saisonendspurt
</span>
<h3>Der Nächste, bitte! Weiterer Zweitliga-Trainer fliegt</h3>

</header>


<footer>
<span>vor 12 Minuten</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/sport/fussball/bundesliga/fc-bayern/rolle-bayern-patron-uli-hoeness-wirtz-poker-spielt-40952138" data-headline="Welche Rolle Hoeneß im Wirtz-Poker spielt" data-teaser-id="40952138">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/310/40952310,pd=1,h=170,w=300/uli-hoeness.webp 300w, https://i0.web.de/image/310/40952310,pd=1,h=255,w=450/uli-hoeness.webp 450w, https://i0.web.de/image/310/40952310,pd=1,h=340,w=600/uli-hoeness.webp 600w" sizes="300px">
<img alt="Uli Hoeneß" loading="lazy" src="https://i0.web.de/image/310/40952310,pd=1,h=170,w=300/uli-hoeness.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>
<label>Analyse</label>


Bayerns Wunschspieler
</span>
<h3>Welche Rolle Hoeneß im Wirtz-Poker spielt</h3>

</header>


<footer>
<span>vor 1 Stunde</span>
<span>von Michael Schleicher</span>

</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/sport/fussball/bundesliga/wechsel-fc-bayern-spricht-wirtz-zukunft-40955368" data-headline="Jetzt spricht Wirtz über seine Zukunft" data-teaser-id="40955368">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/370/40955370,pd=3,h=170,w=300/sc-freiburg-bayer-leverkusen.webp 300w, https://i0.web.de/image/370/40955370,pd=3,h=255,w=450/sc-freiburg-bayer-leverkusen.webp 450w, https://i0.web.de/image/370/40955370,pd=3,h=340,w=600/sc-freiburg-bayer-leverkusen.webp 600w" sizes="300px">
<img alt="SC Freiburg - Bayer Leverkusen" loading="lazy" src="https://i0.web.de/image/370/40955370,pd=3,h=170,w=300/sc-freiburg-bayer-leverkusen.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Wechsel zum FCB?
</span>
<h3>Jetzt spricht Wirtz über seine Zukunft</h3>

</header>


<footer>
<span>vor 25 Minuten</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/sport/fussball/bundesliga/gladbach-profi-cvancara-schiesst-verein-40953978" data-headline="Gladbach-Profi schießt gegen eigenen Verein" data-teaser-id="40953978">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/980/40953980,pd=2,h=170,w=300/borussia-moenchengladbach.webp 300w, https://i0.web.de/image/980/40953980,pd=2,h=255,w=450/borussia-moenchengladbach.webp 450w, https://i0.web.de/image/980/40953980,pd=2,h=340,w=600/borussia-moenchengladbach.webp 600w" sizes="300px">
<img alt="Borussia Mönchengladbach" loading="lazy" src="https://i0.web.de/image/980/40953980,pd=2,h=170,w=300/borussia-moenchengladbach.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



&quot;Versprechungen nicht erfüllt&quot;
</span>
<h3>Gladbach-Profi schießt gegen eigenen Verein</h3>

</header>


<footer>
<span>vor 49 Minuten</span>


</footer>
</article>
</a>

</section>

<div data-component="block-navigation" data-grid-row="" data-tracking-name="channelHeader" data-name="Games" data-tr-component-path="Games">
<h2 data-tr-component-path="titleChannelHeader">
<a href="https://games.web.de?mc=05578265">Games</a>
</h2>
<nav>
<ul>
<li data-tr-component-path="optionChannelHeader">
<a href="https://games.web.de/events/solitaire-spiele">Solitaire Spiele</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://games.web.de/jackpot-spiele?mc=05578267">Jackpot-Spiele</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://games.web.de/strategie?mc=05578268">Strategie</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://games.web.de/simulation?mc=05578269">Simulation</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://games.web.de/pausen-spiele?mc=05578266">Pausen-Spiele</a>
</li>
</ul>
</nav>

</div>

<section data-layout-columns="4col" data-layout-name="sliderWithList" data-name="Games" data-tr-component-path="Games" data-tracking-name="oneList">

<hp-slider v-slot="{ goTo, goPrev, goNext }" data-component="slider" :interval="5000" :animation-type="&#039;lefttoright&#039;" data-animation-type="lefttoright">


<span data-part="arrow-prev" @click="goPrev">
<div data-component="icon">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
<span data-part="arrow-next" @click="goNext">
<div data-component="icon">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>

<div data-wrapper>
<div>

<a data-component="teaser" type="hp-teaser" href="https://games.web.de/jackpot-spiele/mary-vegas?mc=05577054" data-headline="Mary Vegas" data-article-overlay="bottomleft">

<figure>


<img alt="Mary Vegas Teaser Grafik Eine elegante Frau steht im Abendkleid vor Casinos und einer Slotmachine. Im Hintergrund sind die schillernden und bunten Lichter von Las Vegas sowie Hochhäuser und ein leuchtendes Riesenrad." loading="lazy" src="https://img.ui-portal.de/games/spiele/Jackpotde/MaryVegas/MaryVegas_HP.jpg" width="960" height="540">




</figure>

<article>
<header>
<span>



Das kostenlose Online-Casino
</span>
<h3>Mary Vegas</h3>

</header>
<p>Du liebst die schillernde und abenteuerliche Welt von Las Vegas? Dann spiele jetzt Mary Vegas, teste dein Casino Glück und knacke ganz nebenbei den neuen Jackpot!</p>


</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://games.web.de/simulation/my-little-farmies?mc=05577054" data-headline="My Little Farmies" data-article-overlay="bottomleft">

<figure>


<img alt="My Little Farmies Frühlingsgrafik Katze in einer magischen Welt Frühlingsgefühle" loading="lazy" src="https://img.ui-portal.de/games/spiele/Upjers/MY_Little_Farmies/Event/2025/02_Fruehling/MLF_960x540.jpg" width="960" height="540">



<figcaption data-position="top" data-color="accent">

<span>Tägliche Geschenke zum Muttertag bis 11. Mai!</span>
</figcaption>
</figure>

<article>
<header>
<span>



Jeden Tag eine neue Überraschung zum Muttertag – nur bis 11. Mai!
</span>
<h3>My Little Farmies</h3>

</header>
<p>Muttertags-Special! Bis zum 11. Mai erwartet dich jeden Tag eine tolle kostenlose Überraschung! Schnapp sie dir jetzt und freue dich auf Tage voller Liebe und Farmspaß!</p>


</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://games.web.de/jackpot-spiele/golden-ei-of-moorhuhn?mc=05577054" data-headline="Golden Ei of Moorhuhn" data-article-overlay="bottomleft">

<figure>


<img alt="Golden Ei von Moorhuhn Casino Spiel Hero Grafik. Das kultige Moorhuhn hat ein Pharao Outfit an und steht neben einer antiken Slot Machine. Im Hintergrund ist die Wüste aus dem Alten Ägypten abgebildet." loading="lazy" src="https://img.ui-portal.de/games/spiele/Jackpotde/GoldenEi/Homepagemodul/golden_egg_morhuhn_960x540_homepagemodul.jpg" width="960" height="540">




</figure>

<article>
<header>
<span>



Vergolden Sie sich den Tag!
</span>
<h3>Golden Ei of Moorhuhn</h3>

</header>
<p>Helfe dem kultigen Moorhuhn bei seinem Abenteuer im alten Ägypten! Finde das &quot;Goldene Ei&quot; und knacke dabei nebenher auch gleich den Jackpot!</p>


</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://games.web.de/simulation/zoo-2-animal-park?mc=05577054" data-headline="Zoo2: Animal Park" data-article-overlay="bottomleft">

<figure>


<img alt="Zoo2 Animal Park Teaser Grafik für das Muttertagsevent mit Reh Pferd Tieren auf einer Zoo Wiese" loading="lazy" src="https://img.ui-portal.de/games/spiele/Upjers/Zoo2_Animal-Park/Hompagemodul/zoo2_Homepagemodul_960x540.jpg" width="960" height="540">



<figcaption data-position="top" data-color="accent">

<span>Muttertags-Special bis 15. Mai</span>
</figcaption>
</figure>

<article>
<header>
<span>



Event: Sammle Kronen und tausche sie gegen Geschenke bis zum 14. Mai!
</span>
<h3>Zoo2: Animal Park</h3>

</header>
<p>Sammle exklusive Muttertags-Deko und sichere dir das exklusive Schleswiger Kaltblut! Gestalte deinen Zoo, verdiene funkelnde Kronen und hol dir Belohnungen!</p>


</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://games.web.de/jackpot-spiele/the-dog-house?mc=05577054" data-headline="The Dog House" data-article-overlay="bottomleft">

<figure>


<img alt="The Dog House Jackpot Game Teaser Bild. Drei Hunde verschiedener Rassen , darunter ein Mops, ein Kampfhund und ein knuffiger Cesar Hunde mit Schleife auf dem Kopf stehen auf einer grünen und großen Wiese. Eine Abbildung aus der Slot Machine" loading="lazy" src="https://img.ui-portal.de/games/spiele/Jackpotde/the-dog-house/the-dog-house-hp-3.jpg" width="960" height="540">




</figure>

<article>
<header>
<span>



Tierischer Spielspaß!
</span>
<h3>The Dog House</h3>

</header>
<p>Trete ein in die tierische Videoslot Machine. Gewinne mit Hilfe der goldigen Hunden eine Menge Chips und teste dein Ihr Glück beim knacken des Jackpots!</p>


</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://games.web.de/strategie/iron-order?mc=05577054" data-headline="Iron Order" data-article-overlay="bottomleft">

<figure>


<img alt="Verschiedene Mechs vor einer Europakarte" loading="lazy" src="https://img.ui-portal.de/games/spiele/bytro/iron-order/iron-order-hp-2.jpg" width="960" height="540">




</figure>

<article>
<header>
<span>



Mech Echtzeit-Strategie
</span>
<h3>Iron Order</h3>

</header>
<p>Echtzeit-Strategie: In Multiplayer Partien mit bis zu 32 Spielern bist du gefragt, deine Strategie weise zu planen und deine Mechs zum Sieg zu führen.</p>


</article>
</a>

</div>
</div>
</hp-slider>

<div data-component="list">
<h3>Top Games</h3>
<ol>
<li data-tr-component-path="list">
<span>1</span>

<a data-component="teaser" type="hp-teaser" href="https://games.web.de/strategie/iron-order?mc=01551342" data-separator="top" data-headline="Zeige dein Geschick beim neuen Strategie-Game!">



<article>
<header>
<span>



Iron Order
</span>
<h3>Zeige dein Geschick beim neuen Strategie-Game!</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">
<span>2</span>

<a data-component="teaser" type="hp-teaser" href="https://games.web.de/simulation/my-little-farmies?mc=01551342" data-separator="top" data-headline="Zum Muttertag gibt es jeden Tag ein tolles gratis Geschenk!">



<article>
<header>
<span>
<label data-color="accent">Bis 11. Mai!</label>


My Little Farmies
</span>
<h3>Zum Muttertag gibt es jeden Tag ein tolles gratis Geschenk!</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">
<span>3</span>

<a data-component="teaser" type="hp-teaser" href="https://games.web.de/jackpot-spiele/golden-ei-of-moorhuhn?mc=01551342" data-separator="top" data-headline="Knacke zusammen mit dem Moorhuhn den Jackpot!">



<article>
<header>
<span>



Golden Ei of Moorhuhn
</span>
<h3>Knacke zusammen mit dem Moorhuhn den Jackpot!</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">
<span>4</span>

<a data-component="teaser" type="hp-teaser" href="https://games.web.de/strategie/forge-of-empires?mc=01551342" data-separator="top" data-headline="Entwickle dein eigenes Imperium in Forge of Empires!">



<article>
<header>
<span>



Forge of Empires
</span>
<h3>Entwickle dein eigenes Imperium in Forge of Empires!</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">
<span>5</span>

<a data-component="teaser" type="hp-teaser" href="https://games.web.de/simulation/zoo-2-animal-park?mc=01551342" data-separator="top" data-headline="Erhalte bis 15. Mai das exklusive Schleswiger Kaltblut!">



<article>
<header>
<span>
<label data-color="accent">Neues Event</label>


Zoo2: Animal Park
</span>
<h3>Erhalte bis 15. Mai das exklusive Schleswiger Kaltblut!</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">
<span>6</span>

<a data-component="teaser" type="hp-teaser" href="https://games.web.de/jackpot-spiele?mc=01551342" data-separator="top" data-headline="Schaffst du es, den neuen Frühlings-Jackpot zu knacken?">



<article>
<header>
<span>
<label data-color="accent">Frühlings-Jackpot</label>


Frühlings Jackpot
</span>
<h3>Schaffst du es, den neuen Frühlings-Jackpot zu knacken?</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">
<span>7</span>

<a data-component="teaser" type="hp-teaser" href="https://games.web.de/jackpot-spiele/stickers?mc=01551342" data-separator="top" data-headline="Schaffst du es, alle neuen seltenen Sticker zu sammeln?">



<article>
<header>
<span>



Sticker-Sammel-Spaß
</span>
<h3>Schaffst du es, alle neuen seltenen Sticker zu sammeln?</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">
<span>8</span>

<a data-component="teaser" type="hp-teaser" href="https://games.web.de/simulation/wurzelimperium-2?mc=01551342" data-separator="top" data-headline="Falle in Nostalgie mit dem 2. Teil des Kult-Games: Wurzelimperium 2">



<article>
<header>
<span>



Wurzelimperium 2
</span>
<h3>Falle in Nostalgie mit dem 2. Teil des Kult-Games: Wurzelimperium 2</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">
<span>9</span>

<a data-component="teaser" type="hp-teaser" href="https://games.web.de/jackpot-spiele/wer-wird-millionar?mc=01551342" data-separator="top" data-headline="Teste dein Glück bei der neuen Wer-wird-Millionär-Slot!">



<article>
<header>
<span>



Wer wird Millionär?
</span>
<h3>Teste dein Glück bei der neuen Wer-wird-Millionär-Slot!</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">
<span>10</span>

<a data-component="teaser" type="hp-teaser" href="https://games.web.de/jackpot-spiele/bounty-bot?mc=01551342" data-separator="top" data-headline="Die neue Autocollect-Funktion hilft dir, keine Preise zu verpassen!">



<article>
<header>
<span>



Bounty Bot
</span>
<h3>Die neue Autocollect-Funktion hilft dir, keine Preise zu verpassen!</h3>

</header>



</article>
</a>

</li>
</ol>

</div>

</section>

<div data-component="block-navigation" data-grid-row="" data-tracking-name="channelHeader" data-name="Panorama" data-tr-component-path="Panorama">
<h2 data-tr-component-path="titleChannelHeader">
<a href="https://web.de/magazine/panorama/">Panorama</a>
</h2>
<nav>
<ul>
<li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/wetter/">Wetter aktuell</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/regio/">Regionales</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/panorama/lotto/">Lotto-Gewinnzahlen</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/panorama/thema/">Panorama A-Z</a>
</li>
</ul>
</nav>

</div>

<section data-layout-columns="4col" data-layout-name="fiveBigLeft" data-name="Panorama" data-tr-component-path="Panorama" data-tracking-name="fiveBig">

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/panorama/gaeste-sterben-familienessen-gastgeberin-mordes-angeklagt-40952172" data-headline="Drei Gäste sterben nach Familienessen - Gastgeberin wegen Mordes angeklagt" data-teaser-id="40952172">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/296/40952296,pd=1,h=360,w=630.webp 630w, https://i0.web.de/image/296/40952296,pd=1,h=540,w=945.webp 945w, https://i0.web.de/image/296/40952296,pd=1,h=720,w=1260.webp 1260w" sizes="630px">
<img alt="" loading="lazy" src="https://i0.web.de/image/296/40952296,pd=1,h=360,w=630.jpg" width="630" height="360">
</picture>





</figure>

<article>
<header>
<span>



Mordprozess in Australien
</span>
<h3>Drei Gäste sterben nach Familienessen - Gastgeberin wegen Mordes angeklagt</h3>

</header>
<p>Im Prozess um ein tödliches Familienessen in Australien schildert ein Arzt die letzten Stunden der Opfer – und zitiert eine tragische Aussage. Die Angeklagte beteuert weiter ihre Unschuld.</p>

<footer>
<span>vor 39 Minuten</span>


</footer>
</article>
</a>

<div data-service-slot="box_6" data-tr-component-path="box_6"></div>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/panorama/glueckspilz-gewinnt-knapp-millionen-euro-eurojackpot-40953646" data-headline="Eurojackpot: Glückspilz gewinnt knapp sechs Millionen Euro" data-teaser-id="40953646">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/766/40951766,pd=2,h=170,w=300/millionengewinn-eurojackpot.webp 300w, https://i0.web.de/image/766/40951766,pd=2,h=255,w=450/millionengewinn-eurojackpot.webp 450w, https://i0.web.de/image/766/40951766,pd=2,h=340,w=600/millionengewinn-eurojackpot.webp 600w" sizes="300px">
<img alt="Millionengewinn im Eurojackpot" loading="lazy" src="https://i0.web.de/image/766/40951766,pd=2,h=170,w=300/millionengewinn-eurojackpot.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Millionengewinn
</span>
<h3>Eurojackpot: Glückspilz gewinnt knapp sechs Millionen Euro</h3>

</header>


<footer>
<span>vor 56 Minuten</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/panorama/geier-vergiftungsfall-suedlichen-afrika-123-tiere-getoetet-40955970" data-headline="Geier-Vergiftungsfall im südlichen Afrika: 123 Tiere getötet" data-teaser-id="40955970">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/972/40955972,pd=1,h=170,w=300/geier-afrika-getoetet.webp 300w, https://i0.web.de/image/972/40955972,pd=1,h=255,w=450/geier-afrika-getoetet.webp 450w, https://i0.web.de/image/972/40955972,pd=1,h=340,w=600/geier-afrika-getoetet.webp 600w" sizes="300px">
<img alt="Geier in Afrika getötet" loading="lazy" src="https://i0.web.de/image/972/40955972,pd=1,h=170,w=300/geier-afrika-getoetet.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Panorama
</span>
<h3>Geier-Vergiftungsfall im südlichen Afrika: 123 Tiere getötet</h3>

</header>


<footer>
<span>vor 56 Minuten</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/panorama/sexueller-missbrauch-bistum-speyer-studie-strukturell-40955866" data-headline="Sexueller Missbrauch im Bistum Speyer laut Studie &quot;strukturell&quot;" data-teaser-id="40955866">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/868/40955868,pd=1,h=170,w=300/dom-speyer.webp 300w, https://i0.web.de/image/868/40955868,pd=1,h=255,w=450/dom-speyer.webp 450w, https://i0.web.de/image/868/40955868,pd=1,h=340,w=600/dom-speyer.webp 600w" sizes="300px">
<img alt="Dom zu Speyer" loading="lazy" src="https://i0.web.de/image/868/40955868,pd=1,h=170,w=300/dom-speyer.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Zwischenbericht
</span>
<h3>Sexueller Missbrauch im Bistum Speyer laut Studie &quot;strukturell&quot;</h3>

</header>


<footer>
<span>vor 58 Minuten</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/panorama/videos/legendaeren-us-stadt-golfcarts-offiziell-erlaubt-40955668" data-headline="In dieser legendären US-Stadt sind Golfcarts jetzt offiziell erlaubt" data-teaser-id="40955668">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/664/40955664,pd=2,h=170,w=300/buggy-strasse-us-stadt-golfcarts-offiziell-erlaubt.webp 300w, https://i0.web.de/image/664/40955664,pd=2,h=255,w=450/buggy-strasse-us-stadt-golfcarts-offiziell-erlaubt.webp 450w, https://i0.web.de/image/664/40955664,pd=2,h=340,w=600/buggy-strasse-us-stadt-golfcarts-offiziell-erlaubt.webp 600w" sizes="300px">
<img alt="Mit dem Buggy auf die Straße – in dieser US-Stadt sind Golfcarts jetzt offiziell erlaubt" loading="lazy" src="https://i0.web.de/image/664/40955664,pd=2,h=170,w=300/buggy-strasse-us-stadt-golfcarts-offiziell-erlaubt.jpg" width="300" height="170">
</picture>




<figcaption>

<div data-component="icon">























<svg width="20" height="20" viewBox="0 0 20 20">
<path d="M16.76,10.74,4.08,17.89a.85.85,0,0,1-1.16-.33.87.87,0,0,1-.11-.41V2.85A.86.86,0,0,1,3.67,2a.84.84,0,0,1,.41.11L16.76,9.26a.85.85,0,0,1,.32,1.16A.82.82,0,0,1,16.76,10.74Z"/>
</svg>



</div>


</figcaption>
</figure>

<article>
<header>
<span>



Heimat des Speed
</span>
<h3>In dieser legendären US-Stadt sind Golfcarts jetzt offiziell erlaubt</h3>

</header>


<footer>
<span>vor 1 Stunde</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/panorama/sophia-noah-spitze-baby-namensliste-40955696" data-headline="Sophia und Noah weiter Spitze bei Baby-Namensliste" data-teaser-id="40955696">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/698/40955698,pd=1,h=170,w=300/beliebteste-vornamen.webp 300w, https://i0.web.de/image/698/40955698,pd=1,h=255,w=450/beliebteste-vornamen.webp 450w, https://i0.web.de/image/698/40955698,pd=1,h=340,w=600/beliebteste-vornamen.webp 600w" sizes="300px">
<img alt="Beliebteste Vornamen" loading="lazy" src="https://i0.web.de/image/698/40955698,pd=1,h=170,w=300/beliebteste-vornamen.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Panorama
</span>
<h3>Sophia und Noah weiter Spitze bei Baby-Namensliste</h3>

</header>


<footer>
<span>vor 1 Stunde</span>


</footer>
</article>
</a>

</section>

<div data-component="block-navigation" data-grid-row="" data-tracking-name="channelHeader" data-name="EditorialRecommendation" data-tr-component-path="EditorialRecommendation">
<h2 data-tr-component-path="titleChannelHeader">
Das könnte Sie auch interessieren
</h2>


</div>

<section data-layout-columns="4col" data-layout-name="teasers" data-name="EditorialRecommendation" data-tr-component-path="EditorialRecommendation" data-tracking-name="text">

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/stars/schwerer-rueckfall-nico-legat-weist-suchtklinik-40954580" data-separator="top" data-headline="&quot;Schwerer Rückfall&quot;: Nico Legat weist sich selbst in Suchtklinik ein" data-teaser-id="40954580">



<article>
<header>
<span>



Sohn von Thorsten Legat
</span>
<h3>&quot;Schwerer Rückfall&quot;: Nico Legat weist sich selbst in Suchtklinik ein</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/gesundheit/diagnose-patrice-aminati-schuetzen-hautkrebs-40738878" data-separator="top" data-visible-from-up="2col" data-headline="Nach Diagnose bei Patrice Aminati: So schützen Sie sich vor Hautkrebs" data-teaser-id="40738878">



<article>
<header>
<span>



Veränderungen erkennen
</span>
<h3>Nach Diagnose bei Patrice Aminati: So schützen Sie sich vor Hautkrebs</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/ratgeber/kind-familie/muttertag-urspruengliche-bedeutung-verlor-38188702" data-separator="top" data-visible-from-up="3col" data-headline="Sonntag ist Muttertag – die ursprüngliche Idee ist kaum mehr bekannt" data-teaser-id="38188702">



<article>
<header>
<span>



Gesellschaft
</span>
<h3>Sonntag ist Muttertag – die ursprüngliche Idee ist kaum mehr bekannt</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/wissen/tiere/meter-langer-wal-ostsee-travemuende-gesichtet-40951936" data-separator="top" data-visible-from-up="4col" data-headline="Wal in der Ostsee gesichtet - ist es ein bereits bekannter Besucher?" data-teaser-id="40951936">



<article>
<header>
<span>



Verirrter Meeressäuger
</span>
<h3>Wal in der Ostsee gesichtet - ist es ein bereits bekannter Besucher?</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/stars/ex-gntm-kandidatin-anya-elsner-traum-auswandern-40951896" data-separator="top" data-visible-from-up="5col" data-headline="Traum von Ex-Dschungelcamperin endet jäh" data-teaser-id="40951896">



<article>
<header>
<span>



Elsner: &quot;Wird schwer für mich&quot;
</span>
<h3>Traum von Ex-Dschungelcamperin endet jäh</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/sport/eishockey/eishockey-wm-2025-deutschland-spiele-live-free-tv-40951606" data-separator="top" data-headline="So können Sie die Deutschland-Spiele live im TV sehen" data-teaser-id="40951606">



<article>
<header>
<span>



Eishockey-WM
</span>
<h3>So können Sie die Deutschland-Spiele live im TV sehen</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/sport/fussball/bundesliga/fc-bayern/veranlasste-van-gaal-legendaeren-mueller-spruch-40951598" data-separator="top" data-visible-from-up="2col" data-headline="So erklärt Louis van Gaal seinen legendären Müller-Spruch" data-teaser-id="40951598">



<article>
<header>
<span>



Nicht jeder verstand ihn
</span>
<h3>So erklärt Louis van Gaal seinen legendären Müller-Spruch</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/politik/inland/live-blog-aktuelle-umfrage-union-vergroessert-vorsprung-afd-40950984" data-separator="top" data-visible-from-up="3col" data-headline="Umfrage: Union vergrößert Vorsprung auf AfD" data-teaser-id="40950984">



<article>
<header>
<span>



Tag nach der Kanzlerwahl
</span>
<h3>Umfrage: Union vergrößert Vorsprung auf AfD</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/panorama/news-konklave-7-mai-nachlesen-papst-wahl-rom-rauchsignal-erstem-wahlgang-40951522" data-separator="top" data-visible-from-up="4col" data-headline="Papst-Wahl in Rom: Rauchsignal nach erstem Wahlgang" data-teaser-id="40951522">



<article>
<header>
<span>



Erster Tag des Konklave
</span>
<h3>Papst-Wahl in Rom: Rauchsignal nach erstem Wahlgang</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/panorama/lotto-millionaer-lottoschein-meldet-jahr-40951732" data-separator="top" data-visible-from-up="5col" data-headline="Lotto-Millionär findet verlegten Schein - und meldet sich nach einem Jahr" data-teaser-id="40951732">



<article>
<header>
<span>



Monatelang gesucht 
</span>
<h3>Lotto-Millionär findet verlegten Schein - und meldet sich nach einem Jahr</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/ratgeber/haustiere/chihuahua-co-kleinsten-hunderassen-welt-40905590" data-separator="top" data-headline="Das sind die kleinsten Hunderassen der Welt " data-teaser-id="40905590">



<article>
<header>
<span>



Tiere
</span>
<h3>Das sind die kleinsten Hunderassen der Welt </h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/wissen/tiere/collies-perfekten-huetehunden-40947348" data-separator="top" data-visible-from-up="2col" data-headline="Forscher identifizieren &quot;Hütehund-Gene&quot;: Das macht bestimmte Rassen so besonders" data-teaser-id="40947348">



<article>
<header>
<span>



&quot;Bedeutsame&quot; Studie
</span>
<h3>Forscher identifizieren &quot;Hütehund-Gene&quot;: Das macht bestimmte Rassen so besonders</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/ratgeber/haus-garten/geranien-milch-duengen-dran-tipp-40922400" data-separator="top" data-visible-from-up="3col" data-headline="Geranien düngen: Lässt dieses Getränk sie wirklich üppig wachsen?" data-teaser-id="40922400">



<article>
<header>
<span>



Pflanzen
</span>
<h3>Geranien düngen: Lässt dieses Getränk sie wirklich üppig wachsen?</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/ratgeber/haus-garten/regelmaessig-reinigen-dafuer-loch-kuehlschrank-40947948" data-separator="top" data-visible-from-up="4col" data-headline="Diese Aufgabe hat das kleine Loch im Kühlschrank" data-teaser-id="40947948">



<article>
<header>
<span>



Unbedingt regelmäßig reinigen!
</span>
<h3>Diese Aufgabe hat das kleine Loch im Kühlschrank</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/musik/esc/eurovision-song-contest-australien-antreten-36862420" data-separator="top" data-visible-from-up="5col" data-headline="Eurovision Song Contest: Wieso darf Australien teilnehmen?" data-teaser-id="36862420">



<article>
<header>
<span>



Seit zehn Jahren dabei
</span>
<h3>Eurovision Song Contest: Wieso darf Australien teilnehmen?</h3>

</header>



</article>
</a>

</section>

<div data-component="block-navigation" data-grid-row="" data-tracking-name="channelHeader" data-name="WebCent" data-tr-component-path="WebCent">
<h2 data-tr-component-path="titleChannelHeader">
<a href="https://vorteile.web.de/webcent/sammeln/">WEB.Cent Cashback Deals</a>
</h2>
<nav>
<ul>
<li data-tr-component-path="optionChannelHeader">
<a href="https://vorteile.web.de/webcent/sammeln/mode-style/#.hp.int.modul.sl">Fashion</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://vorteile.web.de/webcent/sammeln/technik-multimedia/#.hp.int.modul.sl">Technik</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://vorteile.web.de/webcent/sammeln/finanzen-versicherungen/#.hp.int.modul.sl">Finanzen</a>
</li>
</ul>
</nav>

</div>

<section data-layout-columns="4col" data-layout-name="fiveBigMiddle" data-name="WebCent" data-tr-component-path="WebCent" data-tracking-name="fiveMiddle">

<a data-component="teaser" type="hp-teaser" href="https://vorteile.web.de/webcent/sammeln/shops/ninja/ninja_online/#.hp.int.produktbox.ninja" data-headline="Ninja Creami, Slush-Maschine oder Airfryer jetzt für den Sommer holen und Cashback erhalten">

<figure>


<img alt loading="lazy" src="https://img.ui-portal.de/eigenwerbung/WEB.Cent/Deals/2025/webde_ninja_hpt_m.jpg" width="630" height="360">



<figcaption data-position="top" data-color="webcent">

<span>Bis zu 5 % Cashback</span>
</figcaption>
</figure>

<article>
<header>
<span>



Ninja
</span>
<h3>Ninja Creami, Slush-Maschine oder Airfryer jetzt für den Sommer holen und Cashback erhalten</h3>

</header>
<p></p>


</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://vorteile.web.de/webcent/sammeln/shops/bonprix/bonrix_onlineshop/#.hp.int.produktbox.bonprix" data-headline="Bis zu 40 % im Sale oder neue Bademoden shoppen">

<figure>


<img alt loading="lazy" src="https://img.ui-portal.de/eigenwerbung/WEB.Cent/Deals/2025/webde_bonprix_hpt_s.jpg" width="300" height="170">



<figcaption data-position="top" data-color="webcent">

<span>Bis zu 4 % Cashback</span>
</figcaption>
</figure>

<article>
<header>
<span>



Bonprix
</span>
<h3>Bis zu 40 % im Sale oder neue Bademoden shoppen</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://vorteile.web.de/webcent/sammeln/shops/tchibo/tchibo_onlineshop/#.hp.int.produktbox.tchibo" data-headline="Loungemöbel, Lampen und Spielgeräte - alles für Ihren Garten">

<figure>


<img alt loading="lazy" src="https://img.ui-portal.de/eigenwerbung/WEB.Cent/Deals/2025/webde_tchibo_garten_hpt_s.jpg" width="300" height="170">



<figcaption data-position="top" data-color="webcent">

<span>Bis zu 10 % Cashback</span>
</figcaption>
</figure>

<article>
<header>
<span>



Tchibo
</span>
<h3>Loungemöbel, Lampen und Spielgeräte - alles für Ihren Garten</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://vorteile.web.de/webcent/sammeln/shops/flyingtiger/flyingtiger_online/#.hp.int.produktbox.flyingtiger" data-headline="Jetzt Frühlingsdeko günstig shoppen + Cashback">

<figure>


<img alt loading="lazy" src="https://img.ui-portal.de/eigenwerbung/WEB.Cent/Deals/2025/webde_flyingtiger_a_hpt_s.jpg" width="300" height="170">



<figcaption data-position="top" data-color="webcent">

<span>Bis zu 7 % Cashback</span>
</figcaption>
</figure>

<article>
<header>
<span>



Flying Tiger Copenhagen
</span>
<h3>Jetzt Frühlingsdeko günstig shoppen + Cashback</h3>

</header>



</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://vorteile.web.de/webcent/sammeln/shops/schuhcenter/schuhcenter_onlineshop/#.hp.int.produktbox.schuhcenter" data-headline="Bis zu 50 % Rabatt auf Sneaker im Sale + Cashback">

<figure>


<img alt loading="lazy" src="https://img.ui-portal.de/eigenwerbung/WEB.Cent/Deals/NeueHP/webde_schuhcenter_hpt_s.jpg" width="300" height="170">



<figcaption data-position="top" data-color="webcent">

<span>Bis zu 8 % Cashback</span>
</figcaption>
</figure>

<article>
<header>
<span>



Schuhcenter
</span>
<h3>Bis zu 50 % Rabatt auf Sneaker im Sale + Cashback</h3>

</header>



</article>
</a>

</section>

<div data-component="block-navigation" data-grid-row="" data-tracking-name="channelHeader" data-background="blue" data-name="Lifehacks" data-tr-component-path="Lifehacks">
<h2 data-tr-component-path="titleChannelHeader">
<a href="https://web.de/magazine/ratgeber/lifehacks/">Lifehacks</a>
</h2>


</div>

<section data-layout-columns="4col" data-layout-name="teasers" data-background="blue" data-name="Lifehacks" data-tr-component-path="Lifehacks" data-tracking-name="four">

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/ratgeber/videos/essen-trinken/kiwis-mithilfe-ruehrstabs-schaelen-schneiden-39662610" data-headline="Kiwis mithilfe eines Rührstabs schälen und schneiden" data-teaser-id="39662610">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/612/39662612,pd=2,h=170,w=300/trick-2-1-kiwi-schaelen-portionieren.webp 300w, https://i0.web.de/image/612/39662612,pd=2,h=255,w=450/trick-2-1-kiwi-schaelen-portionieren.webp 450w, https://i0.web.de/image/612/39662612,pd=2,h=340,w=600/trick-2-1-kiwi-schaelen-portionieren.webp 600w" sizes="300px">
<img alt="NICHT NEHMEN! Trick 2 in 1: Kiwi sofort schälen und portionieren
" loading="lazy" src="https://i0.web.de/image/612/39662612,pd=2,h=170,w=300/trick-2-1-kiwi-schaelen-portionieren.jpg" width="300" height="170">
</picture>




<figcaption>

<div data-component="icon">























<svg width="20" height="20" viewBox="0 0 20 20">
<path d="M16.76,10.74,4.08,17.89a.85.85,0,0,1-1.16-.33.87.87,0,0,1-.11-.41V2.85A.86.86,0,0,1,3.67,2a.84.84,0,0,1,.41.11L16.76,9.26a.85.85,0,0,1,.32,1.16A.82.82,0,0,1,16.76,10.74Z"/>
</svg>



</div>


</figcaption>
</figure>

<article>
<header>
<span>



So einfach war es noch nie
</span>
<h3>Kiwis mithilfe eines Rührstabs schälen und schneiden</h3>

</header>


<footer>
<span>vor 3 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/ratgeber/videos/essen-trinken/ueberreife-bananen-probieren-rezept-eckart-hirschhausen-35799794" data-headline="Überreife Bananen? Probieren Sie mal das Rezept von Eckart von Hirschhausen aus" data-teaser-id="35799794">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/796/35799796,pd=2,h=170,w=300/bananeneis-zubereiten.webp 300w, https://i0.web.de/image/796/35799796,pd=2,h=255,w=450/bananeneis-zubereiten.webp 450w, https://i0.web.de/image/796/35799796,pd=2,h=340,w=600/bananeneis-zubereiten.webp 600w" sizes="300px">
<img alt="So einfach können Sie Bananeneis selbst zubereiten." loading="lazy" src="https://i0.web.de/image/796/35799796,pd=2,h=170,w=300/bananeneis-zubereiten.jpg" width="300" height="170">
</picture>




<figcaption>

<div data-component="icon">























<svg width="20" height="20" viewBox="0 0 20 20">
<path d="M16.76,10.74,4.08,17.89a.85.85,0,0,1-1.16-.33.87.87,0,0,1-.11-.41V2.85A.86.86,0,0,1,3.67,2a.84.84,0,0,1,.41.11L16.76,9.26a.85.85,0,0,1,.32,1.16A.82.82,0,0,1,16.76,10.74Z"/>
</svg>



</div>


</figcaption>
</figure>

<article>
<header>
<span>



Bloß nicht wegwerfen!
</span>
<h3>Überreife Bananen? Probieren Sie mal das Rezept von Eckart von Hirschhausen aus</h3>

</header>


<footer>
<span>vor 20 Stunden</span>
<span>von Tamara Haitz</span>

</footer>
</article>
</a>

<div data-service-slot="box_7" data-tr-component-path="box_7" data-visible-in="3,4,5"></div>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/ratgeber/videos/haus-garten/gekleckert-entfernen-kaffeeflecken-37915394" data-headline="Gekleckert? So entfernen Sie Kaffeeflecken wieder" data-teaser-id="37915394">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/152/40947152,pd=1,h=170,w=300/kaffeeflecken-hemd.webp 300w, https://i0.web.de/image/152/40947152,pd=1,h=255,w=450/kaffeeflecken-hemd.webp 450w, https://i0.web.de/image/152/40947152,pd=1,h=340,w=600/kaffeeflecken-hemd.webp 600w" sizes="300px">
<img alt="Frau mit Kaffeeflecken auf dem Hemd" loading="lazy" src="https://i0.web.de/image/152/40947152,pd=1,h=170,w=300/kaffeeflecken-hemd.jpg" width="300" height="170">
</picture>




<figcaption>

<div data-component="icon">























<svg width="20" height="20" viewBox="0 0 20 20">
<path d="M16.76,10.74,4.08,17.89a.85.85,0,0,1-1.16-.33.87.87,0,0,1-.11-.41V2.85A.86.86,0,0,1,3.67,2a.84.84,0,0,1,.41.11L16.76,9.26a.85.85,0,0,1,.32,1.16A.82.82,0,0,1,16.76,10.74Z"/>
</svg>



</div>


</figcaption>
</figure>

<article>
<header>
<span>



Drei einfache Tipps
</span>
<h3>Gekleckert? So entfernen Sie Kaffeeflecken wieder</h3>

</header>


<footer>
<span>vor 2 Tagen</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/ratgeber/videos/essen-trinken/gummibaerchen-tuete-geoeffnet-39910280" data-headline="Haben Sie eine Gummibärchen-Tüte schon mal so geöffnet?" data-teaser-id="39910280">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/924/39915924,pd=1,h=170,w=300/oeffnet-besten-gummibaerchentuete.webp 300w, https://i0.web.de/image/924/39915924,pd=1,h=255,w=450/oeffnet-besten-gummibaerchentuete.webp 450w, https://i0.web.de/image/924/39915924,pd=1,h=340,w=600/oeffnet-besten-gummibaerchentuete.webp 600w" sizes="300px">
<img alt="Wie öffnet man am besten eine Gummibärchentüte? " loading="lazy" src="https://i0.web.de/image/924/39915924,pd=1,h=170,w=300/oeffnet-besten-gummibaerchentuete.jpg" width="300" height="170">
</picture>




<figcaption>

<div data-component="icon">























<svg width="20" height="20" viewBox="0 0 20 20">
<path d="M16.76,10.74,4.08,17.89a.85.85,0,0,1-1.16-.33.87.87,0,0,1-.11-.41V2.85A.86.86,0,0,1,3.67,2a.84.84,0,0,1,.41.11L16.76,9.26a.85.85,0,0,1,.32,1.16A.82.82,0,0,1,16.76,10.74Z"/>
</svg>



</div>


</figcaption>
</figure>

<article>
<header>
<span>



Tüte clever öffnen
</span>
<h3>Haben Sie eine Gummibärchen-Tüte schon mal so geöffnet?</h3>

</header>


<footer>
<span>vor 2 Tagen</span>


</footer>
</article>
</a>

</section>

<div data-component="block-navigation" data-grid-row="" data-tracking-name="channelHeader" data-name="Vorteilswelt" data-tr-component-path="Vorteilswelt">
<h2 data-tr-component-path="titleChannelHeader">
<a href="https://vorteile.web.de/#.homepage.vwSlider.vorteilswelt">Vorteilswelt</a>
</h2>
<nav>
<ul>
<li data-tr-component-path="optionChannelHeader">
<a href="https://vorteile.web.de/software-mobile/#.homepage.vwSlider.internet-mobile">Software &amp; Mobile</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://vorteile.web.de/finanzen/#.homepage.vwSlider.finanzen-versicherung">Finanzen</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://vorteile.web.de/unterhaltung/#.homepage.vwSlider.unterhaltung-lifestyle">Unterhaltung</a>
</li>
</ul>
</nav>

</div>

<section data-layout-columns="4col" data-layout-name="fiveBigMiddle" data-frontend="vorteilswelt" data-name="Vorteilswelt" data-tr-component-path="Vorteilswelt" data-tracking-name="frontend">

<div data-service-slot="slider_1_5" data-tr-component-path="slider_1_5"></div>

<div data-service-slot="slider_1_1" data-tr-component-path="slider_1_1"></div>

<div data-service-slot="slider_1_2" data-tr-component-path="slider_1_2"></div>

<div data-service-slot="slider_1_3" data-tr-component-path="slider_1_3"></div>

<div data-service-slot="slider_1_4" data-tr-component-path="slider_1_4"></div>

</section>

<div data-component="block-navigation" data-grid-row="" data-tracking-name="channelHeader" data-background="blue" data-name="Ratgeber" data-tr-component-path="Ratgeber">
<h2 data-tr-component-path="titleChannelHeader">
<a href="https://web.de/magazine/ratgeber/">Ratgeber</a>
</h2>
<nav>
<ul>
<li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/gesundheit/">Gesundheit &amp; Fitness</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/reise/">Reise</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/ratgeber/finanzen-verbraucher/">Finanzen &amp; Verbraucher</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/ratgeber/essen-trinken/">Essen &amp; Trinken</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/ratgeber/haus-garten/">Haus &amp; Garten</a>
</li>
</ul>
</nav>

</div>

<section data-layout-columns="4col" data-layout-name="fiveBigLeft" data-background="blue" data-name="Ratgeber" data-tr-component-path="Ratgeber" data-tracking-name="fiveBig">

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/ratgeber/finanzen-verbraucher/trinkgeld-deutschen-stadt-gegeizt-40953686" data-headline="Trinkgeld: In dieser deutschen Stadt wird am meisten gegeizt" data-teaser-id="40953686">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/738/40953738,pd=3,h=360,w=630/trinkgeld-deutschland-sumup-koeln.webp 630w, https://i0.web.de/image/738/40953738,pd=3,h=540,w=945/trinkgeld-deutschland-sumup-koeln.webp 945w, https://i0.web.de/image/738/40953738,pd=3,h=720,w=1260/trinkgeld-deutschland-sumup-koeln.webp 1260w" sizes="630px">
<img alt="Trinkgeld, Deutschland, SumUp, Köln" loading="lazy" src="https://i0.web.de/image/738/40953738,pd=3,h=360,w=630/trinkgeld-deutschland-sumup-koeln.jpg" width="630" height="360">
</picture>





</figure>

<article>
<header>
<span>



Digitales Trinkgeld 
</span>
<h3>Trinkgeld: In dieser deutschen Stadt wird am meisten gegeizt</h3>

</header>
<p>Wer im Restaurant, Friseursalon oder Taxi mit dem Service zufrieden war, gibt Trinkgeld. Aber wie viel? Eine aktuelle Auswertung liefert erste Antworten.</p>

<footer>
<span>vor 55 Minuten</span>
<span>von Tanja Ransom</span>

</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/ratgeber/videos/finanzen-verbraucher/angeblich-schwester-telefon-betrugsversuch-40955288" data-headline="Angeblich Schwester am Telefon: Mann aus Seattle berichtet von Betrugsversuch" data-teaser-id="40955288">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/284/40955284,pd=3,h=170,w=300/angeblich-schwester-telefon-seattle-warnt-ki-stimm.webp 300w, https://i0.web.de/image/284/40955284,pd=3,h=255,w=450/angeblich-schwester-telefon-seattle-warnt-ki-stimm.webp 450w, https://i0.web.de/image/284/40955284,pd=3,h=340,w=600/angeblich-schwester-telefon-seattle-warnt-ki-stimm.webp 600w" sizes="300px">
<img alt="Angeblich Schwester am Telefon: Mann aus Seattle warnt vor KI-Stimmen" loading="lazy" src="https://i0.web.de/image/284/40955284,pd=3,h=170,w=300/angeblich-schwester-telefon-seattle-warnt-ki-stimm.jpg" width="300" height="170">
</picture>




<figcaption>

<div data-component="icon">























<svg width="20" height="20" viewBox="0 0 20 20">
<path d="M16.76,10.74,4.08,17.89a.85.85,0,0,1-1.16-.33.87.87,0,0,1-.11-.41V2.85A.86.86,0,0,1,3.67,2a.84.84,0,0,1,.41.11L16.76,9.26a.85.85,0,0,1,.32,1.16A.82.82,0,0,1,16.76,10.74Z"/>
</svg>



</div>


</figcaption>
</figure>

<article>
<header>
<span>



Warnung vor KI-Stimmen
</span>
<h3>Angeblich Schwester am Telefon: Mann aus Seattle berichtet von Betrugsversuch</h3>

</header>


<footer>
<span>vor 4 Stunden</span>


</footer>
</article>
</a>

<div data-service-slot="box_8" data-tr-component-path="box_8"></div>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/ratgeber/videos/haus-garten/bett-morgens-lieber-40953556" data-headline="Sie machen Ihr Bett immer direkt morgens? Das sollten Sie lieber sein lassen" data-teaser-id="40953556">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/720/40955720,pd=1,h=170,w=300.webp 300w, https://i0.web.de/image/720/40955720,pd=1,h=255,w=450.webp 450w, https://i0.web.de/image/720/40955720,pd=1,h=340,w=600.webp 600w" sizes="300px">
<img alt="" loading="lazy" src="https://i0.web.de/image/720/40955720,pd=1,h=170,w=300.jpg" width="300" height="170">
</picture>




<figcaption>

<div data-component="icon">























<svg width="20" height="20" viewBox="0 0 20 20">
<path d="M16.76,10.74,4.08,17.89a.85.85,0,0,1-1.16-.33.87.87,0,0,1-.11-.41V2.85A.86.86,0,0,1,3.67,2a.84.84,0,0,1,.41.11L16.76,9.26a.85.85,0,0,1,.32,1.16A.82.82,0,0,1,16.76,10.74Z"/>
</svg>



</div>


</figcaption>
</figure>

<article>
<header>
<span>



Für eine bessere Hygiene
</span>
<h3>Sie machen Ihr Bett immer direkt morgens? Das sollten Sie lieber sein lassen</h3>

</header>


<footer>
<span>vor 6 Stunden</span>
<span>von Jésula  Thomas</span>

</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/gesundheit/schlaganfall-rechtzeitig-erkennen-frauen-40948608" data-headline="Wie Sie einen Schlaganfall rechtzeitig erkennen – vor allem bei Frauen" data-teaser-id="40948608">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/610/40948610,pd=2,h=170,w=300/schwindelanfall-stuetzt-hauswand.webp 300w, https://i0.web.de/image/610/40948610,pd=2,h=255,w=450/schwindelanfall-stuetzt-hauswand.webp 450w, https://i0.web.de/image/610/40948610,pd=2,h=340,w=600/schwindelanfall-stuetzt-hauswand.webp 600w" sizes="300px">
<img alt="Frau mit Schwindelanfall stützt sich an einer Hauswand ab" loading="lazy" src="https://i0.web.de/image/610/40948610,pd=2,h=170,w=300/schwindelanfall-stuetzt-hauswand.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Oft andere Symptome
</span>
<h3>Wie Sie einen Schlaganfall rechtzeitig erkennen – vor allem bei Frauen</h3>

</header>


<footer>
<span>vor 18 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/ratgeber/videos/kind-familie/beliebtesten-baby-namen-2024-40955862" data-headline="Die beliebtesten Baby-Namen 2024" data-teaser-id="40955862">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/860/40955860,pd=1,h=170,w=300/beliebtesten-baby-namen-spitzenreiter.webp 300w, https://i0.web.de/image/860/40955860,pd=1,h=255,w=450/beliebtesten-baby-namen-spitzenreiter.webp 450w, https://i0.web.de/image/860/40955860,pd=1,h=340,w=600/beliebtesten-baby-namen-spitzenreiter.webp 600w" sizes="300px">
<img alt="Die beliebtesten Baby-Namen: Gibt es neue Spitzenreiter?" loading="lazy" src="https://i0.web.de/image/860/40955860,pd=1,h=170,w=300/beliebtesten-baby-namen-spitzenreiter.jpg" width="300" height="170">
</picture>




<figcaption>

<div data-component="icon">























<svg width="20" height="20" viewBox="0 0 20 20">
<path d="M16.76,10.74,4.08,17.89a.85.85,0,0,1-1.16-.33.87.87,0,0,1-.11-.41V2.85A.86.86,0,0,1,3.67,2a.84.84,0,0,1,.41.11L16.76,9.26a.85.85,0,0,1,.32,1.16A.82.82,0,0,1,16.76,10.74Z"/>
</svg>



</div>


</figcaption>
</figure>

<article>
<header>
<span>



Sophia und Noah
</span>
<h3>Die beliebtesten Baby-Namen 2024</h3>

</header>


<footer>
<span>gerade eben</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/ratgeber/finanzen-verbraucher/gut-deutschen-blackout-gewappnet-40955832" data-headline="Wie gut sind die Deutschen für einen Blackout gewappnet?" data-teaser-id="40955832">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/962/40955962,pd=1,h=170,w=300/familie-isst-dunkeln.webp 300w, https://i0.web.de/image/962/40955962,pd=1,h=255,w=450/familie-isst-dunkeln.webp 450w, https://i0.web.de/image/962/40955962,pd=1,h=340,w=600/familie-isst-dunkeln.webp 600w" sizes="300px">
<img alt="Familie isst im Dunkeln" loading="lazy" src="https://i0.web.de/image/962/40955962,pd=1,h=170,w=300/familie-isst-dunkeln.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Exklusive Umfrage
</span>
<h3>Wie gut sind die Deutschen für einen Blackout gewappnet?</h3>

</header>


<footer>
<span>vor 12 Minuten</span>
<span>von Sophie Bierent</span>

</footer>
</article>
</a>

</section>

<div data-component="block-navigation" data-grid-row="" data-tracking-name="channelHeader" data-name="Wissen" data-tr-component-path="Wissen">
<h2 data-tr-component-path="titleChannelHeader">
<a href="https://web.de/magazine/wissen/">Wissen</a>
</h2>
<nav>
<ul>
<li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/wissen/klima/">Klima</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/wissen/psychologie/">Gesellschaft</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/wissen/geschichte/">Geschichte</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/wissen/natur-umwelt/">Natur</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/wissen/tiere/">Tiere</a>
</li>
</ul>
</nav>

</div>

<section data-layout-columns="4col" data-layout-name="fiveBigLeft" data-name="Wissen" data-tr-component-path="Wissen" data-tracking-name="fiveBig">

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/wissen/tiere/giftfrosch-leo-leggins-forscher-entdecken-art-amazonas-40079526" data-headline="Giftfrosch mit Leo-Leggins: Forscher entdecken neue Art im Amazonas" data-teaser-id="40079526">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/070/40952070,pd=4,h=360,w=630/pfeilgiftfrosch-ranitomeya-aquamarina.webp 630w, https://i0.web.de/image/070/40952070,pd=4,h=540,w=945/pfeilgiftfrosch-ranitomeya-aquamarina.webp 945w, https://i0.web.de/image/070/40952070,pd=4,h=720,w=1260/pfeilgiftfrosch-ranitomeya-aquamarina.webp 1260w" sizes="630px">
<img alt="Pfeilgiftfrosch Ranitomeya aquamarina" loading="lazy" src="https://i0.web.de/image/070/40952070,pd=4,h=360,w=630/pfeilgiftfrosch-ranitomeya-aquamarina.jpg" width="630" height="360">
</picture>




<figcaption>

<div data-component="icon">
























<svg width="20" height="20" viewBox="0 0 20 20">
<rect rx="0.4" height="9.6" width="9.6" y="8.4" x="2" />
<path d="m6,5.2a0.4,0.4 0 1 0 0,0.8l8,0l0,8a0.4,0.4 0 0 0 0.8,0l0,-8.8l-8.8,0z" />
<path d="m9.2,2a0.4,0.4 0 0 0 0,0.8l8,0l0,8a0.4,0.4 0 0 0 0.8,0l0,-8.8l-8.8,0z" />
</svg>


</div>


</figcaption>
</figure>

<article>
<header>
<span>



Er lebt monogam
</span>
<h3>Giftfrosch mit Leo-Leggins: Forscher entdecken neue Art im Amazonas</h3>

</header>
<p>Auf unserem Planeten leben Millionen Tierarten. Von einigen weiß man bis heute nichts. Forschungsteams finden immer wieder bis dato unbekannte Tiere und schaffen es, Bilder von ihnen zu machen. Wir stellen sie vor.</p>

<footer>
<span>vor 1 Stunde</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/wissen/wissenschaft-technik/forscher-genetische-vorteile-extremen-freitauchern-40953474" data-headline="Wissenschaftlerin: &quot;Es ist, als hätten sie eine Art Superkraft&quot;" data-teaser-id="40953474">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/636/40953636,pd=4,h=170,w=300/haenyeo-wasser.webp 300w, https://i0.web.de/image/636/40953636,pd=4,h=255,w=450/haenyeo-wasser.webp 450w, https://i0.web.de/image/636/40953636,pd=4,h=340,w=600/haenyeo-wasser.webp 600w" sizes="300px">
<img alt="Haenyeo unter Wasser" loading="lazy" src="https://i0.web.de/image/636/40953636,pd=4,h=170,w=300/haenyeo-wasser.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Das Geheimnis der Haenyeo
</span>
<h3>Wissenschaftlerin: &quot;Es ist, als hätten sie eine Art Superkraft&quot;</h3>

</header>


<footer>
<span>vor 3 Stunden</span>


</footer>
</article>
</a>

<div data-service-slot="box_9" data-tr-component-path="box_9"></div>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/wissen/videos/tiere/freitaucher-schwimmt-inmitten-haien-40955064" data-headline="Bloß keine falsche Bewegung machen! Freitaucher schwimmt inmitten von Haien" data-teaser-id="40955064">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/156/40955156,pd=1,h=170,w=300/freitaucher-umgeben-haien.webp 300w, https://i0.web.de/image/156/40955156,pd=1,h=255,w=450/freitaucher-umgeben-haien.webp 450w, https://i0.web.de/image/156/40955156,pd=1,h=340,w=600/freitaucher-umgeben-haien.webp 600w" sizes="300px">
<img alt="Freitaucher umgeben von Haien" loading="lazy" src="https://i0.web.de/image/156/40955156,pd=1,h=170,w=300/freitaucher-umgeben-haien.jpg" width="300" height="170">
</picture>




<figcaption>

<div data-component="icon">























<svg width="20" height="20" viewBox="0 0 20 20">
<path d="M16.76,10.74,4.08,17.89a.85.85,0,0,1-1.16-.33.87.87,0,0,1-.11-.41V2.85A.86.86,0,0,1,3.67,2a.84.84,0,0,1,.41.11L16.76,9.26a.85.85,0,0,1,.32,1.16A.82.82,0,0,1,16.76,10.74Z"/>
</svg>



</div>


</figcaption>
</figure>

<article>
<header>
<span>



Nerven wie Drahtseile
</span>
<h3>Bloß keine falsche Bewegung machen! Freitaucher schwimmt inmitten von Haien</h3>

</header>


<footer>
<span>vor 4 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/wissen/klima/forscher-warnen-nordseeinsel-versinken-verurteilt-40952218" data-headline="Forscher warnen: Diese (unbewohnte) Nordseeinsel wird im Meer versinken" data-teaser-id="40952218">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/270/40952270,pd=3,h=170,w=300/memmert.webp 300w, https://i0.web.de/image/270/40952270,pd=3,h=255,w=450/memmert.webp 450w, https://i0.web.de/image/270/40952270,pd=3,h=340,w=600/memmert.webp 600w" sizes="300px">
<img alt="Memmert " loading="lazy" src="https://i0.web.de/image/270/40952270,pd=3,h=170,w=300/memmert.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



In weniger als 100 Jahren
</span>
<h3>Forscher warnen: Diese (unbewohnte) Nordseeinsel wird im Meer versinken</h3>

</header>


<footer>
<span>vor 4 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/wissen/tiere/mallorca-e-kutschen-rollen-alcudia-40955974" data-headline="Mallorca: Erste E-Kutschen rollen durch Alcúdia" data-teaser-id="40955974">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/976/40955976,pd=1,h=170,w=300/mallorca-e-kutschen-rollen-alcudia.webp 300w, https://i0.web.de/image/976/40955976,pd=1,h=255,w=450/mallorca-e-kutschen-rollen-alcudia.webp 450w, https://i0.web.de/image/976/40955976,pd=1,h=340,w=600/mallorca-e-kutschen-rollen-alcudia.webp 600w" sizes="300px">
<img alt="Mallorca: Erste E-Kutschen rollen durch Alcúdia." loading="lazy" src="https://i0.web.de/image/976/40955976,pd=1,h=170,w=300/mallorca-e-kutschen-rollen-alcudia.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>


<img alt="Logo Pferde.de" loading="lazy" src="https://i0.web.de/image/672/37393672,pd=3,h=20,w=20/logo-pferdede.png" width="20" height="20">
Pferde.de
</span>
<h3>Mallorca: Erste E-Kutschen rollen durch Alcúdia</h3>

</header>


<footer>
<span>vor 56 Minuten</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/wissen/tiere/ueberraschende-studie-haustiere-gluecksbringer-40955942" data-headline="Überraschende Studie: Haustiere sind nicht für jeden ein Glücksbringer" data-teaser-id="40955942">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/944/40955944,pd=1,h=170,w=300/studie-haustiere-gluecksbringer.webp 300w, https://i0.web.de/image/944/40955944,pd=1,h=255,w=450/studie-haustiere-gluecksbringer.webp 450w, https://i0.web.de/image/944/40955944,pd=1,h=340,w=600/studie-haustiere-gluecksbringer.webp 600w" sizes="300px">
<img alt="Studie: Haustiere sind nicht immer Glücksbringer." loading="lazy" src="https://i0.web.de/image/944/40955944,pd=1,h=170,w=300/studie-haustiere-gluecksbringer.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>


<img alt="Logo Deine Tierwelt" loading="lazy" src="https://i0.web.de/image/906/37288906,pd=3,h=20,w=20/logo-tierwelt.png" width="20" height="20">
Deine Tierwelt
</span>
<h3>Überraschende Studie: Haustiere sind nicht für jeden ein Glücksbringer</h3>

</header>


<footer>
<span>vor 58 Minuten</span>
<span>von Deine Tierwelt</span>

</footer>
</article>
</a>

</section>

<div data-component="block-navigation" data-grid-row="" data-tracking-name="channelHeader" data-background="grey" data-name="Kolumne" data-tr-component-path="Kolumne">
<h2 data-tr-component-path="titleChannelHeader">
<a href="https://web.de/magazine/kolumnen/">Unsere Kolumnen</a>
</h2>


</div>

<section data-layout-columns="5col" data-layout-name="simples" data-background="grey" data-name="Kolumne_A" data-tr-component-path="Kolumne_A" data-tracking-name="fourBullets">

<hp-simple>
<a type="hp-simple" href="https://web.de/magazine/autor/pit-gottschalk-33614796" data-tr-component-path="simple">
<figure data-component="simple" data-orientation="vertical" data-background-color>


<picture>
<source type="image/webp" srcset="https://i0.web.de/image/576/34329576,pd=3,h=135,w=135.webp 135w, https://i0.web.de/image/576/34329576,pd=3,h=202,w=202.webp 202w, https://i0.web.de/image/576/34329576,pd=3,h=270,w=270.webp 270w" sizes="135px">
<img data-shape="circle" alt="Pit Gottschalk" loading="lazy" src="https://i0.web.de/image/576/34329576,pd=3,h=135,w=135.jpg" width="135" height="135">
</picture>


<figcaption>Pit Gottschalk</figcaption>
</figure>
</a>
</hp-simple>

<hp-simple>
<a type="hp-simple" href="https://web.de/magazine/autor/ulrike-sosalla-37243008" data-tr-component-path="simple">
<figure data-component="simple" data-orientation="vertical" data-background-color>


<picture>
<source type="image/webp" srcset="https://i0.web.de/image/320/37243320,pd=1,h=135,w=135.webp 135w, https://i0.web.de/image/320/37243320,pd=1,h=202,w=202.webp 202w, https://i0.web.de/image/320/37243320,pd=1,h=270,w=270.webp 270w" sizes="135px">
<img data-shape="circle" alt="" loading="lazy" src="https://i0.web.de/image/320/37243320,pd=1,h=135,w=135.jpg" width="135" height="135">
</picture>


<figcaption>Ulrike Sosalla</figcaption>
</figure>
</a>
</hp-simple>

<hp-simple>
<a type="hp-simple" href="https://web.de/magazine/autor/holger-badstuber-38246994" data-tr-component-path="simple">
<figure data-component="simple" data-orientation="vertical" data-background-color>


<picture>
<source type="image/webp" srcset="https://i0.web.de/image/506/38389506,pd=2,h=135,w=135.webp 135w, https://i0.web.de/image/506/38389506,pd=2,h=202,w=202.webp 202w, https://i0.web.de/image/506/38389506,pd=2,h=270,w=270.webp 270w" sizes="135px">
<img data-shape="circle" alt="" loading="lazy" src="https://i0.web.de/image/506/38389506,pd=2,h=135,w=135.jpg" width="135" height="135">
</picture>


<figcaption>Holger Badstuber</figcaption>
</figure>
</a>
</hp-simple>

<hp-simple>
<a type="hp-simple" href="https://web.de/magazine/autor/marie-benken-35429268" data-tr-component-path="simple">
<figure data-component="simple" data-orientation="vertical" data-background-color>


<picture>
<source type="image/webp" srcset="https://i0.web.de/image/584/38341584,pd=2,h=135,w=135.webp 135w, https://i0.web.de/image/584/38341584,pd=2,h=202,w=202.webp 202w, https://i0.web.de/image/584/38341584,pd=2,h=270,w=270.webp 270w" sizes="135px">
<img data-shape="circle" alt="" loading="lazy" src="https://i0.web.de/image/584/38341584,pd=2,h=135,w=135.jpg" width="135" height="135">
</picture>


<figcaption>Marie von den Benken</figcaption>
</figure>
</a>
</hp-simple>

<hp-simple>
<a type="hp-simple" href="https://web.de/magazine/autor/henning-beck-37076780" data-tr-component-path="simple">
<figure data-component="simple" data-orientation="vertical" data-background-color>


<picture>
<source type="image/webp" srcset="https://i0.web.de/image/792/37750792,pd=1,h=135,w=135/henning-beck.webp 135w, https://i0.web.de/image/792/37750792,pd=1,h=202,w=202/henning-beck.webp 202w, https://i0.web.de/image/792/37750792,pd=1,h=270,w=270/henning-beck.webp 270w" sizes="135px">
<img data-shape="circle" alt="Henning Beck" loading="lazy" src="https://i0.web.de/image/792/37750792,pd=1,h=135,w=135/henning-beck.jpg" width="135" height="135">
</picture>


<figcaption>Henning Beck</figcaption>
</figure>
</a>
</hp-simple>

<hp-simple>
<a type="hp-simple" href="https://web.de/magazine/autor/rolf-schwartmann-34522566" data-tr-component-path="simple">
<figure data-component="simple" data-orientation="vertical" data-background-color>


<picture>
<source type="image/webp" srcset="https://i0.web.de/image/886/37748886,pd=1,h=135,w=135/rolf-schwartmann.webp 135w, https://i0.web.de/image/886/37748886,pd=1,h=202,w=202/rolf-schwartmann.webp 202w, https://i0.web.de/image/886/37748886,pd=1,h=270,w=270/rolf-schwartmann.webp 270w" sizes="135px">
<img data-shape="circle" alt="Rolf Schwartmann" loading="lazy" src="https://i0.web.de/image/886/37748886,pd=1,h=135,w=135/rolf-schwartmann.jpg" width="135" height="135">
</picture>


<figcaption>Rolf Schwartmann</figcaption>
</figure>
</a>
</hp-simple>

<hp-simple>
<a type="hp-simple" href="https://web.de/magazine/autor/anja-delastik-33654364" data-tr-component-path="simple">
<figure data-component="simple" data-orientation="vertical" data-background-color>


<picture>
<source type="image/webp" srcset="https://i0.web.de/image/570/34329570,pd=3,h=135,w=135.webp 135w, https://i0.web.de/image/570/34329570,pd=3,h=202,w=202.webp 202w, https://i0.web.de/image/570/34329570,pd=3,h=270,w=270.webp 270w" sizes="135px">
<img data-shape="circle" alt="Anja Delastik" loading="lazy" src="https://i0.web.de/image/570/34329570,pd=3,h=135,w=135.jpg" width="135" height="135">
</picture>


<figcaption>Anja Delastik</figcaption>
</figure>
</a>
</hp-simple>

</section>

<section data-layout-columns="4col" data-layout-name="teasers" data-background="grey" data-name="Kolumne_B" data-tr-component-path="Kolumne_B" data-tracking-name="fourBullets">

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/politik/annalena-baerbocks-traenen-holocaust-gedenk-rede-falsch-eingeordnet-40951924" data-headline="So werden Annalena Baerbocks Tränen bei Holocaust-Gedenk-Rede falsch eingeordnet" data-teaser-id="40951924">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/140/40952140,pd=2,h=170,w=300/annalena-baerbocks-weint-holocaust-gedenkfeier-bun.webp 300w, https://i0.web.de/image/140/40952140,pd=2,h=255,w=450/annalena-baerbocks-weint-holocaust-gedenkfeier-bun.webp 450w, https://i0.web.de/image/140/40952140,pd=2,h=340,w=600/annalena-baerbocks-weint-holocaust-gedenkfeier-bun.webp 600w" sizes="300px">
<img alt="Annalena Baerbocks weint bei Holocaust-Gedenkfeier im Bundestag" loading="lazy" src="https://i0.web.de/image/140/40952140,pd=2,h=170,w=300/annalena-baerbocks-weint-holocaust-gedenkfeier-bun.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>
<label>Faktencheck</label>


Fake-Video
</span>
<h3>So werden Annalena Baerbocks Tränen bei Holocaust-Gedenk-Rede falsch eingeordnet</h3>

</header>


<footer>
<span>vor 2 Stunden</span>
<span>von CORRECTIV-Faktencheck, K. Nicolaus</span>

</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/satirischer-wochenrueckblick/sartirischer-wochenrueckblick-promi-promiskuitaeten-woche-40948444" data-headline="Die Promi-Promiskuitäten der Woche" data-teaser-id="40948444">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/900/40948900,pd=4,h=170,w=300/bushido-rappen-musik.webp 300w, https://i0.web.de/image/900/40948900,pd=4,h=255,w=450/bushido-rappen-musik.webp 450w, https://i0.web.de/image/900/40948900,pd=4,h=340,w=600/bushido-rappen-musik.webp 600w" sizes="300px">
<img alt="Bushido, Rappen, Musik" loading="lazy" src="https://i0.web.de/image/900/40948900,pd=4,h=170,w=300/bushido-rappen-musik.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>
<label>Kolumne</label>


Sartirischer Wochenrückblick
</span>
<h3>Die Promi-Promiskuitäten der Woche</h3>

</header>


<footer>
<span>vor 1 Tag</span>
<span>von Marie von den Benken</span>

</footer>
</article>
</a>

<div data-service-slot="box_10" data-tr-component-path="box_10" data-visible-in="3,4,5"></div>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/digital/situs-vilate-isse-tabernit-ki-latein-anfaenger-40949172" data-headline="&quot;Situs vilate in isse tabernit&quot; – KI-Latein für Anfänger" data-teaser-id="40949172">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/318/40949318,pd=1,h=170,w=300.webp 300w, https://i0.web.de/image/318/40949318,pd=1,h=255,w=450.webp 450w, https://i0.web.de/image/318/40949318,pd=1,h=340,w=600.webp 600w" sizes="300px">
<img alt="" loading="lazy" src="https://i0.web.de/image/318/40949318,pd=1,h=170,w=300.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>
<label>Kolumne</label>


Digitales Leben
</span>
<h3>&quot;Situs vilate in isse tabernit&quot; – KI-Latein für Anfänger</h3>

</header>


<footer>
<span>vor 1 Tag</span>
<span>von Rolf Schwartmann</span>

</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/sport/fussball/120000-euro-em-praemie-fussballerinnen-geld-40936212" data-headline="Viel Geld – und doch nicht genug" data-teaser-id="40936212">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/402/40936402,pd=2,h=170,w=300/dfb.webp 300w, https://i0.web.de/image/402/40936402,pd=2,h=255,w=450/dfb.webp 450w, https://i0.web.de/image/402/40936402,pd=2,h=340,w=600/dfb.webp 600w" sizes="300px">
<img alt="DFB" loading="lazy" src="https://i0.web.de/image/402/40936402,pd=2,h=170,w=300/dfb.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>
<label>Kolumne</label>


EM-Prämie
</span>
<h3>Viel Geld – und doch nicht genug</h3>

</header>


<footer>
<span>vor 5 Tagen</span>
<span>von Pit Gottschalk</span>

</footer>
</article>
</a>

</section>

<div data-component="block-navigation" data-grid-row="" data-tracking-name="channelHeader" data-name="UNICEF" data-tr-component-path="UNICEF">
<h2 data-tr-component-path="titleChannelHeader">
<a href="https://web.de/magazine/unicef/">United Internet for UNICEF</a>
</h2>
<nav>
<ul>
<li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/unicef/helfen-kindern-sudan-39683948">Einmalig spenden</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://www.united-internet-for-unicef-stiftung.de/spenden/unicef-pate-werden">UNICEF-Pate werden</a>
</li>
</ul>
</nav>

</div>

<section data-layout-columns="4col" data-layout-name="teasers" data-name="UNICEF" data-tr-component-path="UNICEF" data-tracking-name="four">

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unicef/toedlicher-stich-malaria-bleibt-grosse-gefahr-kinder-40910470" data-headline="Tödlicher Stich" data-teaser-id="40910470">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/268/40915268,pd=4,h=170,w=300/anopheles-muecke.webp 300w, https://i0.web.de/image/268/40915268,pd=4,h=255,w=450/anopheles-muecke.webp 450w, https://i0.web.de/image/268/40915268,pd=4,h=340,w=600/anopheles-muecke.webp 600w" sizes="300px">
<img alt="Anopheles-Mücke" loading="lazy" src="https://i0.web.de/image/268/40915268,pd=4,h=170,w=300/anopheles-muecke.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Weltmalariatag
</span>
<h3>Tödlicher Stich</h3>

</header>


<footer>
<span>vor 12 Tagen</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unicef/gewalt-ost-kongo-halbe-stunde-kind-vergewaltigt-40909104" data-headline="Gewalt im Ost-Kongo: Jede halbe Stunde wurde ein Kind vergewaltigt" data-teaser-id="40909104">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/254/40222254,pd=6,h=170,w=300/junges-maedchen-tochter-arm.webp 300w, https://i0.web.de/image/254/40222254,pd=6,h=255,w=450/junges-maedchen-tochter-arm.webp 450w, https://i0.web.de/image/254/40222254,pd=6,h=340,w=600/junges-maedchen-tochter-arm.webp 600w" sizes="300px">
<img alt="Ein junges Mädchen mit ihrer Tochter auf dem Arm" loading="lazy" src="https://i0.web.de/image/254/40222254,pd=6,h=170,w=300/junges-maedchen-tochter-arm.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Während der schlimmsten Kämpfe
</span>
<h3>Gewalt im Ost-Kongo: Jede halbe Stunde wurde ein Kind vergewaltigt</h3>

</header>


<footer>
<span>vor 12 Tagen</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unicef/jahre-krieg-sudan-kindern-passieren-40878164" data-headline="Zwei Jahre Krieg im Sudan: &quot;Was soll mit den Kindern passieren?&quot;" data-teaser-id="40878164">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/846/40880846,pd=4,h=170,w=300/vertriebene-sudan.webp 300w, https://i0.web.de/image/846/40880846,pd=4,h=255,w=450/vertriebene-sudan.webp 450w, https://i0.web.de/image/846/40880846,pd=4,h=340,w=600/vertriebene-sudan.webp 600w" sizes="300px">
<img alt="Vertriebene in Sudan" loading="lazy" src="https://i0.web.de/image/846/40880846,pd=4,h=170,w=300/vertriebene-sudan.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>
<label>Interview</label>


Ehemalige Springer-Vorständin
</span>
<h3>Zwei Jahre Krieg im Sudan: &quot;Was soll mit den Kindern passieren?&quot;</h3>

</header>


<footer>
<span>vor 22 Tagen</span>
<span>von Carla Giuseppina Magnanimo</span>

</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unicef/jahre-krieg-kinder-sudan-ueberleben-40857454" data-headline="Kein sicherer Ort: Wie Kinder im Sudan überleben müssen" data-teaser-id="40857454">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/474/40857474,pd=1,h=170,w=300/mutter-kleinkind-bett.webp 300w, https://i0.web.de/image/474/40857474,pd=1,h=255,w=450/mutter-kleinkind-bett.webp 450w, https://i0.web.de/image/474/40857474,pd=1,h=340,w=600/mutter-kleinkind-bett.webp 600w" sizes="300px">
<img alt="Eine Mutter und ein Kleinkind auf einem Bett" loading="lazy" src="https://i0.web.de/image/474/40857474,pd=1,h=170,w=300/mutter-kleinkind-bett.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



United Internet for UNICEF
</span>
<h3>Kein sicherer Ort: Wie Kinder im Sudan überleben müssen</h3>

</header>


<footer>
<span>vor 21 Tagen</span>
<span>von Tessa Page</span>

</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unicef/myanmar-nothilfe-helfen-spende-kindern-erdbebengebiet-40819650" data-headline="Myanmar: Helfen Sie mit Ihrer Spende den Kindern im Erdbebengebiet" data-teaser-id="40825922">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/812/40819812,pd=5,h=170,w=300.webp 300w, https://i0.web.de/image/812/40819812,pd=5,h=255,w=450.webp 450w, https://i0.web.de/image/812/40819812,pd=5,h=340,w=600.webp 600w" sizes="300px">
<img alt="" loading="lazy" src="https://i0.web.de/image/812/40819812,pd=5,h=170,w=300.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



UNICEF-Nothilfe
</span>
<h3>Myanmar: Helfen Sie mit Ihrer Spende den Kindern im Erdbebengebiet</h3>

</header>


<footer>
<span>31. März 2025</span>


</footer>
</article>
</a>

</section>

<div data-component="block-navigation" data-grid-row="" data-tracking-name="channelHeader" data-name="Vergleichswelt" data-tr-component-path="Vergleichswelt">
<h2 data-tr-component-path="titleChannelHeader">
<a href="https://web.de/vergleichswelt/?mc=80000170">Vergleichswelt</a>
</h2>
<nav>
<ul>
<li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/vergleichswelt/finanzen/?mc=80000000">Finanzen</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/vergleichswelt/versicherungen/?mc=01883033">Versicherungen</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/vergleichswelt/bildung/?mc=80500000">Bildung &amp; Nachhilfe</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://www.energie.web.de/strom?mc=05579359">Strom &amp; Gas</a>
</li><li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/handy/?mc=05505272">Mobilfunk &amp; DSL</a>
</li>
</ul>
</nav>

</div>

<section data-layout-columns="4col" data-layout-name="sliderWithList" data-name="Vergleichswelt" data-tr-component-path="Vergleichswelt" data-tracking-name="oneList">

<hp-slider v-slot="{ goTo, goPrev, goNext }" data-component="slider" :interval="5000" :animation-type="&#039;lefttoright&#039;" data-animation-type="lefttoright">


<span data-part="arrow-prev" @click="goPrev">
<div data-component="icon">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>
<span data-part="arrow-next" @click="goNext">
<div data-component="icon">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
<rect x="-2" y="-2" width="20" height="20" transform="translate(18 18) rotate(180)" style="fill: none;"></rect>
<path d="M6.33,6.8h11a0,0,0,0,1,0,0V8.67a0,0,0,0,1,0,0h-11a.75.75,0,0,1-.75-.75V7.55a.75.75,0,0,1,.75-.75Z" transform="translate(27.05 7.09) rotate(135)" class="arrow"></path>
<path d="M-1.34,6.83H9.59a.75.75,0,0,1,.75.75V8a.75.75,0,0,1-.75.75H-1.34a0,0,0,0,1,0,0V6.83a0,0,0,0,1,0,0Z" transform="translate(4.2 18.44) rotate(-135)" class="arrow"></path>
</svg>
</div>
</span>

<div data-wrapper>
<div>

<a data-component="teaser" type="hp-teaser" href="https://web.de/vergleichswelt/finanzen/geldanlage/tagesgeldkonto/?mc=80000314" data-headline="Tagesgeldkonto" data-article-overlay="bottomleft">

<figure>


<img alt="Tagesgeldkonto: Mann mit wachsendem Münzstapel" loading="lazy" src="https://img.ui-portal.de/Vergleichswelt/webde/Finanzen/Geldanlage/Tagesgeld-Vergleich/mann-mit-muenzstapel-groß.jpg" width="960" height="540">



<figcaption data-position="top" data-color="accent">

<span>Über 3 % Zinsen sichern</span>
</figcaption>
</figure>

<article>
<header>
<span>



Über 3 % Zinsen pro Jahr!
</span>
<h3>Tagesgeldkonto</h3>

</header>
<p>Über 3 % Zinsen pro Jahr mit einem Tagesgeldkonto sichern.</p>


</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/vergleichswelt/finanzen/konto-und-karte/girokonto/?mc=80000001" data-headline="Girokonto" data-article-overlay="bottomleft">

<figure>


<img alt="Girokonto Vergleich: Karte am Geldautomat" loading="lazy" src="https://img.ui-portal.de/Vergleichswelt/webde/Finanzen/Konto-und-Karte/Girokonto-Vergleich/mann-am-bankautomat.jpg" width="960" height="540">



<figcaption data-position="top" data-color="accent">

<span>75 € Startguthaben</span>
</figcaption>
</figure>

<article>
<header>
<span>



Girokonto kostenlos vergleichen, das beste Konto finden, online eröffnen!
</span>
<h3>Girokonto</h3>

</header>
<p>Kostenloses Girokonto mit 75 € Startguthaben sichern!</p>


</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/vergleichswelt/finanzen/konto-und-karte/kreditkarte?mc=80000002" data-headline="Kreditkarte" data-article-overlay="bottomleft">

<figure>


<img alt="Kreditkartenvergleich: Paar mit Kreditkarte und Laptop" loading="lazy" src="https://img.ui-portal.de/Vergleichswelt/webde/Finanzen/Konto-und-Karte/Kreditkarten-Vergleich/paar-auf-sofa-mit-karte.jpg" width="960" height="540">



<figcaption data-position="top" data-color="accent">

<span>Willkommensbonus sichern</span>
</figcaption>
</figure>

<article>
<header>
<span>



Kreditkarten mit und ohne Girokonto  – einfach kostenlos vergleichen!
</span>
<h3>Kreditkarte</h3>

</header>
<p>Die besten kostenlosen Kreditkarten im Vergleich. Willkommensbonus sichern!</p>


</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/vergleichswelt/finanzen/geldanlage/depot/?mc=80000003" data-headline="Depot" data-article-overlay="bottomleft">

<figure>


<img alt="Depotvergleich: Laptop und Monitor mit Kursgrafiken" loading="lazy" src="https://img.ui-portal.de/Vergleichswelt/webde/Finanzen/Geldanlage/Depot-Vergleich/statistiken-am-pc-mit-personen.jpg" width="960" height="540">




</figure>

<article>
<header>
<span>



Depots bei Online-Brokern und Banken vergleichen. Oft mit Neukundenbonus!
</span>
<h3>Depot</h3>

</header>
<p>Ein kostenloses Depot beim Online-Broker oder ein Wertpapierdepot bei der Hausbank? Hier Konditionen vergleichen.</p>


</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://vorteile.web.de/webcent/sammeln/shops/webcentcard_webde/#.hp.vergleichswelt" data-headline="WEB.Cent Kreditkarte" data-article-overlay="bottomleft">

<figure>


<img alt="WEB.Cent Kreditkarte" loading="lazy" src="https://img.ui-portal.de/Vergleichswelt/webde/WEBcent Kreditkarte/webde_hp-modul.jpg" width="960" height="540">



<figcaption data-position="top" data-color="accent">

<span>Bis zu 30 € Willkommens-Cashback</span>
</figcaption>
</figure>

<article>
<header>
<span>



Jetzt Willkommens-Cashback sichern!
</span>
<h3>WEB.Cent Kreditkarte</h3>

</header>
<p>0 € Jahresgebühr, 0,5 % Cashback auf jeden Ihrer Einkäufe + Reiseversicherungen – jetzt Willkommens-Cashback sichern!</p>


</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/handy/?mc=05505273" data-headline="Mobilfunk" data-article-overlay="bottomleft">

<figure>


<img alt="Mobilfunk Vergleich: Frau mit Smartphone" loading="lazy" src="https://img.ui-portal.de/Vergleichswelt/homepagemodul/mobilfunk-hp-modul.jpg" width="960" height="540">




</figure>

<article>
<header>
<span>



Günstige Wunschtarife, Neutraler Vergleich, Volle Transparenz!
</span>
<h3>Mobilfunk</h3>

</header>
<p>Der aktuelle Handytarif ist zu teuer? Hier namhafte Anbieter miteinander vergleichen und günstige Alternative finden.</p>


</article>
</a>

</div>
</div>
</hp-slider>

<div data-component="list">
<h3>Top Vergleiche</h3>
<ol>
<li data-tr-component-path="list">
<span>1</span>

<a data-component="teaser" type="hp-teaser" href="https://web.de/vergleichswelt/finanzen/geldanlage/tagesgeldkonto/?mc=80000315" data-separator="top" data-headline="Über 3 % Zinsen pro Jahr mit einem Tagesgeldkonto sichern.">



<article>
<header>
<span>
<label data-color="accent">Über 3 % Zinsen</label>


Tagesgeldkonto
</span>
<h3>Über 3 % Zinsen pro Jahr mit einem Tagesgeldkonto sichern.</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">
<span>2</span>

<a data-component="teaser" type="hp-teaser" href="https://web.de/vergleichswelt/finanzen/konto-und-karte/girokonto/?mc=80000007" data-separator="top" data-headline="Kostenloses Girokonto mit 75 € Startguthaben sichern.">



<article>
<header>
<span>



Girokonto
</span>
<h3>Kostenloses Girokonto mit 75 € Startguthaben sichern.</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">
<span>3</span>

<a data-component="teaser" type="hp-teaser" href="https://web.de/vergleichswelt/bildung/fremdsprachen/?mc=80500009" data-separator="top" data-headline="Jetzt eine neue Sprache für Ihren Urlaub lernen!">



<article>
<header>
<span>
<label data-color="accent">Neu</label>


Fremdsprachen lernen
</span>
<h3>Jetzt eine neue Sprache für Ihren Urlaub lernen!</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">
<span>4</span>

<a data-component="teaser" type="hp-teaser" href="https://web.de/vergleichswelt/finanzen/konto-und-karte/kreditkarte/?mc=80000380" data-separator="top" data-headline="Kostenlose Kreditkarte und Willkommensbonus sichern.">



<article>
<header>
<span>



Kreditkarte
</span>
<h3>Kostenlose Kreditkarte und Willkommensbonus sichern.</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">
<span>5</span>

<a data-component="teaser" type="hp-teaser" href="https://vorteile.web.de/webcent/sammeln/shops/webcentcard_webde/#.hp.vergleichswelt.top" data-separator="top" data-headline="Cashback für jeden Einkauf + 0 € Jahresgebühr">



<article>
<header>
<span>



WEB.Cent Kreditkarte
</span>
<h3>Cashback für jeden Einkauf + 0 € Jahresgebühr</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">
<span>6</span>

<a data-component="teaser" type="hp-teaser" href="https://web.de/vergleichswelt/bildung/abitur/?mc=80500010" data-separator="top" data-headline="Holen Sie an einer Fernschule Ihr Abitur nach.">



<article>
<header>
<span>
<label data-color="accent">ABI</label>


Abitur machen
</span>
<h3>Holen Sie an einer Fernschule Ihr Abitur nach.</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">
<span>7</span>

<a data-component="teaser" type="hp-teaser" href="https://web.de/handy/?mc=05505274" data-separator="top" data-headline="Günstige Handytarife, neutraler Vergleich, volle Transparenz!">



<article>
<header>
<span>



Mobilfunk
</span>
<h3>Günstige Handytarife, neutraler Vergleich, volle Transparenz!</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">
<span>8</span>

<a data-component="teaser" type="hp-teaser" href="https://web.de/vergleichswelt/bildung/bachelor/?mc=80500011" data-separator="top" data-headline="Machen Sie den Bachelor und starten Sie Ihre Karriere!">



<article>
<header>
<span>
<label data-color="accent">Fernstudium</label>


Bachelor machen
</span>
<h3>Machen Sie den Bachelor und starten Sie Ihre Karriere!</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">
<span>9</span>

<a data-component="teaser" type="hp-teaser" href="https://web.de/vergleichswelt/finanzen/geldanlage/depot/?mc=80000008" data-separator="top" data-headline="Depots bei Online-Brokern und Banken vergleichen. Oft mit Neukundenbonus!">



<article>
<header>
<span>



Depot
</span>
<h3>Depots bei Online-Brokern und Banken vergleichen. Oft mit Neukundenbonus!</h3>

</header>



</article>
</a>

</li><li data-tr-component-path="list">
<span>10</span>

<a data-component="teaser" type="hp-teaser" href="https://web.de/vergleichswelt/finanzen/geldanlage/festgeld/?mc=80000427" data-separator="top" data-headline="Planbarer Vermögensaufbau. Garantierter Zinssatz für feste Laufzeiten.">



<article>
<header>
<span>



Festgeld
</span>
<h3>Planbarer Vermögensaufbau. Garantierter Zinssatz für feste Laufzeiten.</h3>

</header>



</article>
</a>

</li>
</ol>

</div>

</section>

<div data-component="block-navigation" data-grid-row="" data-tracking-name="channelHeader" data-name="Comic" data-tr-component-path="Comic">
<h2 data-tr-component-path="titleChannelHeader">
<a href="https://web.de/magazine/unterhaltung/comic/">Comics</a>
</h2>


</div>

<section data-layout-columns="4col" data-layout-name="teasers" data-name="Comic" data-tr-component-path="Comic" data-tracking-name="four">

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/comic/aktuelle-karikaturen-18584042" data-headline="Nachrichten sind langweilig und dröge? Es kommt auf den Blickwinkel an" data-teaser-id="18584042">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/982/40953982,pd=3,h=170,w=300/siteimagesdethemenaktuelldiekleinert-stock-highres.webp 300w, https://i0.web.de/image/982/40953982,pd=3,h=255,w=450/siteimagesdethemenaktuelldiekleinert-stock-highres.webp 450w, https://i0.web.de/image/982/40953982,pd=3,h=340,w=600/siteimagesdethemenaktuelldiekleinert-stock-highres.webp 600w" sizes="300px">
<img alt="" loading="lazy" src="https://i0.web.de/image/982/40953982,pd=3,h=170,w=300/siteimagesdethemenaktuelldiekleinert-stock-highres.jpg" width="300" height="170">
</picture>




<figcaption>

<div data-component="icon">
























<svg width="20" height="20" viewBox="0 0 20 20">
<rect rx="0.4" height="9.6" width="9.6" y="8.4" x="2" />
<path d="m6,5.2a0.4,0.4 0 1 0 0,0.8l8,0l0,8a0.4,0.4 0 0 0 0.8,0l0,-8.8l-8.8,0z" />
<path d="m9.2,2a0.4,0.4 0 0 0 0,0.8l8,0l0,8a0.4,0.4 0 0 0 0.8,0l0,-8.8l-8.8,0z" />
</svg>


</div>


</figcaption>
</figure>

<article>
<header>
<span>



Aktuelle Karikaturen
</span>
<h3>Nachrichten sind langweilig und dröge? Es kommt auf den Blickwinkel an</h3>

</header>


<footer>
<span>vor 18 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/comic/comicserie-zeiten-kuenstlers-andreas-brandt-alias-sebby-38828512" data-headline="Comics des Künstlers Andreas Brandt alias Sebby" data-teaser-id="38828512">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/854/40889854,pd=2,h=170,w=300.webp 300w, https://i0.web.de/image/854/40889854,pd=2,h=255,w=450.webp 450w, https://i0.web.de/image/854/40889854,pd=2,h=340,w=600.webp 600w" sizes="300px">
<img alt="" loading="lazy" src="https://i0.web.de/image/854/40889854,pd=2,h=170,w=300.jpg" width="300" height="170">
</picture>




<figcaption>

<div data-component="icon">
























<svg width="20" height="20" viewBox="0 0 20 20">
<rect rx="0.4" height="9.6" width="9.6" y="8.4" x="2" />
<path d="m6,5.2a0.4,0.4 0 1 0 0,0.8l8,0l0,8a0.4,0.4 0 0 0 0.8,0l0,-8.8l-8.8,0z" />
<path d="m9.2,2a0.4,0.4 0 0 0 0,0.8l8,0l0,8a0.4,0.4 0 0 0 0.8,0l0,-8.8l-8.8,0z" />
</svg>


</div>


</figcaption>
</figure>

<article>
<header>
<span>



Neue Zeiten
</span>
<h3>Comics des Künstlers Andreas Brandt alias Sebby</h3>

</header>


<footer>
<span>vor 5 Tagen</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/comic/comics-kuenstlers-uli-stein-erwin-martha-maeuse-co-38828510" data-headline="Comics des Künstlers Uli Stein" data-teaser-id="38828510">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/910/40889910,pd=3,h=170,w=300.webp 300w, https://i0.web.de/image/910/40889910,pd=3,h=255,w=450.webp 450w, https://i0.web.de/image/910/40889910,pd=3,h=340,w=600.webp 600w" sizes="300px">
<img alt="" loading="lazy" src="https://i0.web.de/image/910/40889910,pd=3,h=170,w=300.jpg" width="300" height="170">
</picture>




<figcaption>

<div data-component="icon">
























<svg width="20" height="20" viewBox="0 0 20 20">
<rect rx="0.4" height="9.6" width="9.6" y="8.4" x="2" />
<path d="m6,5.2a0.4,0.4 0 1 0 0,0.8l8,0l0,8a0.4,0.4 0 0 0 0.8,0l0,-8.8l-8.8,0z" />
<path d="m9.2,2a0.4,0.4 0 0 0 0,0.8l8,0l0,8a0.4,0.4 0 0 0 0.8,0l0,-8.8l-8.8,0z" />
</svg>


</div>


</figcaption>
</figure>

<article>
<header>
<span>



Comics
</span>
<h3>Comics des Künstlers Uli Stein</h3>

</header>


<footer>
<span>vor 5 Tagen</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/comic/comicserie-tag-tier-kuenstlerin-dorthe-landschulz-36570022" data-headline="Comics der norddeutschen Künstlerin Dorthe Landschulz" data-teaser-id="36570022">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/896/40889896,pd=1,h=170,w=300.webp 300w, https://i0.web.de/image/896/40889896,pd=1,h=255,w=450.webp 450w, https://i0.web.de/image/896/40889896,pd=1,h=340,w=600.webp 600w" sizes="300px">
<img alt="" loading="lazy" src="https://i0.web.de/image/896/40889896,pd=1,h=170,w=300.jpg" width="300" height="170">
</picture>




<figcaption>

<div data-component="icon">
























<svg width="20" height="20" viewBox="0 0 20 20">
<rect rx="0.4" height="9.6" width="9.6" y="8.4" x="2" />
<path d="m6,5.2a0.4,0.4 0 1 0 0,0.8l8,0l0,8a0.4,0.4 0 0 0 0.8,0l0,-8.8l-8.8,0z" />
<path d="m9.2,2a0.4,0.4 0 0 0 0,0.8l8,0l0,8a0.4,0.4 0 0 0 0.8,0l0,-8.8l-8.8,0z" />
</svg>


</div>


</figcaption>
</figure>

<article>
<header>
<span>



Ein Tag Ein Tier
</span>
<h3>Comics der norddeutschen Künstlerin Dorthe Landschulz</h3>

</header>


<footer>
<span>vor 1 Tag</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/unterhaltung/comic/comicserie-shit-happens-kuenstlers-ralph-ruthe-36570020" data-headline="Comics des Künstlers Ralph Ruthe" data-teaser-id="36570020">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/066/40819066,pd=1,h=170,w=300.webp 300w, https://i0.web.de/image/066/40819066,pd=1,h=255,w=450.webp 450w, https://i0.web.de/image/066/40819066,pd=1,h=340,w=600.webp 600w" sizes="300px">
<img alt="" loading="lazy" src="https://i0.web.de/image/066/40819066,pd=1,h=170,w=300.jpg" width="300" height="170">
</picture>




<figcaption>

<div data-component="icon">
























<svg width="20" height="20" viewBox="0 0 20 20">
<rect rx="0.4" height="9.6" width="9.6" y="8.4" x="2" />
<path d="m6,5.2a0.4,0.4 0 1 0 0,0.8l8,0l0,8a0.4,0.4 0 0 0 0.8,0l0,-8.8l-8.8,0z" />
<path d="m9.2,2a0.4,0.4 0 0 0 0,0.8l8,0l0,8a0.4,0.4 0 0 0 0.8,0l0,-8.8l-8.8,0z" />
</svg>


</div>


</figcaption>
</figure>

<article>
<header>
<span>



Shit Happens!
</span>
<h3>Comics des Künstlers Ralph Ruthe</h3>

</header>


<footer>
<span>vor 4 Tagen</span>


</footer>
</article>
</a>

</section>

<div data-component="block-navigation" data-grid-row="" data-tracking-name="channelHeader" data-name="Wirtschaft" data-tr-component-path="Wirtschaft">
<h2 data-tr-component-path="titleChannelHeader">
<a href="https://web.de/magazine/wirtschaft/">Wirtschaft</a>
</h2>
<nav>
<ul>
<li data-tr-component-path="optionChannelHeader">
<a href="https://web.de/magazine/wirtschaft/thema/">Wirtschaft A-Z</a>
</li>
</ul>
</nav>

</div>

<section data-layout-columns="4col" data-layout-name="teasers" data-name="Wirtschaft" data-tr-component-path="Wirtschaft" data-tracking-name="four">

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/wirtschaft/check24-versicherungen-vorerst-noten-40956166" data-headline="Check24 darf Versicherungen vorerst weiter Noten geben" data-teaser-id="40956166">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/168/40956168,pd=1,h=170,w=300/vergleichsportal-check24.webp 300w, https://i0.web.de/image/168/40956168,pd=1,h=255,w=450/vergleichsportal-check24.webp 450w, https://i0.web.de/image/168/40956168,pd=1,h=340,w=600/vergleichsportal-check24.webp 600w" sizes="300px">
<img alt="Vergleichsportal Check24" loading="lazy" src="https://i0.web.de/image/168/40956168,pd=1,h=170,w=300/vergleichsportal-check24.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Wirtschaft
</span>
<h3>Check24 darf Versicherungen vorerst weiter Noten geben</h3>

</header>


<footer>
<span>vor 21 Minuten</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/wirtschaft/starkes-us-geschaeft-exporte-trumps-zollpaket-40956074" data-headline="Starkes US-Geschäft – Exporte legen vor Trumps Zollpaket zu" data-teaser-id="40956074">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/076/40956076,pd=1,h=170,w=300/export.webp 300w, https://i0.web.de/image/076/40956076,pd=1,h=255,w=450/export.webp 450w, https://i0.web.de/image/076/40956076,pd=1,h=340,w=600/export.webp 600w" sizes="300px">
<img alt="Export" loading="lazy" src="https://i0.web.de/image/076/40956076,pd=1,h=170,w=300/export.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Wirtschaft
</span>
<h3>Starkes US-Geschäft – Exporte legen vor Trumps Zollpaket zu</h3>

</header>


<footer>
<span>vor 33 Minuten</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/wirtschaft/groesstes-plus-2022-wirtschaft-steigert-produktion-40955580" data-headline="Größtes Plus seit 2022: Wirtschaft steigert Produktion" data-teaser-id="40955580">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/582/40955582,pd=1,h=170,w=300/neuwagen.webp 300w, https://i0.web.de/image/582/40955582,pd=1,h=255,w=450/neuwagen.webp 450w, https://i0.web.de/image/582/40955582,pd=1,h=340,w=600/neuwagen.webp 600w" sizes="300px">
<img alt="Neuwagen" loading="lazy" src="https://i0.web.de/image/582/40955582,pd=1,h=170,w=300/neuwagen.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Wirtschaft
</span>
<h3>Größtes Plus seit 2022: Wirtschaft steigert Produktion</h3>

</header>


<footer>
<span>vor 2 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/wirtschaft/videos/fed-widersteht-trump-leitzins-bleibt-konstant-40955186" data-headline="Fed widersteht Trump: Leitzins bleibt konstant" data-teaser-id="40955186">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/188/40955188,pd=2,h=170,w=300/fed-widersteht-trump-leitzins-bleibt-konstant.webp 300w, https://i0.web.de/image/188/40955188,pd=2,h=255,w=450/fed-widersteht-trump-leitzins-bleibt-konstant.webp 450w, https://i0.web.de/image/188/40955188,pd=2,h=340,w=600/fed-widersteht-trump-leitzins-bleibt-konstant.webp 600w" sizes="300px">
<img alt="Fed widersteht Trump: Leitzins bleibt konstant" loading="lazy" src="https://i0.web.de/image/188/40955188,pd=2,h=170,w=300/fed-widersteht-trump-leitzins-bleibt-konstant.jpg" width="300" height="170">
</picture>




<figcaption>

<div data-component="icon">























<svg width="20" height="20" viewBox="0 0 20 20">
<path d="M16.76,10.74,4.08,17.89a.85.85,0,0,1-1.16-.33.87.87,0,0,1-.11-.41V2.85A.86.86,0,0,1,3.67,2a.84.84,0,0,1,.41.11L16.76,9.26a.85.85,0,0,1,.32,1.16A.82.82,0,0,1,16.76,10.74Z"/>
</svg>



</div>


</figcaption>
</figure>

<article>
<header>
<span>



Auf Konfrontationskurs
</span>
<h3>Fed widersteht Trump: Leitzins bleibt konstant</h3>

</header>


<footer>
<span>vor 2 Stunden</span>


</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/wirtschaft/trotz-trump-drohungen-us-notenbank-leitzins-40954416" data-headline="Trotz Trump-Drohungen: US-Notenbank senkt Leitzins nicht" data-teaser-id="40954416">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/562/40954562,pd=1,h=170,w=300/us-notenbank-fed-belaesst-leitzins-hohem-niveau.webp 300w, https://i0.web.de/image/562/40954562,pd=1,h=255,w=450/us-notenbank-fed-belaesst-leitzins-hohem-niveau.webp 450w, https://i0.web.de/image/562/40954562,pd=1,h=340,w=600/us-notenbank-fed-belaesst-leitzins-hohem-niveau.webp 600w" sizes="300px">
<img alt="US-Notenbank Fed belässt Leitzins erneut auf hohem Niveau" loading="lazy" src="https://i0.web.de/image/562/40954562,pd=1,h=170,w=300/us-notenbank-fed-belaesst-leitzins-hohem-niveau.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Inflation im Blick
</span>
<h3>Trotz Trump-Drohungen: US-Notenbank senkt Leitzins nicht</h3>

</header>


<footer>
<span>vor 2 Stunden</span>


</footer>
</article>
</a>

</section>

<div data-component="block-navigation" data-grid-row="" data-tracking-name="channelHeader" data-name="Redaktion" data-tr-component-path="Redaktion">
<h2 data-tr-component-path="titleChannelHeader">
<a href="https://web.de/magazine/so-arbeitet-die-redaktion/">So arbeitet die Redaktion</a>
</h2>


</div>

<section data-layout-columns="4col" data-layout-name="teasers" data-name="Redaktion" data-tr-component-path="Redaktion" data-tracking-name="four">

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/so-arbeitet-die-redaktion/feedback-erreicht-redaktion-35644470" data-headline="Wie Ihr Feedback uns erreicht – und wie wir damit arbeiten" data-teaser-id="35644470">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/242/36072242,pd=4,h=170,w=300/grafische-darstellung-illustriert-leser-feedback-r.webp 300w, https://i0.web.de/image/242/36072242,pd=4,h=255,w=450/grafische-darstellung-illustriert-leser-feedback-r.webp 450w, https://i0.web.de/image/242/36072242,pd=4,h=340,w=600/grafische-darstellung-illustriert-leser-feedback-r.webp 600w" sizes="300px">
<img alt="Grafische Darstellung, die illustriert, wie Leser Feedback an die Redaktion geben." loading="lazy" src="https://i0.web.de/image/242/36072242,pd=4,h=170,w=300/grafische-darstellung-illustriert-leser-feedback-r.png" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Wie wir arbeiten
</span>
<h3>Wie Ihr Feedback uns erreicht – und wie wir damit arbeiten</h3>

</header>


<footer>
<span>vor 26 Tagen</span>
<span>von F. Scharch, J. Rondthaler</span>

</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/so-arbeitet-die-redaktion/meinung-geschichte-beitrag-leserformate-40690900" data-headline="Ihre Meinung, Ihre Geschichte, Ihr Beitrag – unsere Leserformate" data-teaser-id="40690900">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/800/40769800,pd=2,h=170,w=300/grafische-darstellung-zusammenarbeit-redaktion-les.webp 300w, https://i0.web.de/image/800/40769800,pd=2,h=255,w=450/grafische-darstellung-zusammenarbeit-redaktion-les.webp 450w, https://i0.web.de/image/800/40769800,pd=2,h=340,w=600/grafische-darstellung-zusammenarbeit-redaktion-les.webp 600w" sizes="300px">
<img alt="Grafische Darstellung, die die Zusammenarbeit der Redaktion mit ihren Lesern illustriert." loading="lazy" src="https://i0.web.de/image/800/40769800,pd=2,h=170,w=300/grafische-darstellung-zusammenarbeit-redaktion-les.png" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Wie wir arbeiten
</span>
<h3>Ihre Meinung, Ihre Geschichte, Ihr Beitrag – unsere Leserformate</h3>

</header>


<footer>
<span>vor 1 Tag</span>
<span>von J. Rondthaler, F. Scharch</span>

</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/so-arbeitet-die-redaktion/seltene-fake-werbung--39357646" data-headline="Seltene Fake-Werbung auf unseren Seiten - was Sie dann tun können" data-teaser-id="39357646">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/230/39423230,pd=5,h=170,w=300.webp 300w, https://i0.web.de/image/230/39423230,pd=5,h=255,w=450.webp 450w, https://i0.web.de/image/230/39423230,pd=5,h=340,w=600.webp 600w" sizes="300px">
<img alt="" loading="lazy" src="https://i0.web.de/image/230/39423230,pd=5,h=170,w=300.png" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Wie wir arbeiten
</span>
<h3>Seltene Fake-Werbung auf unseren Seiten - was Sie dann tun können</h3>

</header>


<footer>
<span>29. April 2024</span>
<span>von Christian Zechel</span>

</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/so-arbeitet-die-redaktion/kommentarfunktion-vorerst-deaktiviert-39374522" data-headline="Warum wir unsere Kommentarfunktion (vorerst) deaktiviert haben" data-teaser-id="39374522">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/082/36082082,pd=3,h=170,w=300.webp 300w, https://i0.web.de/image/082/36082082,pd=3,h=255,w=450.webp 450w, https://i0.web.de/image/082/36082082,pd=3,h=340,w=600.webp 600w" sizes="300px">
<img alt="" loading="lazy" src="https://i0.web.de/image/082/36082082,pd=3,h=170,w=300.png" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>



Wie wir arbeiten
</span>
<h3>Warum wir unsere Kommentarfunktion (vorerst) deaktiviert haben</h3>

</header>


<footer>
<span>28. Februar 2024</span>
<span>von Jakob Rondthaler</span>

</footer>
</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/magazine/so-arbeitet-die-redaktion/lesertag-redaktion-40453778" data-headline="So war der Lesertag in unserer Redaktion " data-teaser-id="40453778">

<figure>

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/594/40471594,pd=3,h=170,w=300.webp 300w, https://i0.web.de/image/594/40471594,pd=3,h=255,w=450.webp 450w, https://i0.web.de/image/594/40471594,pd=3,h=340,w=600.webp 600w" sizes="300px">
<img alt="" loading="lazy" src="https://i0.web.de/image/594/40471594,pd=3,h=170,w=300.jpg" width="300" height="170">
</picture>





</figure>

<article>
<header>
<span>
<label>Reportage</label>


Ein Tag hinter den Kulissen
</span>
<h3>So war der Lesertag in unserer Redaktion </h3>

</header>


<footer>
<span>8. Januar 2025</span>
<span>von J. Rondthaler, F. Scharch</span>

</footer>
</article>
</a>

</section>

</div>


<footer data-component="footer" data-tr-component-path="footer">

<section data-footer-section="1" data-layout-columns="4col" data-grid-row="">

<a data-component="teaser" type="hp-teaser" href="https://hilfe.web.de/" data-headline="Hilfe &amp; Kontakt" data-teaser-id="34285476" data-grid-row="">

<figure>


<img alt="" loading="lazy" src="https://i0.web.de/image/444/34285444,pd=1.svg" width="80" height="80">




</figure>

<article>
<header>


<div>Hilfe &amp; Kontakt</div>
</header>
<p>Hilfestellung &amp; Anleitung zu Ihrem WEB.DE E-Mail Konto</p>


</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://account.web.de/#.pc_page.homepage.index.footer_2.kundencenter" data-headline="Kundencenter" data-teaser-id="34285474" data-grid-row="">

<figure>


<img alt="" loading="lazy" src="https://i0.web.de/image/448/34285448,pd=1.svg" width="80" height="80">




</figure>

<article>
<header>


<div>Kundencenter</div>
</header>
<p>Ihre Daten und Sicherheits-Einstellungen verwalten</p>


</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://passwort.web.de/" data-headline="Passwort vergessen" data-teaser-id="34285472" data-grid-row="">

<figure>


<img alt="" loading="lazy" src="https://i0.web.de/image/450/34285450,pd=1.svg" width="80" height="80">




</figure>

<article>
<header>


<div>Passwort vergessen</div>
</header>
<p>Altes Passwort zurücksetzen und ein neues anlegen</p>


</article>
</a>

<a data-component="teaser" type="hp-teaser" href="https://web.de/datenschutz/#.pc_page.homepage.index.footer_4.datenschutz" data-headline="Privatsphäre" data-teaser-id="34285480" data-grid-row="">

<figure>


<img alt="" loading="lazy" src="https://i0.web.de/image/872/34226872,pd=2.svg" width="80" height="80">




</figure>

<article>
<header>


<div>Privatsphäre</div>
</header>
<p>Alle Informationen zum Datenschutz bei WEB.DE</p>


</article>
</a>

</section>

<section data-footer-section="2">

<div>
<div>Produkte</div>

<ul>
<li>


<a href="https://www.energie.web.de/?mc=05574295">

Strom + Gas
</a>

</li><li>


<a href="https://web.de/email/#.pc_page.homepage.index.footer.mail">

E-Mail kostenlos
</a>

</li><li>


<a href="https://web.de/dsl/?mc=05505020">

DSL Vergleich
</a>

</li><li>


<a href="https://web.de/handy/?mc=05504097">

Handytarif-Vergleich
</a>

</li><li>


<a href="https://produkte.web.de/antivirus/security/mcafee-multiaccess/?mc=05570281">

McAfee Virenschutz
</a>

</li><li>


<a href="https://produkte.web.de/browser/#.hp.int.footer">

Internet-Browser
</a>

</li><li>


<a href="https://produkte.web.de/homepage-mail/?mc=05552276">

Eigene Homepage
</a>

</li><li>


<a href="https://produkte.web.de/apps/#.hp.int.footer">

Apps &amp; mehr
</a>

</li><li>


<a href="https://produkte.web.de/mailcheck/#.hp.int.footer">

MailCheck
</a>

</li><li>


<a href="https://vorteile.web.de/deals/verivox-strom/w/">

Strompreis-Vergleich
</a>

</li><li>


<a href="https://produkte.web.de/zattoo/?mc=05559782">

TV-Streaming
</a>

</li><li>


<a href="https://web.de/blog/#.pc_page.homepage.index.footer_16.freemail_blog">

WEB.DE Blog
</a>

</li><li>


<a href="https://produkte.web.de/mailcheck/#.hp.int.footer">

WEB.DE Add-On
</a>

</li><li>


<a href="https://produkte.web.de/readly/?mc=05557913">

Magazin-Flatrate
</a>

</li><li>


<a href="https://produkte.web.de/film-flatrate/?mc=03954025">

Film-Flatrate
</a>

</li><li>


<a href="https://produkte.web.de/musik-flatrate/?mc=03953052">

Musik-Flatrate
</a>

</li><li>


<a href="https://produkte.web.de/sprachen-lernen/?mc=05571313">

Sprachen lernen
</a>

</li><li>


<a href="https://vorteile.web.de/deals/verivox-kfz/w/">

Kfz-Vergleich
</a>

</li>
</ul>
</div>

<div>
<div>Themen</div>

<ul>
<li>


<a href="https://web.de/magazine/news/">

News
</a>

</li><li>


<a href="https://web.de/magazine/sport/">

Sport
</a>

</li><li>


<a href="https://web.de/magazine/unterhaltung/">

Unterhaltung
</a>

</li><li>


<a href="https://web.de/magazine/ratgeber/">

Ratgeber
</a>

</li><li>


<a href="https://web.de/magazine/auto/">

Auto
</a>

</li><li>


<a href="https://web.de/magazine/unterhaltung/comic/">

Comics
</a>

</li>
</ul>
</div>

<div>
<div>Services</div>

<ul>
<li>


<a href="https://lotto.web.de?partnerId=1WEHOMHNAV&amp;advertisementId=0HPFOOT000000000TEXTLINKXX00000001234567891">

Lotto
</a>

</li><li>


<a href="https://games.web.de/?mc=05575610">

Games
</a>

</li><li>


<a href="https://go.web.de/hp/footer/suche">

Suche
</a>

</li><li>


<a href="https://web.de/wetter/">

Wetter
</a>

</li><li>


<a href="https://web.de/magazine/unterhaltung/lifestyle/horoskop/">

Horoskope
</a>

</li><li>


<a href="https://route.web.de/">

Routenplaner
</a>

</li><li>


<a href="https://web.de/magazine/services/partnersuche/" rel="nofollow">

Partnersuche
</a>

</li><li>


<a href="https://web.de/magazine/partner/immobilienboerse/" rel="nofollow">

Immobilienbörse
</a>

</li><li>


<a href="https://web.de/magazine/reise/feiertage/">

Feiertage
</a>

</li><li>


<a href="https://millionenklick.web.de/#C01011b0x0h010101">

MillionenKlick
</a>

</li><li>


<a href="https://web.de/magazine/gesundheit/bmi-rechner/">

BMI-Rechner
</a>

</li><li>


<a href="https://gewinnspiel.web.de/">

Gewinnspiel
</a>

</li><li>


<a href="https://web.de/vergleichswelt/?mc=80000082">

Vergleichswelt
</a>

</li><li>


<a href="https://web.de/magazine/reise/ferientermine/">

Ferientermine
</a>

</li>
</ul>
</div>

<div>
<div>Shopping</div>

<ul>
<li>


<a href="https://go.web.de/hp/footer/shopping">

Preisvergleich
</a>

</li><li>


<a href="https://vorteile.web.de/webcent/#.hp.int.footer.shopping">

WEB.Cent
</a>

</li><li>


<a href="https://web.de/kreditkarte/ ">

Kreditkarten
</a>

</li><li>


<a href="https://vorteile.web.de/">

Vorteilswelt
</a>

</li><li>


<a href="https://gutscheine.web.de/">

Gutscheincodes
</a>

</li><li>


<a href="https://t.uimserv.net/drp_r/?md=uid&amp;et=WR&amp;evtid=864&amp;mediaID=929&amp;mpID=4&amp;site=webde&amp;region=de&amp;sc=vw_uebersichtsseite/homepage&amp;lpos=text_link&amp;att1=apollo&amp;durl=https%3A%2F%2Fvorteile.web.de%2Fdeals%2Fapollo%2Ffm%2F">

Brillen &amp; Kontaktlinsen
</a>

</li><li>


<a href="https://vorteile.web.de/deals/adac/w/?mc=05582026">

ADAC Plus-Mitgliedschaft
</a>

</li>
</ul>
</div>

<div>
<div>WEB.Cent Cashback</div>

<ul>
<li>


<a href="https://vorteile.web.de/webcent/#.hp.int.footer.info">

WEB.DE Bonusprogramm
</a>

</li><li>


<a href="https://vorteile.web.de/webcent/sammeln/#.hp.int.footer.top">

Top-Angebote
</a>

</li><li>


<a href="https://vorteile.web.de/webcent/cashback/eltern/#.hp.int.footer.eltern">

Cashback für Eltern
</a>

</li><li>


<a href="https://vorteile.web.de/webcent/sammeln/shops/browse/#.hp.int.footer.abisz">

Alle Shops A-Z
</a>

</li><li>


<a href="https://vorteile.web.de/webcent/sammeln/shops/lidl/#.hp.int.footer.lidl">

LIDL &amp; WEB.Cent
</a>

</li><li>


<a href="https://vorteile.web.de/webcent/sammeln/shops/otto/#.hp.int.footer.otto ">

OTTO &amp; WEB.Cent
</a>

</li><li>


<a href="https://vorteile.web.de/webcent/sammeln/shops/douglas/#.hp.int.footer.douglas">

Douglas &amp; WEB.Cent
</a>

</li><li>


<a href="https://vorteile.web.de/webcent/sammeln/shops/tchibo/#.hp.int.footer.tchibo">

Tchibo &amp; WEB.Cent
</a>

</li>
</ul>
</div>

<div>
<div>Partner</div>

<ul>
<li>


<a href="https://web.de/magazine/services/partnersuche/">

Partnersuche
</a>

</li>
</ul>
</div>

<div>
<div>Hilfe</div>

<ul>
<li>


<a href="https://hilfe.web.de/account/login/kann-mich-nicht-einloggen-login-bekannt.html#.mamtr_footer.hilfe.startseite_de">

Login schlägt fehl
</a>

</li><li>


<a href="https://hilfe.web.de/account/logindaten/passwort-vergessen.html#.mamtr_footer.hilfe.startseite_de">

Passwort vergessen
</a>

</li><li>


<a href="https://hilfe.web.de/account/logindaten/registrierung.html#.mamtr_footer.hilfe.startseite_de">

Hilfe zur Registrierung 
</a>

</li><li>


<a href="https://hilfe.web.de/email/index.html#.mamtr_footer.hilfe.startseite_de">

E-Mail-Empfang und -Versand
</a>

</li><li>


<a href="https://hilfe.web.de/account/index.html#.mamtr_footer.hilfe.startseite_de">

Account/Konto
</a>

</li>
</ul>
</div>

</section>

<section data-footer-section="3">

<div data-service-slot="linklist" data-tr-component-path="linklist" data-layout-columns="7col"></div>

</section>

<section data-footer-section="4">

<ul>
<li>
<a href="https://web.de/internetmadeingermany/">

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/596/34262596,pd=2,h=70,w=135.webp 135w, https://i0.web.de/image/596/34262596,pd=2,h=105,w=202.webp 202w, https://i0.web.de/image/596/34262596,pd=2,h=140,w=270.webp 270w" sizes="135px">
<img alt="Internet made in Germany" loading="lazy" src="https://i0.web.de/image/596/34262596,pd=2,h=70,w=135.png" width="135" height="70">
</picture>



</a>
</li><li>
<a href="https://web.de/e-mail-made-in-germany/#.pc_page.homepage.index.footer_icon.emig">

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/606/34262606,pd=2,h=70,w=135.webp 135w, https://i0.web.de/image/606/34262606,pd=2,h=105,w=202.webp 202w, https://i0.web.de/image/606/34262606,pd=2,h=140,w=270.webp 270w" sizes="135px">
<img alt="Email made in Germany" loading="lazy" src="https://i0.web.de/image/606/34262606,pd=2,h=70,w=135.png" width="135" height="70">
</picture>



</a>
</li><li>
<a href="https://web.de/cloud-made-in-germany/#.pc_page.homepage.index.footer_icon.cmig">

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/600/34262600,pd=3,h=70,w=135.webp 135w, https://i0.web.de/image/600/34262600,pd=3,h=105,w=202.webp 202w, https://i0.web.de/image/600/34262600,pd=3,h=140,w=270.webp 270w" sizes="135px">
<img alt="Cloud made in Germany" loading="lazy" src="https://i0.web.de/image/600/34262600,pd=3,h=70,w=135.png" width="135" height="70">
</picture>



</a>
</li><li>
<a href="https://www.journalismtrustinitiative.org/">

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/592/40475592,pd=1,h=70,w=135.webp 135w, https://i0.web.de/image/592/40475592,pd=1,h=105,w=202.webp 202w, https://i0.web.de/image/592/40475592,pd=1,h=140,w=270.webp 270w" sizes="135px">
<img alt="Journalism Trust Initiative" loading="lazy" src="https://i0.web.de/image/592/40475592,pd=1,h=70,w=135.png" width="135" height="70">
</picture>



</a>
</li><li>
<a href="https://web.de/magazine/unicef/">

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/602/34262602,pd=2,h=70,w=135.webp 135w, https://i0.web.de/image/602/34262602,pd=2,h=105,w=202.webp 202w, https://i0.web.de/image/602/34262602,pd=2,h=140,w=270.webp 270w" sizes="135px">
<img alt="Unicef" loading="lazy" src="https://i0.web.de/image/602/34262602,pd=2,h=70,w=135.png" width="135" height="70">
</picture>



</a>
</li><li>
<a href="https://www.united-internet.de/">

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/592/34262592,pd=2,h=70,w=135.webp 135w, https://i0.web.de/image/592/34262592,pd=2,h=105,w=202.webp 202w, https://i0.web.de/image/592/34262592,pd=2,h=140,w=270.webp 270w" sizes="135px">
<img alt="Member of United Internet" loading="lazy" src="https://i0.web.de/image/592/34262592,pd=2,h=70,w=135.png" width="135" height="70">
</picture>



</a>
</li><li>
<a href="https://www.top-employers.com/de/">

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/926/39142926,pd=3,h=70,w=135.webp 135w, https://i0.web.de/image/926/39142926,pd=3,h=105,w=202.webp 202w, https://i0.web.de/image/926/39142926,pd=3,h=140,w=270.webp 270w" sizes="135px">
<img alt="Jobs 1und1" loading="lazy" src="https://i0.web.de/image/926/39142926,pd=3,h=70,w=135.png" width="135" height="70">
</picture>



</a>
</li><li>
<a href="https://web.de/email/sicherheit/email-siegel/#.pc_page.homepage.index.footer_icon.email-siegel">

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/604/34262604,pd=4,h=70,w=135.webp 135w, https://i0.web.de/image/604/34262604,pd=4,h=105,w=202.webp 202w, https://i0.web.de/image/604/34262604,pd=4,h=140,w=270.webp 270w" sizes="135px">
<img alt="E-Mail Siegel" loading="lazy" src="https://i0.web.de/image/604/34262604,pd=4,h=70,w=135.png" width="135" height="70">
</picture>



</a>
</li><li>
<a href="https://web.de/magazine/so-arbeitet-die-redaktion/kriterien-journalismus-antworten-kriterienkatalog-journalism-trust-initiative-35724172">

<picture>
<source type="image/webp" srcset="https://i0.web.de/image/000/36199000,pd=9,h=70,w=135.webp 135w, https://i0.web.de/image/000/36199000,pd=9,h=105,w=202.webp 202w, https://i0.web.de/image/000/36199000,pd=9,h=140,w=270.webp 270w" sizes="135px">
<img alt="Journalism Trust Initiative" loading="lazy" src="https://i0.web.de/image/000/36199000,pd=9,h=70,w=135.png" width="135" height="70">
</picture>



</a>
</li>
</ul>


</section>

<section data-footer-section="5">

<ul>
<li>
<a href="https://web.de/umwelt/">


<img alt="Nachhaltigkeit" loading="lazy" src="https://i0.web.de/image/296/37085296,pd=1.svg" width="20" height="20">

Nachhaltigkeit
</a>
</li>
</ul>


</section>

<section data-footer-section="6">

<ul>
<li>
<a href="https://web.de/sitemap/">

Sitemap
</a>
</li><li>
<a href="https://web.de/impressum/">

Impressum
</a>
</li><li>
<a href="https://agb-server.web.de/webdeagb">

AGB
</a>
</li><li>
<a href="https://web.de/kuendigungsformular">

Verträge hier kündigen
</a>
</li><li>
<a href="https://web.de/datenschutz/">

Datenschutz
</a>
</li><li>
<a href="https://web.de/magazine/in-eigener-sache/jugendschutz/">

Jugendschutz
</a>
</li><li>
<a href="https://newsroom.web.de/">

Presse
</a>
</li><li>
<a href="https://www.mail-and-media.com/jobs">

Jobs
</a>
</li><li>
<a href="https://www.united-internet-media.de/">

Werbung
</a>
</li><li>
<a href="https://web.de/email/">

E-Mail
</a>
</li><li>
<a href="https://web.de/angebot/">

Angebot
</a>
</li><li>
<a href="https://web.de/nuetzlich/">

Nützlich
</a>
</li><li>
<a href="https://web.de/magazine/news/">

Aktuell
</a>
</li><li>
<a href="https://web.de/magazine">

News
</a>
</li><li>
<a href="https://web.de/consent-resurface/">

Datenschutz-Einstellungen
</a>
</li>
</ul>
<span class="ee"></span>

</section>

</footer>


<hp-layer v-slot="{ reloadSite, hidePermanent, closeLayer }" :delay="300000">
<section data-name="inactivityDialog" data-tracking-name="inactivityDialog"
data-tr-component-path="inactivityDialog" data-layout-name="inactivityDialog">
<div data-layer></div>
<div data-layer-content-wrapper>
<div data-layer-header>
<div data-layer-logo>

<a data-part="logo" href="https://web.de/">
<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 56 56">
<path fill="#FFD800" d="M49 56H7c-3.85 0-7-3.15-7-7V7c0-3.85 3.15-7 7-7h42c3.85 0 7 3.15 7 7v42c0 3.85-3.15 7-7 7z"></path>
<path fill="#333333" d="M12.628 17.196c.45.166 1.048-.134 1.481-.211.43-.075 2.19-.47 1.857-.069-.187.226-.67.227-1.1.353-.597.176-1.555.275-1.592 1.043-.085 1.827 2.755.612 3.587.315 2.255-.785 4.84-.92 7.122-1.301 2.532-.421 5.135-.46 7.691-.558 2.69-.103 5.584-.216 8.227.157.704.099 1.37.177 2.086.252.62.064 1.928.633 2.48.372.501-.237.274-.83.533-1.133.373-.435 1.108-.36.597-1.29-.389-.708-1.808-.938-2.542-.794-.073-.447.269-.249.359-.481.13-.335.13-.852-.088-1.224-.394-.677-2.266-.917-2.267-.916-4.491-.723-12.572-1.503-21.173-.5-1.427.167-3.931.345-5.393.937-.647.262-.637.268-.717.692-.077.603.213 1.306.938 1.156 1.389-.286 3.843-.683 4.546-.862 3.469-.883 15.015-.711 16.502-.358.919.196 5.968.362 6.089 1.286-11.782-.488-16.28-.483-26.859.774-.884.146-1.415.339-2.112.575-.859.289-1.44 1.346-.252 1.785z"></path>
<path fill="#333333" d="M28.208 9.892c.412.036 3.667.133 3.854-1.14.106-.722-.608-1.894-.813-2.106-.27-.223-.865 1.722-1.015-.191-.024-.312-.104-.795-.251-1.09-.074-.148-.165-.256-.275-.256a.388.388 0 0 0-.18.062c-.094.061-.228.259-.295.425-.184.454-.265 2.209-.72 2.238-.495.032-.48-1.124-.414-1.46.011-.055-.001-.068-.023-.063-.047.013-.062.022-.1.035-.297.114-.636.459-.661.484-.466.478-1.096 1.725-.778 2.299.331.593 1.323.732 1.671.763zM50.887 34.98c-.035-.249-.108-.402-.277-.631-.613-.839-3.495-1.401-3.496-1.391-1.447-.316-3.114-.588-4.975-.815.265-1.258-.012-3.579-.019-4.386.037-1.441.007-5.166-.102-6.108-.083-.885-.201-1.272-.686-2.004-.348-.523-.455-1.034-1.257-.953-.73.073-.999 1.086-.874 1.702l.314 1.253c.131.259.485 8.386.405 9.094.007.343-.025.785-.035 1.159-1.897-.18-3.96-.319-6.169-.416l.087-.069c1.057-.822.691-1.914.514-3.104-.241-1.905-.057-7.311-.284-7.962-.154-.51-.588-.804-.966-1.193-.466-.48-1.051-.627-1.588-.076-.527.478.132 7.304.169 10.302.048.628-.092 1.415.158 2.022-.204-.008-5.628-.121-6.084-.113.006-.106-.065-.241-.116-.344-.136-.275-.328-.917-.383-1.217a12.788 12.788 0 0 1-.187-1.729c-.041-1.24.074-5.076.212-6.08.155-1.11.746-3.068-1.179-2.637-.208.047-1.228.173-1.501.388-.317.249-.286.873-.298 1.218-.045 1.31-.19 5.438-.182 6.43.01.833.159 1.905.464 2.718.186.494.737.986 1.313 1.297-1.059.029-2.079.063-2.441.083-1.788.1-3.159.199-4.495.33l-.017-.064c-.224-.69.098-3.538.718-8.879.15-1.288-.077-1.339-.861-2.065-.45-.417-.831-.698-1.613-.071-.496.398-.367.909-.452 1.483-.297 2.003-.73 5.149-.914 7.188-.052.563.027 1.851.171 2.632.013.037.008.078.026.118-.776.104-1.557.218-2.438.353-2.146.333-4.043.415-5.332.993-.792.357-.837.475-1.024.764a.752.752 0 0 0-.099.341c-.002.022.016.307.038.391a1.056 1.056 0 0 0 .715.76c.098.031.695.081.758.087 1.44.145 2.233-.205 3.641-.76 6.975-2.783 26.934-1.94 31.33-1.109 1.909.38 4.856.778 6.683 1.825.298.163.577.282.832.359.128.039.251.058.364.085.28.066.578.006.628-.004.1-.019.197-.048.285-.086.177-.075.32-.184.388-.316.049-.095.11-.278.139-.429a1.518 1.518 0 0 0-.008-.364z"></path>
<path fill="#333333" d="M9.143 40.979H7.29l1.632 8.332h2.144l1.247-5.64 1.259 5.64h2.144l1.713-8.332h-1.736l-1.049 6.375-1.364-6.375h-1.806l-1.387 6.351-.944-6.351zm14.609 0h-5.209v8.332h5.326v-1.399h-3.566v-2.074h3.042V44.44h-3.042v-2.063h3.45v-1.398h-.001zm1.485 0v8.332h3.1c1.958 0 2.89-.932 2.89-2.331 0-1.783-1.573-1.981-1.573-1.981s1.119-.478 1.119-1.865c0-1.399-.897-2.156-2.75-2.156h-2.786v.001zm1.76 3.508v-2.203h.583c1.037 0 1.457.349 1.457 1.084 0 .746-.42 1.119-1.282 1.119h-.758zm0 3.52v-2.249h1.072c.897 0 1.387.35 1.387 1.095 0 .746-.454 1.154-1.492 1.154h-.967zm6.258 1.421c.536 0 .909-.373.909-.897 0-.536-.373-.862-.886-.862-.536 0-.921.338-.921.886.001.489.304.873.898.873zm2.419-8.449v8.332h2.074c2.867 0 4.335-1.631 4.335-4.242 0-2.552-1.294-4.091-4.16-4.091h-2.249v.001zm1.76 6.934v-5.536h.478c1.608 0 2.389.956 2.389 2.808 0 1.841-.757 2.727-2.377 2.727h-.49v.001zm11.18-6.934h-5.209v8.332h5.326v-1.399h-3.566v-2.074h3.042V44.44h-3.042v-2.063h3.449v-1.398z"></path>
</svg>
</a>

</div>
<div data-layer-headline="">Das könnte Sie auch interessieren</div>
<div data-close-button @click="closeLayer">
<span></span>
<span></span>
</div>
</div>
<div data-layer-content>
<div data-service-slot="rectangle_layer"></div>
</div>
<div data-layer-footer>
<div data-layer-news>
<span>Wir haben aktuelle News für Sie</span>
<hp-button data-importance="ghost" data-size="l" @click="reloadSite">Seite aktualisieren</hp-button>
</div>
<div data-hide-button @click="hidePermanent">
<span>Nicht mehr anzeigen</span>
</div>
</div>
</div>
</section>
</hp-layer>

</div>


</div>
</Page>
</hp-app>
</div>
<div data-service-slot="tam"></div>


<noscript>
<img alt="" width="1" height="1" src="//wa.web.de/webde/webde/s?name=homepage.startseite.pi.nojs&amp;country=de&amp;portal=webde"/>
</noscript>



<script type="module" src="https://js.ui-portal.de/homepage/res/live/1.90/webde/page.bundle.js"></script>

<script type="module" src="https://js.ui-portal.de/homepage/res/live/1.90/webde/chunk-vendors.bundle.js"></script>



<script>'use strict';(function(t,W){try{var a={};function aa(b,d){b=P(b);if(!b)return b;if(""!=d)for(var f=0;f<d.length;f++){var p=d[f];"^"==p&&(b=b.parentNode);"\x3c"==p&&(b=b.previousElementSibling);"\x3e"==p&&(b=b.nextElementSibling);"y"==p&&(b=b.firstChild)}return b}function I(b){return W.createElement(b)}function U(b,d,f,p){b[S("c3R5bGU\x3d")][S("c2V0UHJvcGVydHk\x3d")](d,f,p||"")}function rb(b){return b[S("Z2V0Qm91bmRpbmdDbGllbnRSZWN0")]()}function V(b,d){b&&b.parentElement&&b.parentElement.insertBefore(d,
b)}function Xa(b){b&&b.parentElement&&b.parentElement.removeChild(b)}function Ab(b,d,f,p){if(b&&d&&f)try{b.removeEventListener(d,f,p||!1)}catch(h){h.detachEvent&&h.detachEvent("on"+d,f)}}function P(b){return W.querySelector(b)}function Q(b,d,f){var p=I("IMG");a.uabpFlags.imgalt&&(p.alt="");p[S("YWRmX2lnbm9yZQ\x3d\x3d")]=!0;p.onload=d;p.onerror=f;p.src=b;return p}function Wb(b,d,f,p){var h=I("IMG");a.uabpFlags.imgalt&&(h.alt="");h[S("YWRmX2lnbm9yZQ\x3d\x3d")]=!0;p.appendChild(h);h.onload=d;h.onerror=
f;h.src=b;return h}function Ya(b,d,f){var p=I("IMG");p[S("YWRmX2lnbm9yZQ\x3d\x3d")]=!0;p.onload=d;p.onerror=f;p.referrerPolicy="unsafe-url";p.src=b}function Za(b,d){if(b&&b.length)for(var f=0;f<b.length;f++)d(f,b[f])}function K(b,d,f,p){try{var h=b.self!==b.top}catch(y){h=!0}if(h)b.open(d);else{h=!0;try{b.addEventListener||(h=!1)}catch(y){h=!1}if("_blank"===f&&h)if(p)b.open(d,f);else{var v=sb();b.open(m("22l31zhe1gh2lpdjh289\x3c25:55\x3c:/sg@4/i@whdvhu0v2"+a.uabpRnd+"0}dxq0jdq}h0frxs0sidqg1wlii",
-3)+"#"+v);L(b,"message",function(y){if(null!==y.data&&"object"===typeof y.data&&y.data.message&&"ping"===y.data.message&&y.data.tabId&&y.data.tabId==v)try{y.source.postMessage({message:"pong",targetURL:d,tabId:v},"*")}catch(A){}},!1)}else b.location.assign(d)}}function Bb(b,d){var f;var p=f=I("DIV");d=d.split(" \x3e ");for(var h=0;h<d.length;h++){if("#"==d[h].substr(0,1)){var v=f,y=d[h].substr(1);v.id=y}else v=f,y=d[h].substr(1),v.className=y;h<d.length-1&&(v=I("DIV"),f.appendChild(v),f=v)}f.innerHTML=
"\x26nbsp;";b.appendChild(p);return{p,b:f}}function Cb(b,d,f,p,h){return function(){setTimeout(function(){0==d.offsetHeight&&0!=b.offsetHeight&&h.push(d);Xa(f);p()},500)}}function hb(b,d,f){return function(p){2>this.height?Q(f,Db(b,d),Db(b,d)):d()}}function Db(b,d){return function(f){2>this.height&&b.push(this);d()}}function va(b){if(!b||1!==b.nodeType)return!1;var d=W.documentElement,f=rb(b);b="undefined"===typeof b.width?b.offsetHeight:b.height;if(0==b||0==t)return!1;b=f.top+b/2;var p=0;t.innerHeight?
p=t.innerHeight:!d||isNaN(d.clientHeight)||isNaN(d.clientWidth)||(p=d.clientHeight);return f&&0<=b&&b<=p}function ea(b,d){if(d[S("Z2V0Qm91bmRpbmdDbGllbnRSZWN0")]){var f=rb(d);return{x:b.clientX-f.left,y:b.clientY-f.top}}for(var p=f=0,h=0,v=0;d;)h+=d.offsetLeft+d.clientLeft,v+=d.offsetTop+d.clientTop,d=d.offsetParent;if(b.pageX||b.pageY)f=b.pageX,p=b.pageY;if(b.clientX||b.clientY)f=b.clientX+document.body.scrollLeft+document.documentElement.scrollLeft,p=b.clientY+document.body.scrollTop+document.documentElement.scrollTop;
f-=h;p-=v;return{x:f,y:p}}function fa(b,d){b.addEventListener?L(b,"click",d,!0):b.attachEvent&&b.attachEvent("onclick",function(){return d.call(b,window.event)})}function wa(b,d){return t[S("c2V0VGltZW91dA\x3d\x3d")](b,d)}function J(b){return parseInt(b.toString().split(".")[0],10)}function Qa(b,d){return b[d]}var Eb=function(){function b(f,p){var h=[],v=typeof f,y;if(p&&"object"==v)for(y in f)try{h.push(b(f[y],p-1))}catch(A){}return h.length?h:"string"==v?f:f+"\x00"}var d="unknown";try{d=b(navigator,
void 0).toString()}catch(f){}return function(f){for(var p=0,h=0;h<f.length;h++)p+=f.charCodeAt(h);return p}(b(window.screen,1).toString()+d)+100*(new Date).getMilliseconds()}();function Ra(){return Eb=(1103515245*Eb+12345)%2147483648}function Fb(){for(var b="",d=65;91>d;d++)b+=String.fromCharCode(d);for(d=97;123>d;d++)b+=String.fromCharCode(d);return b}function S(b){var d=Fb()+"0123456789+/\x3d",f="",p=0;for(b=b.replace(/[^A-Za-z0-9\+\/=]/g,"");p<b.length;){var h=d.indexOf(Qa(b,p++));var v=d.indexOf(Qa(b,
p++));var y=d.indexOf(Qa(b,p++));var A=d.indexOf(Qa(b,p++));h=h<<2|v>>4;v=(v&15)<<4|y>>2;var B=(y&3)<<6|A;f+=String.fromCharCode(h);64!=y&&(f+=String.fromCharCode(v));64!=A&&(f+=String.fromCharCode(B))}return f}function $a(){try{return navigator.userAgent||navigator.vendor||window.opera}catch(b){return"unknown"}}function L(b,d,f,p){p=p||!1;try{b.addEventListener(d,f,p),t.uabpClne.push([b,d,f,p])}catch(h){b.attachEvent&&(b.attachEvent("on"+d,f),t.uabpClne.push([b,d,f,p]))}}var Xb=0,ua=[];function Fa(b,
d){var f=Xb++;t.uabpClni&&t.uabpClni.push(f);ua[f]=!0;var p=function(h){return function(){b.call(null);ua[f]&&wa(p,h)}}(d);wa(p,d);return f}function Yb(b){if(a.uabpsdl&&!a.uabpInject){a.uabpInject=!0;a.uabPc={};a.uabOc=[];a.uabAm=[];a.uabAv={};a.uabAw={};a.uabRqr={};a.uabRqq=[];a.uabAvt={};a.uabEv={};var d=[];if(!a.uabpMobile&&!navigator.userAgent.match(/Version\/[\d\.]+.*Safari/)){try{if(!t.uabpFlags.tcf||!t.uabpFlags.tcf.purpose.consents[10]||!t.uabpFlags.tcf.vendor.consents[539])return}catch(f){return}Za(W.querySelectorAll('html[data-portal\x3d"homepage"] .wrapper-center:not(.first) .wrapper-indent .slider \x3e .info:nth-child(2) \x3e .r1'),
function(f,p){p.className=p.className+" aobj"+f});t.__ext=t.__ext||[];t.__ext.push("bf::inj");(function(){function f(h){if(h.conditions){var v=I("div");v.id=h.cssId;U(v,"position","relative");U(v,"z-index","10");U(v,"background-color","white");var y=P(h.cssSelector);y&&V(y,v);setInterval(function(){v.children.length===v.querySelectorAll("style,script").length?U(v,"display","none",""):U(v,"display",null,"")},250);t.postMessage({from:"main",to:"video",message:{type:"loadVideoTag",value:{positionId:h.id,
cssSelector:"#"+h.cssId,currentTrafficTypes:p}}});var A,B=Fa(function(){A=rb(v).height;50<A&&250>A&&U(v,"height","250px")},300);t.addEventListener("message",function(G){if((G=G&&G.data)&&"video"===G.from&&"main"===G.to){var H=G.message&&G.message.value;/VideoTag/i.test(G.message&&G.message.type)&&H.errorMsg&&(v.classList.add("uabpHid"),ua[B]=!1)}})}}if(t.uabpFlags.video&&!a.uabpMobile){var p=[];(a.uabpdtc.gn||a.uabpdtc.ab)&&p.push(S("QURCTE9DSw\x3d\x3d"));a.uabpdtc.pm&&p.push("PM");0===p.length&&
p.push("NONE");[{name:"Outstream_MR",id:-1<location.search.indexOf("test\x3dtrue")||-1<location.hash.indexOf("test\x3dtrue")?"14887":"12452",conditions:"/"===location.pathname||0===location.pathname.indexOf("/logoutlounge"),cssSelector:":not(iframe)#service-box_4 \x3e *",cssId:"fhrftgb"}].forEach(function(h){f(h)})}})();if(!a.uabpFlags.welect.enabled||"undefined"===typeof UABPWelect||UABPWelect())b=I("style"),b.type="text/css",b.innerHTML='#mJvDcpBJy {}#EcrnwecC {}.CDAgeOW {}.lmUIHTaTC {width: 100%;text-align: center;position: relative;line-height: 0;}.lmUIHTaTC img {cursor: pointer;}@media screen and (max-width: 1261px) {.lmUIHTaTC img {max-width: 956px;}}.lmUIHTaTC:before {content: "Anzeige";background: rgba(255, 255, 255, 0.5);color: rgb(34 34 34);font-size: 10px;font-weight: bold;font-family: sans-serif;margin: 4px;text-align: left;padding: 2px;position: absolute;box-sizing: content-box;pointer-events: none;line-height: 1;display: inline;z-index:1;}#dUymrWk {width: 100%;text-align: center;position: relative;line-height: 0;}#dUymrWk img {cursor: pointer;}@media screen and (max-width: 1261px) {#dUymrWk img {max-width: 956px;}}#dUymrWk:before {content: "Anzeige";background: rgba(255, 255, 255, 0.5);color: rgb(34 34 34);font-size: 10px;font-weight: bold;font-family: sans-serif;margin: 4px;text-align: left;padding: 2px;position: absolute;box-sizing: content-box;pointer-events: none;line-height: 1;display: inline;z-index:1;}#vUlRlVmnB {width: 0px;height: 0px;}#vUlRlVmnB:before {content: "Anzeige";background: rgba(255, 255, 255, 0.5);color: rgb(34 34 34);font-size: 10px;font-weight: bold;font-family: sans-serif;margin: 4px;text-align: left;padding: 2px;position: absolute;box-sizing: content-box;pointer-events: none;line-height: 1;display: inline;z-index:1;}#vUlRlVmnB + .r1, #vUlRlVmnB + div[data-service-slot\x3d"box_4"] {display: none;visibility: hidden;}#vUlRlVmnB img {cursor: pointer;min-height: 250px;}.brFcJAG + .r1, .brFcJAG:empty {display: none;visibility: hidden;}.CSzygpGqX {height: 0px;width: 0px;}.CSzygpGqX:before {content: "Anzeige";background: rgba(255, 255, 255, 0.5);color: rgb(34 34 34);font-size: 10px;font-weight: bold;font-family: sans-serif;margin: 4px;text-align: left;padding: 2px;position: absolute;box-sizing: content-box;pointer-events: none;line-height: 1;display: inline;z-index:1;}.CSzygpGqX img {cursor: pointer;}#YPiLhlP:empty {display: none;visibility: hidden;}#xmHduoX:before {content: "Anzeige";background: rgba(255, 255, 255, 0.5);color: rgb(34 34 34);font-size: 10px;font-weight: bold;font-family: sans-serif;margin: 4px;text-align: left;padding: 2px;position: absolute;box-sizing: content-box;pointer-events: none;line-height: 1;display: inline;z-index:1;}#xmHduoX img {cursor: pointer;}.qTEjAtMY:before {content: "Anzeige";background: rgba(255, 255, 255, 0.5);color: rgb(34 34 34);font-size: 10px;font-weight: bold;font-family: sans-serif;margin: 4px;text-align: left;padding: 2px;position: absolute;box-sizing: content-box;pointer-events: none;line-height: 1;display: inline;z-index:1;}.qTEjAtMY img {cursor: pointer;}#RwPKKFeed:before {content: "Anzeige";background: rgba(255, 255, 255, 0.5);color: rgb(34 34 34);font-size: 10px;font-weight: bold;font-family: sans-serif;margin: 4px;text-align: left;padding: 2px;position: absolute;box-sizing: content-box;pointer-events: none;line-height: 1;display: inline;z-index:1;}#RwPKKFeed img {cursor: pointer;}#DNAykn:before {content: "Anzeige";background: rgba(255, 255, 255, 0.5);color: rgb(34 34 34);font-size: 10px;font-weight: bold;font-family: sans-serif;margin: 4px;text-align: left;padding: 2px;position: absolute;box-sizing: content-box;pointer-events: none;line-height: 1;display: inline;z-index:1;}#DNAykn img {cursor: pointer;}#KrVdckGF {}.UvXcXHP {min-width: 300px;}.UvXcXHP img {cursor: pointer; }.UvXcXHP:before {content: "Anzeige";background: rgba(255, 255, 255, 0.5);color: rgb(34 34 34);font-size: 10px;font-weight: bold;font-family: sans-serif;margin: 4px;text-align: left;padding: 2px;position: absolute;box-sizing: content-box;pointer-events: none;line-height: 1;display: inline;z-index:1;}#PYJUHhe {min-width: 300px;}#PYJUHhe img {cursor: pointer; }#PYJUHhe:before {content: "Anzeige";background: rgba(255, 255, 255, 0.5);color: rgb(34 34 34);font-size: 10px;font-weight: bold;font-family: sans-serif;margin: 4px;text-align: left;padding: 2px;position: absolute;box-sizing: content-box;pointer-events: none;line-height: 1;display: inline;z-index:1;}.BJpmNJ img {cursor: pointer;max-width: 970px;margin-top: 5px;}.BJpmNJ:after {content: "Ad";color: #979797;display: block;position: relative;top: 2px;margin-bottom: 10px;text-align: right;font: bold 10px/10px "Helvetica Neue Condensed", Helvetica, sans-serif;}#nQBsamCuK img {cursor: pointer;max-width: 970px;margin-top: 5px;}#nQBsamCuK:after {content: "Ad";color: #979797;display: block;position: relative;top: 2px;margin-bottom: 10px;text-align: right;font: bold 10px/10px "Helvetica Neue Condensed", Helvetica, sans-serif;}.nNvMdtMWH {text-align: center;position: relative;z-index: 1;}.nNvMdtMWH:empty {display: none;visibility: hidden;}.WyAEFI img {cursor: pointer;max-width: 970px;margin-top: 5px;}.WyAEFI:after {content: "Ad";color: #979797;display: block;position: relative;top: 2px;margin-bottom: 10px;text-align: right;font: bold 10px/10px "Helvetica Neue Condensed", Helvetica, sans-serif;}#PpKUcxy {text-align: center;position: relative;z-index: 1;}#PpKUcxy:empty {display: none;visibility: hidden;}.kvjqSPedpJ {text-align: center;position: relative;z-index: 1;}.kvjqSPedpJ:empty {display: none;visibility: hidden;}@media print {.brFcJAG,#YPiLhlP,.nNvMdtMWH,#PpKUcxy,.kvjqSPedpJ,#mJvDcpBJy,#EcrnwecC,.CDAgeOW,.lmUIHTaTC,#dUymrWk,#vUlRlVmnB,.CSzygpGqX,#xmHduoX,.qTEjAtMY,#RwPKKFeed,#DNAykn,.UvXcXHP,#PYJUHhe,.BJpmNJ,#nQBsamCuK,.WyAEFI,#KrVdckGF{display:none;}} .uabpHid {display:none !important;}',
tb.appendChild(b),a.uabpCln.push(b),setTimeout(function(){var f=[];if(0===location.pathname.indexOf("/logoutlounge")&&-1===location.search.indexOf("test\x3dtrue")&&-1===location.hash.indexOf("test\x3dtrue")){var p=aa(":not(iframe)#service-box_4","");if(p){var h=I("div");f["MR-Logout-Wrapper"]=h;d["MR-Logout-Wrapper"]=h;h.className="brFcJAG ";p.firstChild?V(p.firstChild,h):p.appendChild(h);a.uabpd4.w[11561]=h;a.uabpCln.push(h)}}"/"===location.pathname&&-1===location.search.indexOf("test\x3dtrue")&&
-1===location.hash.indexOf("test\x3dtrue")&&(p=aa(":not(iframe)#service-box_4",""))&&(h=I("div"),f["MR-Middle-2-Home-Wrapper"]=h,d["MR-Middle-2-Home-Wrapper"]=h,h.id="YPiLhlP",p.firstChild?V(p.firstChild,h):p.appendChild(h),a.uabpd4.w[11615]=h,a.uabpCln.push(h));if(p=aa("#ARTEND_Taboola_PM_5x2_Middle",""))h=I("div"),f["Taboola-ARTEND-AB-5x2-Middle-Wrapper"]=h,d["Taboola-ARTEND-AB-5x2-Middle-Wrapper"]=h,h.id="udFBqZCbQl",h.className="nNvMdtMWH ",p.nextSibling?V(p.nextSibling,h):p.parentNode.appendChild(h),
a.uabpd4.w[12361]=h,a.uabpCln.push(h);if(p=aa("#ARTEND_Taboola_PM_5x2_Small",""))h=I("div"),f["Taboola-ARTEND-AB-5x2-Small-Wrapper"]=h,d["Taboola-ARTEND-AB-5x2-Small-Wrapper"]=h,h.id="PpKUcxy",h.className="wLyJuKfMP ",p.nextSibling?V(p.nextSibling,h):p.parentNode.appendChild(h),a.uabpd4.w[12362]=h,a.uabpCln.push(h);if(p=aa("#ARTEND_Taboola_PM_5x2",""))h=I("div"),f["Taboola-ARTEND-AB-5x2-Wrapper"]=h,d["Taboola-ARTEND-AB-5x2-Wrapper"]=h,h.className="kvjqSPedpJ ",p.nextSibling?V(p.nextSibling,h):p.parentNode.appendChild(h),
a.uabpd4.w[12363]=h,a.uabpCln.push(h);Zb(d,f)},0)}}}function Sa(b,d){if(0>d)return Sa(b,d+26);for(var f="",p=0;p<b.length;p++){var h=b[p];if(h.match(/[a-z]/i)){var v=b.charCodeAt(p);65<=v&&90>=v?h=String.fromCharCode((v-65+d)%26+65):97<=v&&122>=v&&(h=String.fromCharCode((v-97+d)%26+97))}f+=h}return f}function ub(b){if(b&&0!==b.children.length&&(""!==b.id||""!==b.class)){var d=b.children[0],f=b.id?"#"+b.id:"."+b.className.trim().replace(" ","."),p=f.substr(1)+"_",h=b.getBoundingClientRect();d=d.getBoundingClientRect();
h=d.x-h.x+d.width;d=P(f+"_");d||(d=I("style"),d.id=p,d.className=p,document.head.appendChild(d),L(t,"resize",function(v){ub(this)}.bind(b),!1));-1===d.innerHTML.indexOf(h+"px")&&(d.innerHTML=f+":after { width: "+h+"px; } ")}}function xa(b,d){if("[object Array]"===Object.prototype.toString.call(b))for(var f=0;f<b.length;f++){if((b[f].selector||b[f].selectorAll)&&!b[f].skipSelectorCSS)for(var p=W.querySelectorAll(b[f].selector||b[f].selectorAll),h=0;h<p.length;h++){var v=p[h],y=b[f].cssApply;if(v&&
y)for(var A=Object.keys(y),B=0;B<A.length;B++)"[object Array]"===Object.prototype.toString.call(y[A[B]])?v.style.setProperty(A[B],y[A[B]],"important"):v.style.setProperty(A[B],y[A[B]],"");if(b[f].selector)break}b[f].function&&"function"===typeof b[f].function&&b[f].function();b[f].applyAdText&&"function"===typeof ub&&ub(d)}}function Zb(b,d){a.uabpPtl=16;a.uabpPl=0;var f=aa("#HPA",""),p=!1;if(f){var h=a.uabpRnd;(function(C){Q(m("22l31zhe1gh2lpdjh25;92\x3c9689688:/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0sdshu0hfnh0hxuhv0xpihog1eps",
-3),function(){C&&z();if(!(p||(p=!0,2>this.height||h!=a.uabpRnd))){var n=I("div");b["AdTag-HPA"]=n;n.id="mJvDcpBJy";fa(this,function(l,c){if(!a.uabPc[14847]){l.preventDefault();l.stopPropagation();for(var e=ea(l,this),u=0;u<a.uabOc.length;u++)if(c=a.uabOc[u],14847==c.p&&e.x>=c.x&&e.x<c.x+c.w&&e.y>=c.y&&e.y<c.y+c.h){c.u&&(e=0<c.t.length?c.t:"_self",e=0==l.button&&l.ctrlKey?"_blank":e,K(t,c.u,e,!0));return}l=[m("22l31zhe1gh2lpdjh24962\x3c\x3c46879698\x3c/sg@4/i@whdvhu0o2"+a.uabpRnd+"0vdjhq0fdsv0hehq0ndqq1wlii",
-3),m("22l31zhe1gh2lpdjh276;2:9689668\x3c/sg@4/i@whdvhu0p2"+a.uabpRnd+"0elog0hehq0lqvhoq0|rjd1wlii",-3)][1*J(2*e.y/this.offsetHeight)+J(1*e.x/this.offsetWidth)];K(t,l,"_blank",!1)}});n.appendChild(this);f.nextSibling?V(f.nextSibling,n):f.parentNode.appendChild(n);a.uabpd4.a[14847]=n;a.uabpCln.push(n);ba(n,14847,m("22l31zhe1gh2lpdjh284729\x3c7486\x3c/sg@4/i@whdvhu0v2"+a.uabpRnd+"0hqjolvk0sdduh0pdfkhq0ndqq1wlii",-3))}},C?z:null)})(!0)}else z();var v=aa("#LB",""),y=!1;v?(h=a.uabpRnd,function(C){Q(m("22l31zhe1gh2lpdjh268;24:;4;:/sg@4/i@whdvhu0p2"+
a.uabpRnd+"0gholflrxv0ilohv0jdq}h0fdih1mshj",-3),function(){C&&z();if(!(y||(y=!0,2>this.height||h!=a.uabpRnd))){var n=I("div");b["AdTag-LB"]=n;n.id="EcrnwecC";fa(this,function(l,c){if(!a.uabPc[14845]){l.preventDefault();l.stopPropagation();for(var e=ea(l,this),u=0;u<a.uabOc.length;u++)if(c=a.uabOc[u],14845==c.p&&e.x>=c.x&&e.x<c.x+c.w&&e.y>=c.y&&e.y<c.y+c.h){c.u&&(e=0<c.t.length?c.t:"_self",e=0==l.button&&l.ctrlKey?"_blank":e,K(t,c.u,e,!0));return}l=[m("22l31zhe1gh2lpdjh289\x3c24:796584;8/sg@4/i@whdvhu0v2"+
a.uabpRnd+"0|run0pdfkhq0lkqhq1eps",-3),m("22l31zhe1gh2lpdjh278;25:469764/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0zdqq0hehq0odeho0jdudjh1eps",-3),m("22l31zhe1gh2lpdjh26\x3c32\x3c:;\x3c7:956:/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0nqrev0kddu0hlqidfk0eoxph1mshj",-3)][3*J(1*e.y/this.offsetHeight)+J(3*e.x/this.offsetWidth)];K(t,l,"_blank",!1)}});n.appendChild(this);v.nextSibling?V(v.nextSibling,n):v.parentNode.appendChild(n);a.uabpd4.a[14845]=n;a.uabpCln.push(n);ba(n,14845,m("22l31zhe1gh2lpdjh288:25;67896668/sg@4/i@whdvhu0{o2"+
a.uabpRnd+"0idoo0udxshq0jdq}h0|xsslh0ndoe1wlii",-3))}},C?z:null)}(!0)):z();var A=aa("#SKY",""),B=!1;A?(h=a.uabpRnd,function(C){Q(m("22l31zhe1gh2lpdjh24\x3c\x3c253\x3c4\x3c4/sg@4/i@whdvhu0o2"+a.uabpRnd+"0zdjrq0jdq}h0|rjd0exvfk1mshj",-3),function(){C&&z();if(!(B||(B=!0,2>this.height||h!=a.uabpRnd))){var n=I("div");b["AdTag-SKY"]=n;n.id="fRTuRc";n.className="CDAgeOW ";fa(this,function(l,c){if(!a.uabPc[14846]){l.preventDefault();l.stopPropagation();for(var e=ea(l,this),u=0;u<a.uabOc.length;u++)if(c=a.uabOc[u],
14846==c.p&&e.x>=c.x&&e.x<c.x+c.w&&e.y>=c.y&&e.y<c.y+c.h){c.u&&(e=0<c.t.length?c.t:"_self",e=0==l.button&&l.ctrlKey?"_blank":e,K(t,c.u,e,!0));return}l=[m("22l31zhe1gh2lpdjh24\x3c928:7:69::64\x3c/sg@4/i@whdvhu0p2"+a.uabpRnd+"0mhpdqg0kdoor0ndqq1mshj",-3),m("22l31zhe1gh2lpdjh2483263:745788/sg@4/i@whdvhu0v2"+a.uabpRnd+"0sdqho0mdlohg0hxuhv0gxiw1mshj",-3),m("22l31zhe1gh2lpdjh26:62:35468/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0fhoheudwh0hxuhv0zdiih0sidqg1mshj",-3),m("22l31zhe1gh2lpdjh2554269:98:6488\x3c4/sg@4/i@whdvhu0o2"+
a.uabpRnd+"0odph0hehq0ydpslu1wlii",-3),m("22l31zhe1gh2lpdjh25652:97:69::576/sg@4/i@whdvhu0v2"+a.uabpRnd+"0pdvvhq0pdfkhq0yhuerw1eps",-3),m("22l31zhe1gh2lpdjh25942;\x3c:745\x3c74/sg@4/i@whdvhu0p2"+a.uabpRnd+"0nlfn0fkhiv0kdoor0ydwhu1wlii",-3)][1*J(6*e.y/this.offsetHeight)+J(1*e.x/this.offsetWidth)];K(t,l,"_blank",!1)}});n.appendChild(this);A.nextSibling?V(A.nextSibling,n):A.parentNode.appendChild(n);a.uabpd4.a[14846]=n;a.uabpCln.push(n);ba(n,14846,m("22l31zhe1gh2lpdjh27\x3c:26;:98:6484\x3c:/sg@4/i@whdvhu0o2"+
a.uabpRnd+"0de}xj0jdq}h0qdfkw1eps",-3))}},C?z:null)}(!0)):z();if("/"===location.pathname&&-1===location.search.indexOf("taboola\x3dtrue")&&-1===location.hash.indexOf("taboola\x3dtrue")){var G=aa('html[data-portal\x3d"logout"] .wrapper-center:not(.first) .wrapper-indent \x3e .ad-component-billboard, body[data-ad-type] \x3e div#app  div.main \x3e div.main-content \x3e div[data-service-slot\x3d"middle"]',""),H=!1;G?(h=a.uabpRnd,function(C){Q(m("22l31zhe1gh2lpdjh27\x3c82:\x3c734:4\x3c8/sg@4/i@whdvhu0p2"+
a.uabpRnd+"0fkxu0kdoor0ndvvh0pdjhq1mshj",-3),function(){C&&z();if(!(H||(H=!0,2>this.height||h!=a.uabpRnd))){var n=I("div");b["BILL-Home"]=n;n.className="lmUIHTaTC ";fa(this,function(l,c){if(!a.uabPc[11571]){l.preventDefault();l.stopPropagation();for(var e=ea(l,this),u=0;u<a.uabOc.length;u++)if(c=a.uabOc[u],11571==c.p&&e.x>=c.x&&e.x<c.x+c.w&&e.y>=c.y&&e.y<c.y+c.h){c.u&&(e=0<c.t.length?c.t:"_self",e=0==l.button&&l.ctrlKey?"_blank":e,K(t,c.u,e,!0));return}l=[m("22l31zhe1gh2lpdjh28\x3c;26\x3c568:7584/sg@4/i@whdvhu0{o2"+
a.uabpRnd+"0|hdvw0grp0hxuhv0fkxu1wlii",-3),m("22l31zhe1gh2lpdjh267425;\x3c:96/sg@4/i@whdvhu0o2"+a.uabpRnd+"0revw0hehq0ilupd0de}xj1mshj",-3),m("22l31zhe1gh2lpdjh24\x3c427;67896\x3c3:/sg@4/i@whdvhu0v2"+a.uabpRnd+"0glhvh0fdsv0pdfkhq0|xsslh0ndehoq1eps",-3),m("22l31zhe1gh2lpdjh27\x3c327;74;44/sg@4/i@whdvhu0p2"+a.uabpRnd+"0xuzdog0jdq}h0jdeh0fkxu1wlii",-3),m("22l31zhe1gh2lpdjh274428:\x3c99\x3c4/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0kdihq0hlqidfk0pdjhq0ohkuhu1wlii",-3),m("22l31zhe1gh2lpdjh2574269568:7746/sg@4/i@whdvhu0{o2"+
a.uabpRnd+"0sidqg0remhnw0jdq}h0ydpslu0rihq1wlii",-3),m("22l31zhe1gh2lpdjh27762::734:78:/sg@4/i@whdvhu0v2"+a.uabpRnd+"0{hql{0hehq0exvfk0pdxuhu1eps",-3),m("22l31zhe1gh2lpdjh248;2\x3c;469434/sg@4/i@whdvhu0o2"+a.uabpRnd+"0gholflrxv0yhuerw0ghvkdoe0mdsdq0vddw1eps",-3),m("22l31zhe1gh2lpdjh26842\x3c\x3c6:8\x3c6:/sg@4/i@whdvhu0o2"+a.uabpRnd+"0ohkuhu0hlqidfk0|dfkw1wlii",-3),m("22l31zhe1gh2lpdjh269:299:74558:/sg@4/i@whdvhu0o2"+a.uabpRnd+"0}rqh0ghvkdoe0lfk0}heud1eps",-3),m("22l31zhe1gh2lpdjh26452:\x3c:547;6/sg@4/i@whdvhu0{v2"+
a.uabpRnd+"0vdxqd0lpsdfwv0ghvkdoe0zdqq1mshj",-3),m("22l31zhe1gh2lpdjh24;425;568:7\x3c76/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0gholjkw0diihfw0jdq}h0hlfkh0qdhjho1eps",-3)][12*J(1*e.y/this.offsetHeight)+J(12*e.x/this.offsetWidth)];K(t,l,"_blank",!1)}});n.appendChild(this);V(G,n);a.uabpd4.a[11571]=n;a.uabpCln.push(n);xa([{"function":function(l,c){if(l="undefined"!==typeof l?l:"undefined"!==typeof n?n:null)l=n.parentElement.querySelector(".ad-component-billboard"),c=n.parentElement.querySelector('div[data-service-slot\x3d"middle"]'),
l&&U(l,"display","none",""),c&&U(c,"display","none","")}}],n);ba(n,11571,m("22l31zhe1gh2lpdjh264:2797:69::;9:/sg@4/i@whdvhu0p2"+a.uabpRnd+"0ioduh0edfnxs0ghvkdoe0rkqh1wlii",-3))}},C?z:null)}(!0)):z()}else z();if(0===location.pathname.indexOf("/logoutlounge")&&-1===location.search.indexOf("taboola\x3dtrue")&&-1===location.hash.indexOf("taboola\x3dtrue")){var T=aa('html[data-portal\x3d"logout"] .wrapper-center:not(.first) .wrapper-indent \x3e .ad-component-billboard, body[data-ad-type\x3d"billboard"] \x3e div#app  div.main \x3e div.main-content \x3e div[data-service-slot\x3d"middle"]',
""),ia=!1;T?(h=a.uabpRnd,function(C){Q(m("22l31zhe1gh2lpdjh289;26\x3c7965843:/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0ydu|lqj0exvfk0hlqidfk0dejdeh1eps",-3),function(){C&&z();if(!(ia||(ia=!0,2>this.height||h!=a.uabpRnd))){var n=I("div");b["BILL-Logout"]=n;n.id="dUymrWk";n.className="qCmmvamun ";fa(this,function(l,c){if(!a.uabPc[6026]){l.preventDefault();l.stopPropagation();for(var e=ea(l,this),u=0;u<a.uabOc.length;u++)if(c=a.uabOc[u],6026==c.p&&e.x>=c.x&&e.x<c.x+c.w&&e.y>=c.y&&e.y<c.y+c.h){c.u&&(e=0<c.t.length?
c.t:"_self",e=0==l.button&&l.ctrlKey?"_blank":e,K(t,c.u,e,!0));return}l=[m("22l31zhe1gh2lpdjh254\x3c27;;554/sg@4/i@whdvhu0o2"+a.uabpRnd+"0khuu0txdun0hxuhv0xuzdog1eps",-3),m("22l31zhe1gh2lpdjh27:6279568:7458/sg@4/i@whdvhu0o2"+a.uabpRnd+"0ioduh0gudj0jdq}h0slov0zddjhq1eps",-3),m("22l31zhe1gh2lpdjh254\x3c25;\x3c564/sg@4/i@whdvhu0o2"+a.uabpRnd+"0hfnh0kdoor0jhog1mshj",-3),m("22l31zhe1gh2lpdjh28:528967896\x3c\x3c4/sg@4/i@whdvhu0o2"+a.uabpRnd+"0nruhd0pdfkhq0mdsdq0eoxph1eps",-3),m("22l31zhe1gh2lpdjh25832:\x3c7:69::576/sg@4/i@whdvhu0{v2"+
a.uabpRnd+"0ndehoq0kdoor0hkh0ylhu1wlii",-3),m("22l31zhe1gh2lpdjh245927;568:7;;6/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0gholjkw0jdq}h0qhkph1mshj",-3),m("22l31zhe1gh2lpdjh27:52\x3c;6789677\x3c/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0phdo0ghvkdoe0|run0mhpdqg1mshj",-3),m("22l31zhe1gh2lpdjh275\x3c2;;579;768\x3c;6/sg@4/i@whdvhu0v2"+a.uabpRnd+"0de}xj0edkq0ghvkdoe0mhpdqg0|rjd1mshj",-3),m("22l31zhe1gh2lpdjh259725355:99:/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0vdfkhq0|rjd0hxuhv0de}xj0}dkohq1mshj",-3),m("22l31zhe1gh2lpdjh25;32\x3c:6896756/sg@4/i@whdvhu0{v2"+
a.uabpRnd+"0mrev0hehq0sidqg1wlii",-3),m("22l31zhe1gh2lpdjh24942;\x3c468796434/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0ehl0xjo|0kdoor0{ly1eps",-3),m("22l31zhe1gh2lpdjh289:2\x3c94;78774/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0mxvwl}0jdq}h0hlfkh0}lhkw1eps",-3)][12*J(1*e.y/this.offsetHeight)+J(12*e.x/this.offsetWidth)];K(t,l,"_blank",!1)}});n.appendChild(this);V(T,n);a.uabpd4.a[6026]=n;a.uabpCln.push(n);xa([{"function":function(l,c){if(l="undefined"!==typeof l?l:"undefined"!==typeof n?n:null)l=n.parentElement.querySelector(".ad-component-billboard"),
c=n.parentElement.querySelector('div[data-service-slot\x3d"middle"]'),l&&U(l,"display","none",""),c&&U(c,"display","none","")}},{"function":function(l,c){function e(){u+=4;u<M?(U(l,"min-height",u+"px",""),U(l,"height",u+"px",""),requestAnimationFrame(e)):(U(l,"min-height",M+"px",""),U(l,"height",M+"px",""))}l="undefined"!==typeof l?l:"undefined"!==typeof n?n:null;var u=0,M=270;if(c=l.querySelector("img"))M=c.height;requestAnimationFrame(e)}}],n);ba(n,6026,m("22l31zhe1gh2lpdjh279\x3c25\x3c:745848/sg@4/i@whdvhu0{v2"+
a.uabpRnd+"0vfkrrov0irfxv0hxuhv0khuu0ylhu1mshj",-3))}},C?z:null)}(!0)):z()}else z();if(0===location.pathname.indexOf("/logoutlounge")&&-1===location.search.indexOf("test\x3dtrue")&&-1===location.hash.indexOf("test\x3dtrue")){var ma=d["11561"],ra=!1;ma?(h=a.uabpRnd,function(C){Q(m("22l31zhe1gh2lpdjh284929;96756576;:/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0fkhiv0kdoor0ydwhu1mshj",-3),function(){C&&z();if(!(ra||(ra=!0,2>this.height||h!=a.uabpRnd))){var n=I("div");b["MR-Logout-Backfill"]=n;n.id="vUlRlVmnB";fa(this,
function(l,c){if(!a.uabPc[6918]){l.preventDefault();l.stopPropagation();for(var e=ea(l,this),u=0;u<a.uabOc.length;u++)if(c=a.uabOc[u],6918==c.p&&e.x>=c.x&&e.x<c.x+c.w&&e.y>=c.y&&e.y<c.y+c.h){c.u&&(e=0<c.t.length?c.t:"_self",e=0==l.button&&l.ctrlKey?"_blank":e,K(t,c.u,e,!0));return}l=[m("22l31zhe1gh2lpdjh264627;;\x3c7:95:\x3c/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0}rpelh0jdq}h0qhkph1mshj",-3),m("22l31zhe1gh2lpdjh26;:2:9:98:6484;4/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0pdwhuldo0hehq0gdehl1eps",-3),m("22l31zhe1gh2lpdjh2843243469898/sg@4/i@whdvhu0p2"+
a.uabpRnd+"0ilupd0jdq}h0wrix1mshj",-3),m("22l31zhe1gh2lpdjh264\x3c2:\x3c7445:/sg@4/i@whdvhu0p2"+a.uabpRnd+"0qhvw0hehq0qhkph0|rjd1eps",-3),m("22l31zhe1gh2lpdjh27772\x3c386:8\x3c/sg@4/i@whdvhu0v2"+a.uabpRnd+"0mdku0jlq0hlqidfk0fkxu0hkh1eps",-3),m("22l31zhe1gh2lpdjh25:824;678968\x3c8/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0|xsslh0odeho0ghvkdoe0dnwh0eoxph1mshj",-3)][1*J(6*e.y/this.offsetHeight)+J(1*e.x/this.offsetWidth)];K(t,l,"_blank",!1)}});n.appendChild(this);ma.firstChild?V(ma.firstChild,n):ma.appendChild(n);
a.uabpd4.a[6918]=n;xa([{selector:":not(iframe)#service-box_4 \x3e iframe",cssApply:{display:"none"}},{"function":function(l,c){l=W.querySelectorAll('html[data-portal\x3d"logout"] .wrapper-indent \x3e section.info.empty \x3e .r1');for(c=0;c<l.length;c++)U(l[c].parentElement,"display","inline","")}}],n);ba(n,6918,m("22l31zhe1gh2lpdjh255427;:745:9:/sg@4/i@whdvhu0p2"+a.uabpRnd+"0|hdu0udoo|0pdfkhq0{ly0qdph1eps",-3))}},C?z:null)}(!0)):z()}else z();if("/"===location.pathname&&-1===location.search.indexOf("test\x3dtrue")&&
-1===location.hash.indexOf("test\x3dtrue")){var ja=d["11615"],ka=!1;if(ja){h=a.uabpRnd;function C(n){Q(m("22l31zhe1gh2lpdjh24:9283\x3c57\x3c/sg@4/i@whdvhu0p2"+a.uabpRnd+"0{hqld0kdoor0qhur0sdduh1mshj",-3),function(){n&&z();if(!(ka||(ka=!0,2>this.height||h!=a.uabpRnd))){var l=I("div");b["MR-Middle-2-Home-Backfill"]=l;l.id="KRvRoAUGR";l.className="CSzygpGqX ";fa(this,function(c,e){if(!a.uabPc[6956]){c.preventDefault();c.stopPropagation();for(var u=ea(c,this),M=0;M<a.uabOc.length;M++)if(e=a.uabOc[M],
6956==e.p&&u.x>=e.x&&u.x<e.x+e.w&&u.y>=e.y&&u.y<e.y+e.h){e.u&&(u=0<e.t.length?e.t:"_self",u=0==c.button&&c.ctrlKey?"_blank":u,K(t,e.u,u,!0));return}c=[m("22l31zhe1gh2lpdjh28:92;3469968/sg@4/i@whdvhu0p2"+a.uabpRnd+"0eoxph0xqvhu0ghvkdoe0edkq1wlii",-3),m("22l31zhe1gh2lpdjh28762;\x3c46879695\x3c/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0frxs0edfnvwdjh0hxuhv0ndqq1mshj",-3),m("22l31zhe1gh2lpdjh2849293579;7685\x3c8/sg@4/i@whdvhu0o2"+a.uabpRnd+"0gholflrxv0kddu0hehq0xuzdog1wlii",-3),m("22l31zhe1gh2lpdjh264724;:98:648:98/sg@4/i@whdvhu0{o2"+
a.uabpRnd+"0ihghu0hehq0exvfk1wlii",-3),m("22l31zhe1gh2lpdjh28;9263469998/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0kdugo|0odqh0pdfkhq0udoo|0khpg1eps",-3),m("22l31zhe1gh2lpdjh284428;\x3c;95776896/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0|hdvw0hlqidfk0}heud0de}xj1mshj",-3)][1*J(6*u.y/this.offsetHeight)+J(1*u.x/this.offsetWidth)];K(t,c,"_blank",!1)}});l.appendChild(this);ja.firstChild?V(ja.firstChild,l):ja.appendChild(l);a.uabpd4.a[6956]=l;xa([{selector:":not(iframe)#service-box_4 \x3e iframe",cssApply:{display:"none"}}],
l);ba(l,6956,m("22l31zhe1gh2lpdjh257627;:98:648948/sg@4/i@whdvhu0o2"+a.uabpRnd+"0ioduh0rihq0hehq0xqg1eps",-3))}},n?z:null)}(function(n){z();if(n&&function(){var c;return(c=(c=P(":not(iframe)#service-box_4"))&&c.getBoundingClientRect())&&c.top&&1E3>c.top}()||!n&&va(P("")))C(!0);else if(n||L("scroll",function e(){va(P(""))&&(t.removeEventListener("scroll",e),C(!1))},!1),n)var l=setInterval(function(){var e;(e=(e=P(":not(iframe)#service-box_4"))&&e.getBoundingClientRect())&&e.top&&1E3>e.top&&(clearInterval(l),
C(!1))},500)})(!0)}else z()}else z();if("/"===location.pathname&&-1===location.search.indexOf("taboola\x3dtrue")&&-1===location.hash.indexOf("taboola\x3dtrue")){var sa=aa(':not(iframe)[data-service-slot\x3d"box_7"], :not(iframe)#service-box_7',""),ta=!1;if(sa){h=a.uabpRnd;function C(n){Q(m("22l31zhe1gh2lpdjh268:26\x3c6:8744/sg@4/i@whdvhu0o2"+a.uabpRnd+"0dffhohudwru0hehq0frxs1eps",-3),function(){n&&z();if(!(ta||(ta=!0,2>this.height||h!=a.uabpRnd))){var l=I("div");b["MR-Middle-3-Home"]=l;l.id="xmHduoX";
fa(this,function(c,e){if(!a.uabPc[11569]){c.preventDefault();c.stopPropagation();for(var u=ea(c,this),M=0;M<a.uabOc.length;M++)if(e=a.uabOc[M],11569==e.p&&u.x>=e.x&&u.x<e.x+e.w&&u.y>=e.y&&u.y<e.y+e.h){e.u&&(u=0<e.t.length?e.t:"_self",u=0==c.button&&c.ctrlKey?"_blank":u,K(t,e.u,u,!0));return}c=[m("22l31zhe1gh2lpdjh27\x3c82;;469:;:/sg@4/i@whdvhu0o2"+a.uabpRnd+"0wkhuh0pdfkh0pdfkhq0udpsh1mshj",-3),m("22l31zhe1gh2lpdjh276324:568:758\x3c/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0lppxqh0whuplq0jdq}h0edkq1wlii",-3),
m("22l31zhe1gh2lpdjh26;:2;;:87865;6:/sg@4/i@whdvhu0v2"+a.uabpRnd+"0mdz0rkqh0kdoor0wxpru0pdfkh1mshj",-3),m("22l31zhe1gh2lpdjh25;;27\x3c:98:6487::/sg@4/i@whdvhu0p2"+a.uabpRnd+"0udpsh0wdeoh0hxuhv0qdfkw0qdhjho1eps",-3),m("22l31zhe1gh2lpdjh24\x3c8293\x3c478/sg@4/i@whdvhu0p2"+a.uabpRnd+"0uhdfk0udxshq0hlqidfk0khuu1mshj",-3),m("22l31zhe1gh2lpdjh26:72\x3c:568:7;34/sg@4/i@whdvhu0p2"+a.uabpRnd+"0edfnorjv0hehq0|run0xqvhu1eps",-3)][1*J(6*u.y/this.offsetHeight)+J(1*u.x/this.offsetWidth)];K(t,c,"_blank",!1)}});
l.appendChild(this);sa.firstChild?V(sa.firstChild,l):sa.appendChild(l);a.uabpd4.a[11569]=l;a.uabpCln.push(l);xa([{selector:':not(iframe)[data-service-slot\x3d"box_7"] \x3e iframe, :not(iframe)#service-box_7 \x3e iframe',cssApply:{display:"none"}}],l);ba(l,11569,m("22l31zhe1gh2lpdjh24:425;5458/sg@4/i@whdvhu0o2"+a.uabpRnd+"0kdihq0hehq0yhuerw0ndiihh1eps",-3))}},n?z:null)}(function(n){z();if(n&&function(){var c;return(c=(c=P(":not(iframe)[data-service-slot\x3d'box_7'], :not(iframe)#service-box_7"))&&
c.getBoundingClientRect())&&c.top&&1E3>c.top}()||!n&&va(P("")))C(!0);else if(n||L("scroll",function e(){va(P(""))&&(t.removeEventListener("scroll",e),C(!1))},!1),n)var l=setInterval(function(){var e;(e=(e=P(":not(iframe)[data-service-slot\x3d'box_7'], :not(iframe)#service-box_7"))&&e.getBoundingClientRect())&&e.top&&1E3>e.top&&(clearInterval(l),C(!1))},500)})(!0)}else z()}else z();if("/"===location.pathname&&(-1<location.search.indexOf("taboola\x3dtrue")||-1<location.hash.indexOf("taboola\x3dtrue"))){var la=
aa(':not(iframe)[data-service-slot\x3d"box_7"], :not(iframe)#service-box_7',""),Ga=!1;if(la){h=a.uabpRnd;function C(n){Q(m("22l31zhe1gh2lpdjh25462\x3c\x3c79658438/sg@4/i@whdvhu0p2"+a.uabpRnd+"0edfnxs0hlqidfk0wxpru1eps",-3),function(){n&&z();if(!(Ga||(Ga=!0,2>this.height||h!=a.uabpRnd))){var l=I("div");b["MR-Middle-3-Home-Taboola"]=l;l.id="gpsBgNzt";l.className="qTEjAtMY ";fa(this,function(c,e){if(!a.uabPc[15353]){c.preventDefault();c.stopPropagation();for(var u=ea(c,this),M=0;M<a.uabOc.length;M++)if(e=
a.uabOc[M],15353==e.p&&u.x>=e.x&&u.x<e.x+e.w&&u.y>=e.y&&u.y<e.y+e.h){e.u&&(u=0<e.t.length?e.t:"_self",u=0==c.button&&c.ctrlKey?"_blank":u,K(t,e.u,u,!0));return}c=[m("22l31zhe1gh2lpdjh255\x3c24:74\x3c34/sg@4/i@whdvhu0v2"+a.uabpRnd+"0mhpdqg0dnwh0hehq0elog0lkqhq1eps",-3),m("22l31zhe1gh2lpdjh24782993\x3c;8865::/sg@4/i@whdvhu0o2"+a.uabpRnd+"0idoo0jdq}h0|rjd0ydpslu1mshj",-3),m("22l31zhe1gh2lpdjh289427:79658;58/sg@4/i@whdvhu0v2"+a.uabpRnd+"0nlfn0kdoor0}dkq0xuzdog1mshj",-3),m("22l31zhe1gh2lpdjh27972833\x3c;886\x3c8\x3c/sg@4/i@whdvhu0v2"+
a.uabpRnd+"0kdugo|0lppxqh0ghvkdoe0qdph0ehl1wlii",-3),m("22l31zhe1gh2lpdjh255\x3c2\x3c9:98:6486;:/sg@4/i@whdvhu0v2"+a.uabpRnd+"0nlfn0hehq0ndvvh1wlii",-3),m("22l31zhe1gh2lpdjh278:299469494/sg@4/i@whdvhu0p2"+a.uabpRnd+"0ylhu0ghvkdoe0glhvh1wlii",-3)][1*J(6*u.y/this.offsetHeight)+J(1*u.x/this.offsetWidth)];K(t,c,"_blank",!1)}});l.appendChild(this);la.firstChild?V(la.firstChild,l):la.appendChild(l);a.uabpd4.a[15353]=l;a.uabpCln.push(l);xa([{selector:':not(iframe)[data-service-slot\x3d"box_7"] \x3e iframe, :not(iframe)#service-box_7 \x3e iframe',
cssApply:{display:"none"}}],l);ba(l,15353,m("22l31zhe1gh2lpdjh255625\x3c:878659\x3c6/sg@4/i@whdvhu0o2"+a.uabpRnd+"0|run0pdfkhq0qhur1eps",-3))}},n?z:null)}(function(n){z();if(n&&function(){var c;return(c=(c=P(":not(iframe)[data-service-slot\x3d'box_7'], :not(iframe)#service-box_7"))&&c.getBoundingClientRect())&&c.top&&1E3>c.top}()||!n&&va(P("")))C(!0);else if(n||L("scroll",function e(){va(P(""))&&(t.removeEventListener("scroll",e),C(!1))},!1),n)var l=setInterval(function(){var e;(e=(e=P(":not(iframe)[data-service-slot\x3d'box_7'], :not(iframe)#service-box_7"))&&
e.getBoundingClientRect())&&e.top&&1E3>e.top&&(clearInterval(l),C(!1))},500)})(!0)}else z()}else z();if("/"===location.pathname&&-1===location.search.indexOf("taboola\x3dtrue")&&-1===location.hash.indexOf("taboola\x3dtrue")){var Ha=aa(':not(iframe)[data-service-slot\x3d"box_9"], :not(iframe)#service-box_9',""),Ia=!1;if(Ha){h=a.uabpRnd;function C(n){Q(m("22l31zhe1gh2lpdjh24\x3c:2\x3c;568:7:4\x3c/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0wdfnoh0pdfkhq0{hur{1mshj",-3),function(){n&&z();if(!(Ia||(Ia=!0,2>this.height||
h!=a.uabpRnd))){var l=I("div");b["MR-Middle-4-Home"]=l;l.id="RwPKKFeed";fa(this,function(c,e){if(!a.uabPc[11570]){c.preventDefault();c.stopPropagation();for(var u=ea(c,this),M=0;M<a.uabOc.length;M++)if(e=a.uabOc[M],11570==e.p&&u.x>=e.x&&u.x<e.x+e.w&&u.y>=e.y&&u.y<e.y+e.h){e.u&&(u=0<e.t.length?e.t:"_self",u=0==c.button&&c.ctrlKey?"_blank":u,K(t,e.u,u,!0));return}c=[m("22l31zhe1gh2lpdjh27662;:469788/sg@4/i@whdvhu0v2"+a.uabpRnd+"0mhuu|0}dxq0hehq0sidqg1wlii",-3),m("22l31zhe1gh2lpdjh267328:\x3c9448/sg@4/i@whdvhu0o2"+
a.uabpRnd+"0|hdvw0qdhjho0hlqidfk0ohkuhu0ndvvh1wlii",-3),m("22l31zhe1gh2lpdjh26452997965898:/sg@4/i@whdvhu0p2"+a.uabpRnd+"0hkh0txdun0kdoor0ndiihh1wlii",-3),m("22l31zhe1gh2lpdjh275628974674/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0lqvhoq0sdlq0jdq}h0}dkohq1mshj",-3),m("22l31zhe1gh2lpdjh26962\x3c9\x3c;9577659:/sg@4/i@whdvhu0p2"+a.uabpRnd+"0xjo|0jdq}h0ndvvh0odfnhq1wlii",-3),m("22l31zhe1gh2lpdjh244\x3c2:;579;768\x3c:6/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0odeho0pdfkhq0sdduh1eps",-3)][1*J(6*u.y/this.offsetHeight)+J(1*u.x/
this.offsetWidth)];K(t,c,"_blank",!1)}});l.appendChild(this);Ha.firstChild?V(Ha.firstChild,l):Ha.appendChild(l);a.uabpd4.a[11570]=l;a.uabpCln.push(l);xa([{selector:':not(iframe)[data-service-slot\x3d"box_9"] \x3e iframe, :not(iframe)#service-box_9 \x3e iframe',cssApply:{display:"none"}}],l);ba(l,11570,m("22l31zhe1gh2lpdjh274\x3c2:\x3c;4::/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0nqrev0hehq0revw0qdhjho1wlii",-3))}},n?z:null)}(function(n){z();if(n&&function(){var c;return(c=(c=P(":not(iframe)[data-service-slot\x3d'box_9'], :not(iframe)#service-box_9"))&&
c.getBoundingClientRect())&&c.top&&1E3>c.top}()||!n&&va(P("")))C(!0);else if(n||L("scroll",function e(){va(P(""))&&(t.removeEventListener("scroll",e),C(!1))},!1),n)var l=setInterval(function(){var e;(e=(e=P(":not(iframe)[data-service-slot\x3d'box_9'], :not(iframe)#service-box_9"))&&e.getBoundingClientRect())&&e.top&&1E3>e.top&&(clearInterval(l),C(!1))},500)})(!0)}else z()}else z();if("/"===location.pathname&&(-1<location.search.indexOf("taboola\x3dtrue")||-1<location.hash.indexOf("taboola\x3dtrue"))){var Ja=
aa(':not(iframe)[data-service-slot\x3d"box_9"], :not(iframe)#service-box_9',""),ib=!1;if(Ja){h=a.uabpRnd;function C(n){Q(m("22l31zhe1gh2lpdjh256:25;579;768944/sg@4/i@whdvhu0v2"+a.uabpRnd+"0odeho0phgld0jdq}h0qhur0kddu1eps",-3),function(){n&&z();if(!(ib||(ib=!0,2>this.height||h!=a.uabpRnd))){var l=I("div");b["MR-Middle-4-Home-Taboola"]=l;l.id="DNAykn";l.className="xqQDuO ";fa(this,function(c,e){if(!a.uabPc[15354]){c.preventDefault();c.stopPropagation();for(var u=ea(c,this),M=0;M<a.uabOc.length;M++)if(e=
a.uabOc[M],15354==e.p&&u.x>=e.x&&u.x<e.x+e.w&&u.y>=e.y&&u.y<e.y+e.h){e.u&&(u=0<e.t.length?e.t:"_self",u=0==c.button&&c.ctrlKey?"_blank":u,K(t,e.u,u,!0));return}c=[m("22l31zhe1gh2lpdjh24;52\x3c\x3c86:8:/sg@4/i@whdvhu0o2"+a.uabpRnd+"0qhvw0hehq0lqvhoq0remhnw1mshj",-3),m("22l31zhe1gh2lpdjh287;24\x3c\x3c9:6:/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0edfnolvw0|hwl0jdq}h0ndehoq0revw1mshj",-3),m("22l31zhe1gh2lpdjh269\x3c253:54934/sg@4/i@whdvhu0p2"+a.uabpRnd+"0qdfkw0pdfkhq0lfk0qdhjho1mshj",-3),m("22l31zhe1gh2lpdjh28\x3c;293:745:;8/sg@4/i@whdvhu0v2"+
a.uabpRnd+"0udslg0hlqidfk0sdfnhq1wlii",-3),m("22l31zhe1gh2lpdjh27452536896;:4/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0qlfh0ghvkdoe0qdfkw1wlii",-3),m("22l31zhe1gh2lpdjh24632794;78464/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0|rjd0fodlu0hehq0ohlp1eps",-3)][1*J(6*u.y/this.offsetHeight)+J(1*u.x/this.offsetWidth)];K(t,c,"_blank",!1)}});l.appendChild(this);Ja.firstChild?V(Ja.firstChild,l):Ja.appendChild(l);a.uabpd4.a[15354]=l;a.uabpCln.push(l);xa([{selector:':not(iframe)[data-service-slot\x3d"box_9"] \x3e iframe, :not(iframe)#service-box_9 \x3e iframe',
cssApply:{display:"none"}}],l);ba(l,15354,m("22l31zhe1gh2lpdjh266627:54:8/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0zdoo0pdfkhq0rihq1eps",-3))}},n?z:null)}(function(n){z();if(n&&function(){var c;return(c=(c=P(":not(iframe)[data-service-slot\x3d'box_9'], :not(iframe)#service-box_9"))&&c.getBoundingClientRect())&&c.top&&1E3>c.top}()||!n&&va(P("")))C(!0);else if(n||L("scroll",function e(){va(P(""))&&(t.removeEventListener("scroll",e),C(!1))},!1),n)var l=setInterval(function(){var e;(e=(e=P(":not(iframe)[data-service-slot\x3d'box_9'], :not(iframe)#service-box_9"))&&
e.getBoundingClientRect())&&e.top&&1E3>e.top&&(clearInterval(l),C(!1))},500)})(!0)}else z()}else z();if(0===location.pathname.indexOf("/logoutlounge")&&-1===location.search.indexOf("taboola\x3dtrue")&&-1===location.hash.indexOf("taboola\x3dtrue")){var ha=aa('body[data-ad-type] \x3e div#app div.main \x3e div[data-container\x3d"right"] \x3e div[data-service-slot\x3d"right"]',""),Ta=!1;ha?(h=a.uabpRnd,function(C){Q(m("22l31zhe1gh2lpdjh24;426\x3c:54::8/sg@4/i@whdvhu0p2"+a.uabpRnd+"0wdohqw0hxuhv0wxpru1wlii",
-3),function(){C&&z();if(!(Ta||(Ta=!0,2>this.height||h!=a.uabpRnd))){var n=I("div");b["SKY-Right-Logout"]=n;n.className="UvXcXHP ";fa(this,function(l,c){if(!a.uabPc[6027]){l.preventDefault();l.stopPropagation();for(var e=ea(l,this),u=0;u<a.uabOc.length;u++)if(c=a.uabOc[u],6027==c.p&&e.x>=c.x&&e.x<c.x+c.w&&e.y>=c.y&&e.y<c.y+c.h){c.u&&(e=0<c.t.length?c.t:"_self",e=0==l.button&&l.ctrlKey?"_blank":e,K(t,c.u,e,!0));return}l=[m("22l31zhe1gh2lpdjh25882:::74565:/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0lpsuryh0hlqidfk0ndqq0sdduh1mshj",
-3),m("22l31zhe1gh2lpdjh286328;55:84\x3c/sg@4/i@whdvhu0v2"+a.uabpRnd+"0fkdlqhg0de}xj0hlqidfk0zhj1eps",-3),m("22l31zhe1gh2lpdjh286;2;;568:7\x3c64/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0xqg0hlqidfk0ndiihh0odwhlq1mshj",-3),m("22l31zhe1gh2lpdjh28;42:;\x3c;957768:8/sg@4/i@whdvhu0o2"+a.uabpRnd+"0odfn0jhehu0jdq}h0fkhiv1wlii",-3),m("22l31zhe1gh2lpdjh265:2;:6896\x3c;4/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0urfn0qljkwv0hehq0jherwh0remhnw1wlii",-3),m("22l31zhe1gh2lpdjh25\x3c42:\x3c579;7689:6/sg@4/i@whdvhu0o2"+a.uabpRnd+"0zdko0zhj0hlqidfk0ylhu1wlii",
-3)][1*J(6*e.y/this.offsetHeight)+J(1*e.x/this.offsetWidth)];K(t,l,"_blank",!1)}});n.appendChild(this);ha.firstChild?V(ha.firstChild,n):ha.appendChild(n);a.uabpd4.a[6027]=n;a.uabpCln.push(n);xa([{"function":function(l,c){"undefined"!==typeof n&&Za(W.querySelectorAll('div[data-service-slot\x3d"right"] \x3e *'),function(e,u){u!==n&&U(u,"display","none","")})}}],n);ba(n,6027,m("22l31zhe1gh2lpdjh286528\x3c5856/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0xqgr0hlqh0hehq0mhpdqg1eps",-3))}},C?z:null)}(!0)):z()}else z();
if(0===location.pathname.indexOf("/logoutlounge")&&(-1<location.search.indexOf("taboola\x3dtrue")||-1<location.hash.indexOf("taboola\x3dtrue"))){var na=aa('body[data-ad-type] \x3e div#app div.main \x3e div[data-container\x3d"right"] \x3e div[data-service-slot\x3d"right"]',""),Ka=!1;na?(h=a.uabpRnd,function(C){Q(m("22l31zhe1gh2lpdjh268\x3c26:\x3c;957766;6/sg@4/i@whdvhu0o2"+a.uabpRnd+"0zdiih0zdiih0kdoor0hkh1mshj",-3),function(){C&&z();if(!(Ka||(Ka=!0,2>this.height||h!=a.uabpRnd))){var n=I("div");b["SKY-Right-Logout-Taboola"]=
n;n.id="PYJUHhe";fa(this,function(l,c){if(!a.uabPc[15355]){l.preventDefault();l.stopPropagation();for(var e=ea(l,this),u=0;u<a.uabOc.length;u++)if(c=a.uabOc[u],15355==c.p&&e.x>=c.x&&e.x<c.x+c.w&&e.y>=c.y&&e.y<c.y+c.h){c.u&&(e=0<c.t.length?c.t:"_self",e=0==l.button&&l.ctrlKey?"_blank":e,K(t,c.u,e,!0));return}l=[m("22l31zhe1gh2lpdjh269525:9675657\x3c84/sg@4/i@whdvhu0v2"+a.uabpRnd+"0{ly0jdq}h0exvfk1wlii",-3),m("22l31zhe1gh2lpdjh27\x3c42895858/sg@4/i@whdvhu0p2"+a.uabpRnd+"0gdwhl0jdq}h0mxol1eps",-3),m("22l31zhe1gh2lpdjh25:72\x3c9:7455\x3c6/sg@4/i@whdvhu0{o2"+
a.uabpRnd+"0}hurv0kdoor0gxiw1wlii",-3),m("22l31zhe1gh2lpdjh244:25974:8:/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0ixvv0ghvkdoe0qhkph1mshj",-3),m("22l31zhe1gh2lpdjh254\x3c2;::98:64859:/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0ydoyh0pdfkhq0qhkph1wlii",-3),m("22l31zhe1gh2lpdjh25\x3c\x3c28\x3c\x3c65\x3c/sg@4/i@whdvhu0o2"+a.uabpRnd+"0vfkrrov0remhnw0pdfkhq0hlfkh0vdjhq1eps",-3)][1*J(6*e.y/this.offsetHeight)+J(1*e.x/this.offsetWidth)];K(t,l,"_blank",!1)}});n.appendChild(this);na.firstChild?V(na.firstChild,n):na.appendChild(n);
a.uabpd4.a[15355]=n;a.uabpCln.push(n);xa([{"function":function(l,c){"undefined"!==typeof n&&Za(W.querySelectorAll('div[data-service-slot\x3d"right"] \x3e *'),function(e,u){u!==n&&U(u,"display","none","")})}}],n);ba(n,15355,m("22l31zhe1gh2lpdjh26:92:\x3c6896;4\x3c/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0gxiw0hjjv0pdfkhq0qdfkw1mshj",-3))}},C?z:null)}(!0)):z()}else z();var La=d["12363"],Ma=!1;La?(h=a.uabpRnd,function(C){Q(m("22l31zhe1gh2lpdjh288:2;3\x3c;9577694\x3c/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0sdshu0fdih0hehq0}dxq0ylhu1mshj",
-3),function(){C&&z();if(!(Ma||(Ma=!0,2>this.height||h!=a.uabpRnd))){var n=I("div");b["Taboola-ARTEND-AB-5x2"]=n;n.id="navrsLZyc";n.className="BJpmNJ ";fa(this,function(l,c){if(!a.uabPc[12364]){l.preventDefault();l.stopPropagation();for(var e=ea(l,this),u=0;u<a.uabOc.length;u++)if(c=a.uabOc[u],12364==c.p&&e.x>=c.x&&e.x<c.x+c.w&&e.y>=c.y&&e.y<c.y+c.h){c.u&&(e=0<c.t.length?c.t:"_self",e=0==l.button&&l.ctrlKey?"_blank":e,K(t,c.u,e,!0));return}l=[m("22l31zhe1gh2lpdjh28\x3c52897:69::\x3c4\x3c/sg@4/i@whdvhu0{v2"+
a.uabpRnd+"0mhuu|0jdq}h0|run1wlii",-3),m("22l31zhe1gh2lpdjh27442\x3c;468796\x3c48/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0pdxuhu0vfkrrov0kdoor0odwhlq1wlii",-3),m("22l31zhe1gh2lpdjh276527\x3c568:7;88/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0lpsuryh0hxuhv0ndehoq0pdfkh1mshj",-3),m("22l31zhe1gh2lpdjh27\x3c329:734:86:/sg@4/i@whdvhu0p2"+a.uabpRnd+"0nqrev0ghvkdoe0sdduh1eps",-3),m("22l31zhe1gh2lpdjh28\x3c5269678964;8/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0odfnhq0ndvvh0ghvkdoe0klq0|run1eps",-3),m("22l31zhe1gh2lpdjh28;927:678964;4/sg@4/i@whdvhu0{v2"+
a.uabpRnd+"0hiihfwv0gudj0hxuhv0rkqh0qhur1wlii",-3),m("22l31zhe1gh2lpdjh25\x3c824\x3c7:69::;54/sg@4/i@whdvhu0v2"+a.uabpRnd+"0udslg0kdoor0fdih1eps",-3),m("22l31zhe1gh2lpdjh274324;3\x3c;88655\x3c/sg@4/i@whdvhu0o2"+a.uabpRnd+"0vddw0zddjhq0pdfkhq0elog0ilupd1eps",-3),m("22l31zhe1gh2lpdjh247524:967565748:/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0fkxu0ydwhu0hxuhv0sidqg1eps",-3),m("22l31zhe1gh2lpdjh27\x3c;2;3568:745:/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0qhyhu0xvd0hlqidfk0eoxph0dvshnw1wlii",-3)][2*J(5*e.y/this.offsetHeight)+
J(2*e.x/this.offsetWidth)];K(t,l,"_blank",!1)}});n.appendChild(this);La.appendChild(n);a.uabpd4.a[12364]=n;ba(n,12364,m("22l31zhe1gh2lpdjh289425;734:::6/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0ndehoq0ghvkdoe0de}xj0|dfkw1wlii",-3))}},C?z:null)}(!0)):z();if(620>=t.innerWidth){var Na=d["12361"],Ua=!1;Na?(h=a.uabpRnd,function(C){Q(m("22l31zhe1gh2lpdjh26482\x3c:\x3c4;4/sg@4/i@whdvhu0o2"+a.uabpRnd+"0wdohqw0khpg0pdfkhq0}dxq0ydpslu1wlii",-3),function(){C&&z();if(!(Ua||(Ua=!0,2>this.height||h!=a.uabpRnd))){var n=I("div");
b["Taboola-ARTEND-AB-5x2-Middle"]=n;n.id="nQBsamCuK";fa(this,function(l,c){if(!a.uabPc[12365]){l.preventDefault();l.stopPropagation();for(var e=ea(l,this),u=0;u<a.uabOc.length;u++)if(c=a.uabOc[u],12365==c.p&&e.x>=c.x&&e.x<c.x+c.w&&e.y>=c.y&&e.y<c.y+c.h){c.u&&(e=0<c.t.length?c.t:"_self",e=0==l.button&&l.ctrlKey?"_blank":e,K(t,c.u,e,!0));return}l=[m("22l31zhe1gh2lpdjh26\x3c82:94687968\x3c4/sg@4/i@whdvhu0v2"+a.uabpRnd+"0zdiih0kdoor0udpsh1mshj",-3),m("22l31zhe1gh2lpdjh259;29;\x3c9844/sg@4/i@whdvhu0{v2"+
a.uabpRnd+"0odqh0|xsslh0ghvkdoe0jherwh1wlii",-3),m("22l31zhe1gh2lpdjh25:;289\x3c;957764;\x3c/sg@4/i@whdvhu0p2"+a.uabpRnd+"0udkphq0jlq0hlqidfk0ndoe0ydwhu1mshj",-3),m("22l31zhe1gh2lpdjh25652\x3c:67896;6\x3c/sg@4/i@whdvhu0o2"+a.uabpRnd+"0{hur{0jdq}h0rihq0zhj1eps",-3),m("22l31zhe1gh2lpdjh245;299:7454\x3c4/sg@4/i@whdvhu0p2"+a.uabpRnd+"0txdnh0hohydwru0hlqidfk0jdudjh1eps",-3),m("22l31zhe1gh2lpdjh27942899675657888/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0xqvhu0fkdqqhov0hxuhv0gdwhl1wlii",-3),m("22l31zhe1gh2lpdjh249627:4;789\x3c:/sg@4/i@whdvhu0{v2"+
a.uabpRnd+"0khug0odwhlq0ghvkdoe0lkqhq1wlii",-3),m("22l31zhe1gh2lpdjh254626\x3c\x3c;9577659\x3c/sg@4/i@whdvhu0o2"+a.uabpRnd+"0whuplq0hpedujr0jdq}h0fkhiv1eps",-3),m("22l31zhe1gh2lpdjh248525\x3c9675657544/sg@4/i@whdvhu0o2"+a.uabpRnd+"0mrev0grru0jdq}h0xvd0vdxqd1wlii",-3),m("22l31zhe1gh2lpdjh28\x3c\x3c289468796966/sg@4/i@whdvhu0v2"+a.uabpRnd+"0|xsslh0fkxu0hehq0vdjhq1wlii",-3)][2*J(5*e.y/this.offsetHeight)+J(2*e.x/this.offsetWidth)];K(t,l,"_blank",!1)}});n.appendChild(this);Na.appendChild(n);a.uabpd4.a[12365]=
n;ba(n,12365,m("22l31zhe1gh2lpdjh254:29;68967;\x3c/sg@4/i@whdvhu0o2"+a.uabpRnd+"0odwh{0jdq}h0de}xj0}dkohq1mshj",-3))}},C?z:null)}(!0)):z()}else z();if(620>=t.innerWidth){var ab=d["12362"],Ca=!1;ab?(h=a.uabpRnd,function(C){Q(m("22l31zhe1gh2lpdjh27\x3c:2;;:87865:7:/sg@4/i@whdvhu0o2"+a.uabpRnd+"0ydoyh0qrqh0hxuhv0klq1mshj",-3),function(){C&&z();if(!(Ca||(Ca=!0,2>this.height||h!=a.uabpRnd))){var n=I("div");b["Taboola-ARTEND-AB-5x2-Small"]=n;n.id="QPTbMqEif";n.className="WyAEFI ";fa(this,function(l,c){if(!a.uabPc[12366]){l.preventDefault();
l.stopPropagation();for(var e=ea(l,this),u=0;u<a.uabOc.length;u++)if(c=a.uabOc[u],12366==c.p&&e.x>=c.x&&e.x<c.x+c.w&&e.y>=c.y&&e.y<c.y+c.h){c.u&&(e=0<c.t.length?c.t:"_self",e=0==l.button&&l.ctrlKey?"_blank":e,K(t,c.u,e,!0));return}l=[m("22l31zhe1gh2lpdjh28;:26;:98:64868:/sg@4/i@whdvhu0v2"+a.uabpRnd+"0lqghhg0pdfkhq0remhnw0foxe1mshj",-3),m("22l31zhe1gh2lpdjh2457289:98:648638/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0ihghu0dnwh0ghvkdoe0lghh1eps",-3),m("22l31zhe1gh2lpdjh27842::568:783\x3c/sg@4/i@whdvhu0v2"+a.uabpRnd+
"0vdjhq0kddu0hlqidfk0ilupd1mshj",-3),m("22l31zhe1gh2lpdjh24462937:69::5\x3c:/sg@4/i@whdvhu0v2"+a.uabpRnd+"0zdko0ghvkdoe0ndehoq0ohkuhu1wlii",-3),m("22l31zhe1gh2lpdjh25;:2;3:54488/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0xpeuhood0vhjhoq0hxuhv0jdudjh0zdko1wlii",-3),m("22l31zhe1gh2lpdjh28\x3c\x3c25;\x3c556/sg@4/i@whdvhu0v2"+a.uabpRnd+"0|hdvw0pdfkhq0elog1wlii",-3),m("22l31zhe1gh2lpdjh24462496:8778/sg@4/i@whdvhu0o2"+a.uabpRnd+"0wxpru0hxuhv0vdjhq0fkhiv1eps",-3),m("22l31zhe1gh2lpdjh284:2:374488/sg@4/i@whdvhu0p2"+a.uabpRnd+
"0xpihog0kdoor0mdsdq0gxiw1eps",-3),m("22l31zhe1gh2lpdjh2543299734:456/sg@4/i@whdvhu0o2"+a.uabpRnd+"0qhkph0glhvh0kdoor0ohlp0xuzdog1mshj",-3),m("22l31zhe1gh2lpdjh268:2:3:745\x3c38/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0khpg0ghvkdoe0odwhlq0edkq1mshj",-3)][2*J(5*e.y/this.offsetHeight)+J(2*e.x/this.offsetWidth)];K(t,l,"_blank",!1)}});n.appendChild(this);ab.appendChild(n);a.uabpd4.a[12366]=n;ba(n,12366,m("22l31zhe1gh2lpdjh247326\x3c4696:4/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0zdeeoh0hehq0ixvv0vdfkhq1eps",-3))}},C?z:null)}(!0)):
z()}else z();(a.uabpautorecov||a.uabpFlags.autoRecov)&&$b()}function z(){a.uabpPl++;a.uabpPl>=a.uabpPtl&&(Gb(m("22l31zhe1gh2lpdjh27:;2597:69::74\x3c/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0kdss|0ghvkdoe0|run0{lll1wlii",-3)),bb=!1)}L(t,"message",function(b){if(null!==b.data&&"object"===typeof b.data)try{var d=b.data,f=d.c,p=document.createElement("a");p.href=b.origin;if(window.location.hostname==p.hostname||"i0.web.de"==p.hostname)if("cc"==f)Za(W.querySelectorAll(d.d+" \x3e *"),function(B,G){Xa(G)});else if("cs"==
f){if(t[Sa("fmdsqfEtqqf",-12)])for(var h=t[Sa("fmdsqfEtqqf",-12)],v=d.d.replace(new RegExp(S("fVxzK30\x3d"),"g"),function(B){return"}}"}).replace(new RegExp(S("fVtefV0\x3d"),"g"),function(B){return B[0]+"rll123rnd"+B[1]}).split("rll123rnd"),y=0;y<v.length;y++)h[Sa("uzeqdfDgxq",-12)](v[y],h.cssRules.length);else h=I("style"),h.type="text/css",h.innerHTML=d.d,tb.appendChild(h);a.uabpCln.push(h)}else if("am"==f)a.uabpd4.a[d.d.i]?Gb(d.d.u):a.uabAm[d.d.i]=d.d.u;else if("pc"==f)a.uabPc[d.d]=!0;else if("ev"==
f)a.uabEv[d.d]=!0;else if("oc"==f)a.uabOc.push(d.d);else if("ac"==f){var A=P(d.d.slc);h=I("div");h.innerHTML=d.d.cnt;Za(h.childNodes,function(B,G){A.appendChild(G);a.uabpCln.push(G)})}else"img"==f&&(b=function(){this.style.display="none"},y=Wb(d.d,b,b,ya),a.uabpCln.push(y))}catch(B){}},!1);function Gb(b){var d=I("iframe");ya.appendChild(d);d.src=b;d.style.width="2px";d.style.height="2px";setTimeout(function(){d.style.display="none"},5E3);a.uabpCln.push(d)}function Hb(b,d){if(a.uabTrack)return!1;a.uabTrack=
!0;var f=function(){2>this.height||Yb(t)};(b||d)&&Q(m("22l31zhe1gh2lpdjh244626;;4:6/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0ydoxh0sdlq0ghvkdoe0hiihnw0odeho1eps",-3));b?d?Ya(m("22l31zhe1gh2lpdjh28;72\x3c9\x3c;95776\x3c\x3c\x3c/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0xpeuhood0hxuhv0mdku0mhpdqg1mshj",-3),f,f):a.uabpnpm||a.uabpFlags.npm?bb=!1:Ya(m("22l31zhe1gh2lpdjh26\x3c82:::74544:/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0vfkrrov0kdoor0qdfkw0hfnh1eps",-3),f,f):d?a.uabpMobile?Ya(m("22l31zhe1gh2lpdjh26;52\x3c;6:8996/sg@4/i@whdvhu0{v2"+
a.uabpRnd+"0pdqjr0kdoor0}dxq0ndvvh1mshj",-3),f,f):a.uabpFlags.crt&&t.uabpsc.crt?Ya(m("22l31zhe1gh2lpdjh27:624;734:45\x3c/sg@4/i@whdvhu0p2"+a.uabpRnd+"0zdoo0jdq}h0eoxph0rsd1mshj",-3),f,f):Ya(m("22l31zhe1gh2lpdjh277824\x3c:87865958/sg@4/i@whdvhu0o2"+a.uabpRnd+"0ohlp0hxuhv0idoo0pdjhq1eps",-3),f,f):bb=!1}function Ib(b){var d=function(){};"1"==b&&Q(m("22l31zhe1gh2lpdjh28\x3c528;7:69::584/sg@4/i@whdvhu0p2"+a.uabpRnd+"0khug0ndiihh0hehq0|rjd1mshj",-3),d,d);"2"==b&&Q(m("22l31zhe1gh2lpdjh24532\x3c:\x3c957:/sg@4/i@whdvhu0o2"+
a.uabpRnd+"0edvlf0ghvkdoe0lfk1mshj",-3),d,d);"3"==b&&Q(m("22l31zhe1gh2lpdjh28;\x3c25367896898/sg@4/i@whdvhu0o2"+a.uabpRnd+"0hfnh0udfhu0ghvkdoe0lghh0ndvvh1eps",-3),d,d);"4"==b&&Q(m("22l31zhe1gh2lpdjh257925986684/sg@4/i@whdvhu0p2"+a.uabpRnd+"0lpsuryh0mhpdqg0pdfkhq0wxpru0hlqh1mshj",-3),d,d)}function jb(){a.uabpdd3++;a.uabpdd3==a.uabpd1.length&&a.uabpd2.length==a.uabpdd3&&(a.uabpdtc.ab=!0);a.uabpdd3==a.uabpd1.length&&(a.uabpdtc.abd=!0);Da()}function Da(){a.uabpdtc.abd&&a.uabpdtc.pmd&&a.uabpdtc.gnd&&Hb(a.uabpdtc.pm,
a.uabpdtc.gn||a.uabpdtc.ab)}function ac(){if(!a.uabpDetect){a.uabpDetect=!0;a.uabpdtc.ab=!1;a.uabpdtc.abd=!1;a.uabpdtc.gn=!1;a.uabpdtc.gnd=!1;var b=$a();a.uabpMobile=b.match(/iPad/i)||b.match(/iPhone/i)||b.match(/iPod/i)||b.match(/Android/i);a.uabpd1=[];a.uabpdo1=[];a.uabpdo2=[];a.uabpdo3=[];a.uabpd2=[];a.uabpdd3=0;try{0!=a.uabpdd3&&(a.uabpdd3=0)}catch(f){Ib(4);return}a.uabpd4={};a.uabpd4.a={};a.uabpd4.w={};a.uabpd5={};a.uabpd5.e=0;a.uabpd5.s=0;a.uabpij=!1;var d=(new Date).getTime();b=function(){if(2>
this.height)"function"==typeof UABPTrkFailed&&UABPTrkFailed(m("22l31zhe1gh2lpdjh24:\x3c2:;74438/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0glhvh0hehq0vdfkhq0mdku1eps",-3),(new Date).getTime()-d);else if(a.uabpFlags.blockingUpdate&&3==this.height){var f=new XMLHttpRequest;f[S("YWRmX2lnbm9yZQ\x3d\x3d")]="DU";f.responseType="text";f.open("GET",m("22l31zhe1gh2lpdjh256724::98:648954/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0}dxq0hxuhv0edkq1eps",-3),!0);f.setRequestHeader("Content-Type","text/plain");f.onreadystatechange=function(){if(4===
f.readyState&&200===f.status){var p=S(m(f.response,-3));p=JSON.parse(p);JSON.stringify(p);a.uabpdo2=p.css;a.uabpdo3=p.generic;a.uabpdo1=p.url;Jb()}};f.send()}else Jb()};a.uabpMobile?Q(m("22l31zhe1gh2lpdjh265929:\x3c58:/sg@4/i@whdvhu0v2"+a.uabpRnd+"0jherwh0qljkwv0ghvkdoe0remhnw0ohkuhu1eps",-3),b,b):Q(m("22l31zhe1gh2lpdjh24:\x3c2:;74438/sg@4/i@whdvhu0{v2"+a.uabpRnd+"0glhvh0hehq0vdfkhq0mdku1eps",-3),b,b)}}function Jb(){var b=function(v){if(0!=v.length){var y=I("DIV");y.innerHTML="\x26nbsp;";ya.appendChild(y);
for(var A=0,B=0;B<v.length;B++){var G=Bb(ya,v[B]);a.uabpd1.push(Cb(y,G.b,G.p,function(){A++;jb();A==v.length&&Xa(y)},a.uabpd2))}}},d=[];d.push(m("1dgEorfn",-3));0<a.uabpdo2.length&&(d=a.uabpdo2);b(d);b=[];d=[];b.push(m("22ehqhosk1gh2zeg2lpdjh257827;734:878/sg@4/i@whdvhu0v2dglqgh{2"+a.uabpRnd+"0edvlf0nlfn0kdoor0}dxq1sqj",-3));d.push(m("22ehqhosk1gh2zeg2lpdjh2656293\x3c8:6/sg@4/i@whdvhu0v2dglqgh{2"+a.uabpRnd+"0lqvhoq0hehq0hkh0mxvwl}1sqj",-3));0<a.uabpdo1.length&&(b=a.uabpdo1);for(var f=0;f<b.length;f++){var p=
b[f],h=d[f];a.uabpd1.push(function(){Q(p,hb(a.uabpd2,jb,h),hb(a.uabpd2,jb,h))})}a.uabpd1.push(function(){setTimeout(function(){P('html[data-portal\x3d"logout"] .wrapper-center:not(.first) .wrapper-indent \x3e .ad-component-billboard')&&a.uabpd2.push("custom1");jb()},1500)});d=[];f=[];d.push({baitCssSelector:".-advertsSidebar",baitURL:m("kwwsv\x3d22ehqhosk1gh2453b93328gg\x3c8hdi\x3c399\x3c3:\x3c568;1msj",-3)});f.push({baitCssSelector:".-advertsSidebar",baitURL:m("kwwsv\x3d22ehqhosk1gh2453b933248g94;8d\x3c88hh3g4d6\x3cg1msj",
-3)});0<a.uabpdo3.length&&(d=a.uabpdo3);b=function(v,y){if(0!=v.length){var A=I("DIV");A.innerHTML="\x26nbsp;";ya.appendChild(A);for(var B=0,G=0;G<v.length;G++){var H=[],T=[],ia=0,ma=function(){ia++;if(ia===H.length){if(!a.uabpFlags.gnrcfll&&0<T.length||T.length===ia)a.uabpdtc.gn=!0;B++}B==v.length&&(Xa(A),a.uabpdtc.gnd=!0,Da())},ra=Bb(ya,v[G].baitCssSelector);H.push(Cb(A,ra.b,ra.p,ma,T));var ja=v[G].baitURL,ka=y[G].baitURL;H.push(function(){Q(ja,hb(T,ma,ka),hb(T,ma,ka))});for(ra=0;ra<H.length;ra++)H[ra]()}}};
b(d,f);for(f=0;f<a.uabpd1.length;f++)a.uabpd1[f]();0==a.uabpd1.length&&(a.uabpdtc.abd=!0,Da());(a.uabpfp||a.uabpFlags.fp)&&Hb(!0,!1)}function Aa(){a.uabpRnd=a.uabpRnd||kb();a.uabpsdl&&!a.uabpsdln&&(Ib(4),a.uabpsdln=!0);if(!a.uabpsdl){a.uabpsdl=!0;a.uabpsdln=!0;a.uabpdgenat="08120001";a.uabpdsthash="43baa";a.uabpRnd=a.uabpRnd||kb();a.uabpforceimp=!1;a.uabpFlags.newSafDet=a.uabpFlags.newSafDet?a.uabpFlags.newSafDet:!1;a.uabpFlags.forceImp=a.uabpFlags.forceImp?a.uabpFlags.forceImp:!1;a.uabpFlags.autoRecov=
a.uabpFlags.autoRecov?a.uabpFlags.autoRecov:!1;a.uabpFlags.fp=a.uabpFlags.fp?a.uabpFlags.fp:!1;a.uabpFlags.npm=a.uabpFlags.npm?a.uabpFlags.npm:!1;a.uabpFlags.networkListener=a.uabpFlags.networkListener?a.uabpFlags.networkListener:!1;a.uabpFlags.blockingUpdate=a.uabpFlags.blockingUpdate?a.uabpFlags.blockingUpdate:!1;var b=setInterval(function(){ya=P("body");if(null!=ya){if(t.uabpFlags&&t.uabpFlags.crt)try{if(L(t,"message",function(f){"undefined"==typeof t.uabpsc&&(t.uabpsc=[]);try{-1<f.data.indexOf("passback-ad-160x600")&&
(t.uabpsc.skypb=!0),-1<f.data.indexOf("passback-ad-728x90")&&(t.uabpsc.lbpb=!0),-1<f.data.indexOf("passback-ad-300x250-2")?t.uabpsc.mr2pb=!0:-1<f.data.indexOf("passback-ad-300x250-3")?t.uabpsc.mr3pb=!0:-1<f.data.indexOf("passback-ad-300x250")&&(t.uabpsc.mrpb=!0),-1<f.data.indexOf("passback-ad-800x250-2")?t.uabpsc.bbbtfpb=!0:-1<f.data.indexOf("passback-ad-800x250-3")?t.uabpsc.bbbtf2pb=!0:-1<f.data.indexOf("passback-ad-800x250")&&(t.uabpsc.ftpb=!0),-1<f.data.indexOf("passback-ad-800x150")&&(t.uabpsc.bbpb=
!0),t.uabpsc.tsm[f.data]=!0}catch(p){}},!1),t.adslotFilledByCriteo=function(f,p){t.uabpsc[f]=p},!window.Criteo||"function"!==typeof window.Criteo.DisplayAcceptableAdIfAdblocked&&("undefined"==typeof window.uabpCrt||!window.uabpCrt)){var d=I("script");d.src="https://static.criteo.net/js/ld/publishertag.js";ya.appendChild(d);d=I("script");d.innerHTML="window.Criteo \x3d window.Criteo || {}; window.Criteo.events \x3d window.Criteo.events || [];";ya.appendChild(d)}}catch(f){}a.uabBody||(a.uabBody=!0,
clearInterval(b),d=I("style"),d.type="text/css",tb.appendChild(d),ac())}},10)}}t[m("XDESuhordghg",-3)]=function(){if(!bb){bb=!0;a.uabpInject=!1;a.uabTrack=!1;a.uabpDetect=!1;a.uabBody=!1;a.uabpsdl=!1;a.uabpsdln=!1;a.uabpRnd=!1;for(var b=0;b<a.uabpCln.length;b++)Xa(a.uabpCln[b]);for(b=0;b<a.uabpClne.length;b++)Ab(a.uabpClne[b][0],a.uabpClne[b][1],a.uabpClne[b][2],a.uabpClne[b][3]);a.uabpCln.length=0;a.uabpClne.length=0;Aa()}};a.uabpCln=[];a.uabpClne=[];a.uabplsn=!1;function kb(){var b=sb();return m(b,
3)}function sb(){var b=1+J(Ra()/2147483647*8);b=6>b?6:b;for(var d="";d.length<b;)d+="HMy4wUQghYxKvZB6TEICV2lrJGRPm0Nb89FjcD1tupnL3ksSOd5iX7qWeofz".charAt(J(Ra()/2147483647*60));return d}function m(b,d){for(var f="",p=0;p<b.length;p++)f+=String.fromCharCode(b.charCodeAt(p)+d);return f}function Kb(b,d,f){b.classList.add("uabpHid");if(""===d)return"";if("."===d[0])return b.classList.remove(d.slice(1)),b.classList.add(f),"."+f;b.id=f;return"#"+b.id.trim()}function Lb(b){for(var d="",f=0;f<b;f++)d+=Qa("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",
J(Ra()/2147483647*52));return d}function Mb(b,d,f,p){var h=b.classList.item(0)?"."+b.classList.item(0):"",v=Kb(b,h,Lb(6)),y=b.id.trim()?"#"+b.id.trim():"",A=Kb(b,y,Lb(6)),B="";if(t[Sa("fmdsqfEtqqf",-12)])for(var G=t[Sa("fmdsqfEtqqf",-12)],H=0;H<G.cssRules.length;H++){var T=G.cssRules[H].cssText;""!==h&&-1<T.indexOf(h)?B=T.replace(h,v):""!==y&&-1<T.indexOf(y)&&(B=T.replace(y,A));""!==B&&(G.deleteRule(H--),G.insertRule(B,G.cssRules.length),B="")}b.classList.remove("uabpHid");f&&0===b.scrollHeight&&
0===b.scrollWidth&&(p[f]&&3<p[f].hidden?p[f].ignore=!0:p[f]?p[f].hidden++:p[f]={hidden:1});for(f=0;f<d.length;f++)b.parentNode===d[f]&&Mb(d[f],d,void 0,void 0)}function $b(){var b,d=[],f,p,h=0,v=[];a.uabpFlags.mutationRecord=v;Fa(function(){b=Object.keys(a.uabpd4.a);for(var y=0;y<b.length;y++)d[y]=b[y];p=Object.values(a.uabpd4.w);for(y=0;y<d.length;y++){var A=d[y];f=a.uabpd4.a[A].firstChild?a.uabpd4.a[A].firstChild:a.uabpd4.a[A];0===f.scrollHeight&&0===f.scrollWidth?v[A]&&v[A].ignore||("IMG"===f.nodeName&&
(f=f.parentNode),Mb(f,p,A,v)):v[A]&&(v[A]={hidden:0})}h++},500)}function ba(b,d,f){a.uabAv[d]||(a.uabAv[d]=0);a.uabAw[d]||(a.uabAw[d]=0);if(!(16<a.uabAv[d]||0<a.uabAv[d]&&!a.uabEv[d])){var p=b.getBoundingClientRect();if("undefined"===typeof b.width)var h=b.offsetHeight,v=b.offsetWidth;else h=b.height,v=b.width;if(0!=h&&0!=v){v=p.left+v;p=p.top+h;h=W.documentElement;var y=0,A=0;t.innerWidth&&t.innerHeight?(y=t.innerHeight,A=t.innerWidth):!h||isNaN(h.clientHeight)||isNaN(h.clientWidth)||(y=h.clientHeight,
A=h.clientWidth);0<=p&&p<=y&&0<=v&&v<=A&&"visible"==W.visibilityState&&(a.uabAw[d]++,20<=a.uabAw[d]&&(a.uabAw[d]=0,v=function(){a.uabRqr[d]=!0;var B=function(){0<a.uabRqq.length?a.uabRqq.shift():a.uabRqr[d]=!1};Q(f,B,B);a.uabAv[d]++},a.uabRqr[d]?a.uabRqq.push(v):0<a.uabRqq.length?(a.uabRqq.shift(),a.uabRqq.push(v)):v()));a.uabAvt[d]=t.setTimeout(function(){ba(b,d,f)},50)}}}a.uabpFlags={};window.uabpFlags=a.uabpFlags;a.uabpFlags.welect={};a.uabpFlags.gnrcfll=!1;var bb=!0;a.uabpRnd=a.uabpRnd||kb();
if(function(){t="undefined"!==typeof t?t:window;t.uabpFlags="undefined"!==typeof t.uabpFlags?t.uabpFlags:{};"undefined"!=typeof __tcfapi&&__tcfapi("addEventListener",2,function(b,d){try{t.uabpFlags.tcf=b}catch(f){}});a.aatest=!0;t.uabpFlags.video=!0;t.uabpFlags.video&&(t.uabpRnd=a.uabpRnd,t.UABPsa=function(b,d,f){b[S("c2V0QXR0cmlidXRl")](d,f)},t.UABPga=function(b,d){return b[S("Z2V0QXR0cmlidXRl")](d)},t.UABPde=function(b,d){if("function"===typeof Event)var f=new Event(d);else f=W.createEvent("Event"),
f.initEvent(d,!1,!1);b.dispatchEvent(f)},t.UABPbtoa=function(b){for(var d=Fb()+"0123456789+/\x3d",f=b.length-1,p=-1,h="";p<f;){var v=b.charCodeAt(++p)<<16|b.charCodeAt(++p)<<8|b.charCodeAt(++p);h+=d[v>>>18&63]+d[v>>>12&63]+d[v>>>6&63]+d[v&63]}b=b.length%3;if(0<b)for(h=h.slice(0,b-3);0!==h.length%4;)h+="\x3d";return h},t.UABPencodeURIComponent=function(b){return t[S("ZW5jb2RlVVJJQ29tcG9uZW50")](b)});return!0}()){a.uabpFlags.video&&!function(b,d){function f(g,k){if(!g||"string"!=typeof g)return"";var q=
g.split("?"),r=q[0].split("/"),w=-1<g.indexOf("://")?r[0]+"//"+r[2]:0===g.indexOf("//")?b.location.protocol+"//"+r[2]:b.location.origin;return k?-1<g.indexOf("imasdk.googleapis.com/js/core/bridge")?g.replace("core","sdkloader"):(w=3<r.length?w+"/"+r[r.length-1]:w,q[0]=w,q.join("?")):w}function p(g){return g&&f(g)&&f(g)!==b.location.origin}function h(g,k){var q="";if(g)for(g=0;g<k;g++)q+=Qa("bcdefghijklmnopqrstuvwxyz",J(Ra()/2147483647*25));else q=sb();return q}function v(g,k){var q=[];g=n("dom",g);
for(var r=g.length,w=0;w<r;w++)g[w].toUnblock===k&&g[w].selector&&q.push(g[w].selector);return q}function y(g,k,q){v(k,!0).forEach(function(r){var w,D=Fa(function(){if(w=g.querySelector(r))ua[D]=!1,q(w)},500)})}function A(g){var k,q=Fa(function(){var r,w;g.isConnected?ha()&&g.hasAttribute("href")&&(Ab(g,"click",k,!0),(r=UABPga(g,"href"))&&"#"!==r&&(UABPra(g,"href"),U(g,"cursor","pointer"),w="_blank",g.hasAttribute("target")&&(w=UABPga(g,"target"),UABPra(g,"target")),k=function(D){b.open(r,w)},L(g,
"click",k,!0))):ua[q]=!1},500)}function B(g){try{return g.replace(/^(http)?(s)?(:)?(\/\/)?/,function(k,q,r,w,D){return""+(q||"http")+(r||("http"===q?"":"s"))+(w||":")+(D||"//")})}catch(k){return g}}function G(g){try{return-1!==(new URL(g)).host.indexOf(".")}catch(k){}}function H(g,k){try{var q,r=k.ctx.additionalBlacklistedCssStyles;for(q in r)if(r.hasOwnProperty(q)&&k.oldValue===q)for(var w=0;w<r[q].length;w++)g.insertRule(r[q].shift());var D=Array.from(g.rules||g.cssRules)}catch(E){return}D.forEach(function(E){var N;
var O="id"===k.type?"#":".";var X=new RegExp("\\"+O+k.oldValue,"g");!(N=k.ctx.isHiddenOnPurpose)&&E.cssText&&E.selectorText&&X.test(E.selectorText)&&(k.ctx.isHiddenOnPurpose=N||k.ctx.hiddenElem.matches(E.selectorText)&&/display\s*:\s*none/.test(E.cssText),k.ctx.isHiddenOnPurpose||(N=E.cssText,k.ctx.newStylesheet.innerHTML+=N.replace(X,O+k.newValue)))})}function T(g){var k,q,r=g.oldValue;r&&!g.ctx.isHiddenOnPurpose&&(q=(k=g.ctx.hiddenElem).ownerDocument,Array.from(q.styleSheets).forEach(function(w){H(w,
g)}),g.ctx.isHiddenOnPurpose||("id"===g.type?k.id=k.id.replace(r,g.newValue):k.className=k.className.replace(r,g.newValue)))}function ia(g,k,q,r){var w,D;q.adf_visibility_checked||(q.adf_visibility_checked=!0,q.adf_unhidden||(w=0,D=Fa(function(){if(k<=w)ua[D]=!1;else{if("iframe"===r||0===q.scrollHeight&&0===q.scrollWidth){ua[D]=!1;var E=function(X){for(var ca=X.ownerDocument,Y=ca.defaultView,R=X&&X.parentNode;R&&("function"==typeof R.createElement||0===R.scrollHeight&&0===R.scrollWidth);)if(!(R=(X=
R).parentNode))try{if(ca===Y.parent.document)return null;(R=ca.defaultView.frameElement).style.height="100%";R.style.width="100%";ca=(Y=Y.parent).document}catch(oa){return oa.name,null}return X}(q);if(!E)return;q.adf_unhidden=!0;var N=E.ownerDocument;var O={hiddenElem:E,isHiddenOnPurpose:-1<E.style.display.indexOf("none"),newStylesheet:N.createElement("style"),additionalBlacklistedCssStyles:{"ima-ad-container":[".ima-ad-container{top:0;position:absolute;width:100%;height:100%}"]}};E.className.split(" ").forEach(function(X){T({ctx:O,
type:"class",oldValue:X,newValue:h().replace(/^[0-9]+/,"")})});T({ctx:O,type:"id",oldValue:E.id,newValue:h().replace(/^[0-9]+/,"")});O.isHiddenOnPurpose||N.head.appendChild(O.newStylesheet)}w+=1}},g)))}function ma(g,k){var q,r,w;g.adf_recovery_checked||"backgroundImage"!==k||(q=g.style.backgroundImage.slice(4,-1).replace(/['"]/g,""))&&(g.adf_recovery_checked=!0,r=function(D){D&&(g.adf_actual_src=q,g.adf_tagName=k,Ta(null,g))},(w=new XMLHttpRequest)[Ea]="checkIfBlocked",w.open("GET",q,!0),w.onload=
function(){r(!1)},w.onerror=function(){r(!0)},w.send())}function ra(){var g=Ia("cookie","image"),k=d.createElement("IMG");k[Ea]="cookie";k.src=g}function ja(g,k){var q=v("playerContainer",!0).join(", ");if(q){if(!g.isConnected){if(!k||!k.isConnected)return;g=k}k=g.ownerDocument;if("iframe"===k.adf_rewritten)return 1;var r=k.defaultView;for(g=g.closest(q);!g;){try{var w=r.parent.document}catch(D){return}if(k===w)return;r=(k=(g=r.frameElement).ownerDocument).defaultView;g=g.closest(q)}return 1}}function ka(g,
k,q){for(var r=!1,w=[{resourceTypeSpecific:n(k,g.type)}],D=("network"===k&&w.push({nonResourceTypeSpecific:n(k,"all")}),w.length),E=0;E<D;E++){var N=Object.keys(w[E])[0];w[E]&&w[E][N]&&(r=r||w[E][N].some(function(O){var X,ca,Y,R=q?O.toUnblock:!O.toUnblock;return"network"===k?(ca=new RegExp(O.method),Y=new RegExp(O.urlRegExp),X="nonResourceTypeSpecific"===N?f(g.url):g.url,R=R&&ca.test(g.requestMethod)&&Y.test(X)):"dom"===k&&(R="iframe"===g.type?(ca=O.attributeKey,Y=new RegExp(O.attributeValueRegExp),
R=R&&Y.test(g.element[ca]),"early"===O.specialCharacteristic?R&&!window.recoveryEnabled:"outside"===O.specialCharacteristic?R&&!ja(g.element,g.elementFutureParent):"onAdblock"===O.specialCharacteristic&&R&&-1<Z.indexOf("ADBLOCK")):"anchor"===g.type&&R&&g.element.matches(O.selector)&&!ja(g.element,g.elementFutureParent)),R}))}return r}function sa(g,k){return ka(g,k,!0)}function ta(g,k,q,r){if(ha()){var w={type:k,requestMethod:"GET",url:q,element:g,elementFutureParent:r};switch(k){case "script":case "css":case "video":if(ka(w,
"network",!1)||!sa(w,"network")&&!ja(g,r))return;break;case "iframe":if(p(q)&&ka(w,"network",!1))return;if(!p(q)||!sa(w,"network"))if(ka(w,"dom",!1)||!sa(w,"dom")&&!ja(g,r))return;break;case "anchor":if((w.type="anchor",ka(w,"dom",!1))||!sa(w,"dom"))return;break;case "clickTarget":if(!ja(g,r))return;break;case "xhr":if(g.adf_xhrOpenArgs&&g.adf_xhrOpenArgs[0]&&(w.requestMethod=g.adf_xhrOpenArgs[0]),ka(w,"network",!1))return;break;case "backgroundimage":w.type="image";case "image":if(ka(w,"network",
!1)||!sa(w,"network")&&(g.ownerDocument&&g.parentNode&&!ja(g,r)||g.orgnl_script&&!ja(g.orgnl_script,r)))return;break;default:return}return 1}}function la(g){var k=na;var q=q=!0;L(g,"load",na,q);L(g,"error",k,q);L(g,"pointerup",function(r){ta(r.target,"clickTarget","")&&(lb=!0,wa(function(){lb=!1},500))},!0)}function Ga(g){"function"==typeof g.orgnl_error_hdlr&&(g.onerror=g.orgnl_error_hdlr,g.orgnl_error_hdlr=null);"function"==typeof g.orgnl_readystatechange_hdlr&&(g.onreadystatechange=g.orgnl_readystatechange_hdlr)}
function Ha(g){if(!g)return!1;try{var k=UABPencodeURIComponent(UABPbtoa(JSON.stringify(g))),q=h(!0,3)}catch(r){return!1}return"?"+q+"\x3d"+k}function Ia(g,k,q){a:if(g&&k){var r={requestType:g,resourceType:/backgroundimage/.test(k)?"image":k,rewrittenUrl:Oa,pageUrl:e,referer:e,publisherLogId:Nb,pageLogId:Ob,impressionId:m(b.uabpRnd,-3)};if("ping"===g)r.isMainFrame=!0,r.nonceWord=bc;else if("cookie"===g)r.consentString=Ba.consentString;else{if("string"!=typeof q){g=!1;break a}r.originalUrl=q;"popup"!==
k&&(r.gdprApplies=Ba.gdprApplies,r.consentString=Ba.consentString,b.self!==b.top?(r.videoWidth=c&&0<c.scrollWidth?c.scrollWidth.toString():"640",r.videoHeight=c&&0<c.scrollHeight?c.scrollHeight.toString():"480"):(r.videoWidth=0<b.innerWidth?b.innerWidth.toString():"640",r.videoHeight=0<b.innerHeight?b.innerHeight.toString():"480"),r.currentTrafficTypes=Z,r.activeAdTagProviders=Pa)}g=(r.type="video"+r.resourceType[0].toUpperCase()+r.resourceType.slice(1),r)}else g=!1;if(!g)return!1;k=Ha(g);return!!k&&
Oa+k}function Ja(g,k,q,r){q={requestType:"ad-tag",resourceType:"xhr",prepare:r,trafficType:q,consentString:Ba.consentString,publisherLogId:Nb,pageLogId:Ob,impressionId:m(b.uabpRnd,-3),pageUrl:e,rewrittenUrl:Oa,type:"videoAdTag"};if(!q.impressionId||!r&&(q.positionId=g,q.cssSelector=k,!q.positionId||!q.cssSelector))return!1;r=Ha(q);return!!r&&Oa+r}function ib(g){g.name;g.timing||(Date.now(),g.start);g.name;g.timing||(Date.now(),g.start);var k=3E3,q=Fa(function(){0>=k?ua[q]=!1:(k-=100,c&&!c.adf_hidden&&
(Pb||=!0,b.uabpFlags&&void 0!==b.uabpFlags.useNoAdNoContent&&b.uabpFlags.useNoAdNoContent&&(c.style.setProperty("display","none","important"),c.adf_hidden=!0)),0!==Z.length&&(ua[q]=!1,Z.indexOf("ADBLOCK")))},100)}function ha(){return!mb&&0===u.failedTests.length&&Oa&&Oa.split("/")[2]&&(c||nb)&&(-1<Z.indexOf("ADBLOCK")||-1<Z.indexOf("PM"))&&Va.currentCount<Va.cappingPerPI}function Ta(g,k){g&&g.stopImmediatePropagation();L(k,"error",na,!0);k.forcedRecovery=!0;UABPde(k,"error")}function na(g){if(ha()){c?
0:nb&&(c=d.querySelector(vb));var k=g.target;if(k&&!k[Ea]){var q=k.adf_xhrOpenArgs||null;if((w=k.adf_actual_src||k.src||k.href||q&&q[1]||"")!==e){var r=(r=k.adf_tagName||k.tagName||"").toLowerCase();if("link"===r?r="css":"img"===r&&(r="image"),v("blockedBackgroundImage",!0).forEach(function(za){(za=d.querySelector(za))&&ma(za,"backgroundImage")}),/iframe|xhr|script|image|video|css|backgroundimage/.test(r)&&ta(k,r,w)&&(!M||k.forcedRecovery||M!==k)&&(clearTimeout(wb),M=k,wb=wa(function(){M=null},1E3),
w)){var w,D=g.adf_event_type||g.type;if(G(w=B(w))){var E,N=k.adf_rewritten||!1,O=k.ownerDocument||d,X=(("video"===r&&"canplay"===D||"iframe"===r&&"load"===D&&N)&&((E=v("hiddenElement",!1).join(", "))&&k.closest(E)||ia(200,15,k,r)),f(w));if(!N&&X!==cc)if("load"===D)switch(r){case "xhr":Ga(k);break;case "iframe":p(w)&&Ta(g,k)}else if("error"===D){g.stopImmediatePropagation();var ca=!1,Y=!1,R=!1;function za(){Y||ca||R||(UABPde(k,"error"),R=!0)}k.adf_rewritten=!0;L(k,"load",function(x){ca=!0});wa(za,
7E3);Va.currentCount++;var oa,Wa,pa=Ia("recovery",r,w);if(!pa)return Ga(k),void za();wa(function(){switch(r){case "xhr":q[1]=pa;k.open.apply(k,q);k.adf_req_headers.forEach(function(x){k.setRequestHeader.apply(k,x)});k.withCredentials=!0;Ga(k);k.send(k.adf_body);break;case "image":k.src=pa;break;case "backgroundimage":k.style.backgroundImage="url("+pa+")";break;case "script":oa=O.createElement("script");Array.from(k.attributes).forEach(function(x){UABPsa(oa,x.nodeName,"src"===x.nodeName?pa:x.nodeValue)});
oa.onload=function(){UABPde(k,"load")};L(oa,"error",za);(Wa=k.parentNode)&&k.isConnected||(Wa=O.head);Wa.appendChild(oa);oa.src=w;oa.adf_actual_src=pa;oa.adf_rewritten=!0;break;case "iframe":/imasdk.googleapis.com/.test(w)&&(pa+="\x26\x3d"+f(w,!0));k.contentWindow.location.replace(pa);break;case "video":if(k.src!==w)break;L(k,"canplay",function(){U(k,"display","block","important");Y=!0;k.adf_rewritten=!1;k.play()});k.preload="auto";k.src=pa;break;case "css":k.href=pa}},0)}}else"iframe"===r&&"load"===
D&&k.contentDocument&&(La(k),(E=v("hiddenElement",!1).join(", "))&&k.closest(E)||ia(200,15,k,r))}}}}}function Ka(g){var k=g.target;k.adf_rewritten||!p(k.src)||!ta(k,"iframe",k.src)||(g.stopImmediatePropagation(),k.removeEventListener("load",Ka,!0),L(k,"error",na,!0),UABPde(k,"error"))}function La(g){p(g.src)?L(g,"load",Ka,!0):g.contentDocument?(Na(g.contentDocument),L(g,"load",Ma,!0)):wa(function(){g.contentDocument?Na(g.contentDocument):L(g,"load",Ma,!0)},0)}function Ma(g){try{var k=g.target;k.removeEventListener("load",
Ma,!0);p(k.src)?Ka(g):k.contentDocument&&(la(k.contentDocument),Na(k.contentDocument))}catch(q){}}function Na(g){function k(){var x=D(E,arguments);return ha()&&(x.orgnl_script=g.currentScript,la(x)),x}var q,r,w,D,E,N,O,X,ca,Y,R,oa,Wa,pa,za;g.adf_rewritten||(g.adf_rewritten="main",(q=b)!==g.defaultView&&(g.adf_rewritten="iframe",q=g.defaultView),y(g,"hiddenElement",function(x){ia(200,15,x)}),y(g,"anchor",function(x){A(x)}),g.querySelectorAll("script").forEach(function(x){la(x)}),r=b.Function.bind,
w=r.bind(r),D=function(x,F){return new (w(x,null).apply(null,F))},q.Image=(E=q.Image,k.prototype=E.prototype,k),N=q.XMLHttpRequest.prototype.open,q.XMLHttpRequest.prototype.open=function(){try{arguments[0]&&arguments[1]&&!/^\/[^\/]/.test(arguments[1])&&ta(this,"xhr",arguments[1])&&!this.adf_rewritten&&!this[Ea]&&(this.adf_xhrOpenArgs=arguments,this.adf_tagName="xhr",this.adf_req_headers=[])}finally{N.apply(this,arguments)}},O=q.XMLHttpRequest.prototype.setRequestHeader,q.XMLHttpRequest.prototype.setRequestHeader=
function(){try{"xhr"===this.adf_tagName&&!this.adf_rewritten&&!this[Ea]&&this.adf_req_headers instanceof q.Array&&ha()&&this.adf_req_headers.push(arguments)}finally{O.apply(this,arguments)}},X=q.XMLHttpRequest.prototype.send,q.XMLHttpRequest.prototype.send=function(){var x=this;try{if(!("xhr"!==x.adf_tagName||x.adf_rewritten||x[Ea]||x.hasOwnProperty("adf_body"))&&ha()){if(x.orgnl_error_hdlr=x.onerror,x.onerror=null,x.orgnl_readystatechange_hdlr=x.onreadystatechange,x.onreadystatechange=function(F){if(4===
x.readyState){if(/^[23]/.test(x.status))return F.adf_event_type="load",na(F),void("function"==typeof x.orgnl_readystatechange_hdlr&&x.orgnl_readystatechange_hdlr(F));F.adf_event_type="error";na(F)}else"function"==typeof x.orgnl_readystatechange_hdlr&&x.orgnl_readystatechange_hdlr(F)},x.adf_body=arguments[0],sa({type:"xhr",requestMethod:x.adf_xhrOpenArgs[0],url:x.adf_xhrOpenArgs[1]},"network"))return void Ta(null,x);la(x)}}catch(F){Ga(x)}finally{X.apply(x,arguments)}},ca=q.open,q.open=function(){var x;
try{var F=ha()&&lb?(x=Ia("recovery","popup",arguments[0]),ca.apply(q,[x])):ca.apply(q,arguments)}catch(da){F=ca.apply(q,arguments)}finally{return F}},Y=q.fetch,b.uabpFlags&&b.uabpFlags.fetchRecoveryOff||(q.fetch=function(){var x=arguments;try{var F="",da=!1,qa=(x&&x[0]&&("string"==typeof x[0]?F=x[0]:"string"==typeof x[0].url&&(da=!0,F=x[0].url)),{type:"xhr",requestMethod:x&&x[1]&&x[1].method?x[1].method:"GET",url:F});return ha()&&qa.url&&!ka(qa,"network",!1)?(qa.url=B(qa.url),G(qa.url)?new Promise(function(ob,
dc){function Qb(Rb){function xb(cb){Sb||Tb||(dc(cb),Tb=!0)}var Sb=!1,Tb=!1;try{Va.currentCount++;var yb=Ia("recovery","xhr",qa.url);if(!yb)return void xb(Rb);wa(function(){x[0]=da?new Request(yb,x[0]):yb;Y.apply(q,x).then(function(cb){Sb=!0;ob(cb)}).catch(xb)},0)}catch(cb){xb(Rb||cb)}}sa(qa,"network")?Qb():Y.apply(q,x).then(ob).catch(Qb)}):Y.apply(q,x)):Y.apply(q,x)}catch(ob){return Y.apply(q,x)}}),R=g.body&&g.body.appendChild,oa=q.Node.prototype.appendChild,R&&(g.body.appendChild=function(){var x=
R.apply(this,arguments);try{var F=arguments[0],da=F&&F.tagName&&F.tagName.toLowerCase();if(ta(F,da,F.src||F.href,this))switch(da){case "iframe":La(F);break;case "script":la(F)}}catch(qa){}return x}),q.Node.prototype.appendChild=function(){var x=oa.apply(this,arguments);try{var F=arguments[0],da=F&&F.tagName&&F.tagName.toLowerCase();if(ta(F,da="a"===da?"anchor":da,F.src||F.href,this))switch(da){case "iframe":La(F);break;case "anchor":A(F);break;case "script":la(F)}}catch(qa){}return x},Wa=q.Node.prototype.replaceChild,
q.Node.prototype.replaceChild=function(){var x=Wa.apply(this,arguments);try{var F=arguments[0]instanceof q.Element&&arguments[0].querySelector("IFRAME");F&&ta(F,"iframe",F.src,this)&&(/Firefox/.test(q.navigator.userAgent)?L(F,"load",Ma,!0):La(F))}catch(da){}return x},pa=q.Node.prototype.insertBefore,q.Node.prototype.insertBefore=function(){var x=pa.apply(this,arguments);try{var F=arguments[0],da=F&&F.tagName&&F.tagName.toLowerCase();ta(F,da,F.src||F.href,this)&&"script"===da&&la(F)}catch(qa){}return x},
la(g),za=g.createElement,g.createElement=function(){var x=za.apply(g,arguments);try{if(!ha())return x;var F=arguments[0]&&arguments[0].toLowerCase();switch(F){case "iframe":L(x,"load",Ka,!0);break;case "video":var da=x.appendChild;x.appendChild=function(){try{var qa=arguments[0].localName;if(!ta(x,F,x.src)||"source"!==qa)return da.apply(x,arguments);if(arguments[0].src&&!x.src)return x.src=arguments[0].src,null}catch(ob){}};L(x,"error",na,!0);L(x,"canplay",na,!0);break;case "img":x.orgnl_script=g.currentScript;
case "div":case "script":la(x)}}catch(qa){}return x})}function Ua(g,k){b.uabpRnd=g||kb();c=null;e=b.location.href;u={failedTests:[],successfulTests:[]};M=null;clearTimeout(wb);clearTimeout(Ub);Va={currentCount:0,cappingPerPI:2500,maxRecoveryDurationInMins:20};Z=[];Pa=[];db=[];mb=void 0===k?100<=J(100*(Ra()/2147483647)):k;Pb=lb=!1;pb="toBePrepared";eb=!(qb={});Ub=wa(function(){mb=!0},6E4*Va.maxRecoveryDurationInMins);(nb=nb&&vb&&!ec.test(e))&&l("","",{cssSelector:vb,currentTrafficTypes:["ADBLOCK"]})}
function ab(g,k){var q=d.querySelector(g.cssSelector);if(!q)return w="No tag container",void Ca("loadVideoTag",g.positionId,k,w);var r=Ja(g.positionId,g.cssSelector,g.currentTrafficTypes.join(","),!1),w=null,D=new XMLHttpRequest;D.onload=function(){var E;D.response&&"json"===D.responseType&&D.response.content?"// ad tag error"===D.response.content?w="Ad tag error":D.response.content==="// no banner for position "+g.positionId?w="No fill":(E=0===Pa.length?0:1E3,wa(function(){q.innerHTML="";l(D.response.adTagProvider,
D.response.adTagVersion,g,D.response.additionalAdTagProviders);var N=I("script");N.innerHTML=D.response.content;q.appendChild(N)},E)):w="Invalid response";Ca("loadVideoTag",g.positionId,k,w)};D.onerror=function(){w="Failed request";Ca("loadVideoTag",g.positionId,k,w)};D[Ea]=!0;D.responseType="json";D.open("GET",r,!0);D.send()}function Ca(g,k,q,r){q.postMessage({from:zb,to:fb,message:{type:g,value:{positionId:k,errorMsg:r}}},"*")}function C(g){var k=[];if(!Z)return k;for(var q=g.length,r=0;r<q;r++){for(var w=
!1,D=g[r].trafficTypes.length,E=0;E<D;E++){var N=g[r].trafficTypes[E];if(Z.includes(N))w=!0;else if(N.startsWith("!")&&Z.includes(N.substring(1))){w=!1;break}}w&&k.push(g[r].rule)}return k}function n(g,k){var q=qb[g+"_"+k];if(q)return q;var r=[];q=C(gb.generic[g][k]);q=(r=r.concat(q),Pa.length);for(var w=0;w<q;w++){var D,E=Pa[w].adTagProvider;E&&(D=Pa[w].adTagVersion,E=C(gb.specific[E][D][g][k]),r=r.concat(E))}return qb[g+"_"+k]=r}function l(g,k,q,r){if("string"==typeof g&&"string"==typeof k&&"object"==
typeof q){Z=q.currentTrafficTypes;function D(E,N){var O;(E=E.toLowerCase())&&gb.specific[E]?(O=gb.specific[E][N="v"+N],Pa.push({adTagProvider:E,adTagVersion:N})):O=gb.generic;O.dom.playerContainer.push(w)}q=q.cssSelector||"*";var w=(c=d.querySelector(q),{trafficTypes:Z,rule:{selector:q,toUnblock:!0}});g=(D(g,k),r?r.length:0);for(k=0;k<g;k++)D(r[k].adTagProvider,r[k].adTagVersion);qb={};ha()&&eb&&(ra(),eb=!1)}}if(!(b[m("ylghrVfulswLvDouhdg|H{hfxwhg",-3)]||-1<b.location.search.indexOf("forceVideoOff\x3dtrue"))){b[m("ylghrVfulswLvDouhdg|H{hfxwhg",
-3)]=!0;"function"==typeof activateUnblockingFor&&(activateUnblockingFor=l);b[m("XDESYuhordghg",-3)]=Ua;var c,e,u,M,wb,Va,Z,Pa,db,qb,mb,lb,Pb,pb,eb,Ub,bc="wbcNDTHOxE",gb={generic:{network:{script:[{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"t.cpdsrv.de/cpt.js",method:".*",toUnblock:!0}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"cdn.adswizz.com/adswizz/js/SynchroClient2.js",method:".*",toUnblock:!0}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"synchrobox.adswizz.com/register2.php",method:".*",
toUnblock:!0}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"imasdk.googleapis.com/js/sdkloader/",method:".*",toUnblock:!0}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"/integrator.js",method:".*",toUnblock:!0}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"/client.js",method:".*",toUnblock:!0}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"/vpaid.js",method:".*",toUnblock:!0}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"geo.moatads.com/n.js",method:".*",toUnblock:!0}},{trafficTypes:["ADBLOCK",
"PM"],rule:{urlRegExp:"cdn.doubleverify.com/dv-measurements",method:".*",toUnblock:!0}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"/vast.js",method:".*",toUnblock:!0}},{trafficTypes:["ADBLOCK"],rule:{urlRegExp:"/googima.js",method:".*",toUnblock:!0}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"secure-assets.rubiconproject.com.*usync.js",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"//ads.[^/]+/ads.[^/]+.js",method:".*",toUnblock:!0}}],image:[{trafficTypes:["ADBLOCK"],
rule:{urlRegExp:"servt.vid-play.com/track",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK"],rule:{urlRegExp:"prd.jwpltx.com",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK"],rule:{urlRegExp:"pp.lp4.io",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK"],rule:{urlRegExp:"meetrics.net/data",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK"],rule:{urlRegExp:"k.streamrail.com/x",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK"],rule:{urlRegExp:"m6r.eu/video/empty",method:".*",toUnblock:!1}},
{trafficTypes:["ADBLOCK"],rule:{urlRegExp:"brid.tv/ping.gif",method:".*",toUnblock:!1}},{trafficTypes:["PM"],rule:{urlRegExp:"/gen_204",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"aniview.com",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"id.rlcdn.com",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"youtube.com",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"googleadservices.com",method:".*",
toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"/auto-user-sync",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"rubiconproject.com.+sync.php",method:".*",toUnblock:!1}}],video:[],iframe:[{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"ad.yieldlab.net.+\\/2x2",method:".*",toUnblock:!1}},{trafficTypes:["!ADBLOCK","PM"],rule:{urlRegExp:".*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"smartadserver.com.+CookieSync.html",method:".*",
toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"rubiconproject.com.+multi-sync.html",method:".*",toUnblock:!1}}],xhr:[{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"adnxs.com.+\\/prebid",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"rtb.openx.net/openrtbb",method:"POST",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"adnxs.com.+v3$",method:"POST",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"360yield.com.+pb$",method:"POST",
toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"paper/public/js/ads/adex.js",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"doubleclick.net/pagead/ppub_config",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"rubiconproject.com/openrtb2/auction",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"_.rocks",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"pubads.g.doubleclick.net/gampad/ads.+output\x3dldjh",
method:"GET",toUnblock:!1}},{trafficTypes:["PM"],rule:{urlRegExp:"pubads.g.doubleclick.net/gampad/ads",method:"GET",toUnblock:!0}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"radio-api.net/.+/songs",method:".*",toUnblock:!1}}],css:[],all:[{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*rocks[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*emsservice[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*jwplayer[^/]*",
method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*ligatus[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*kameleoon[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*facebook[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*native.adscale.de[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*justpremium[^/]*",
method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*twitter.com[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*consensu[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*meetrics[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*daznplayer[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*api.rlcdn.com[^/]*",
method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*publisher-assets.spot.im[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"mdsngpush\\.",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*aniview.com[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*taboola.com[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*spot.im[^/]*",
method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*pub.doubleverify.com[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*ap.lijit.com[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*brwsrfrm.com[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*s.thebrighttag.com[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],
rule:{urlRegExp:"https?://[^/]*sync.richaudience.com[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*ssbsync-global.smartadserver.com[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*farm.plista.com[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*ssbsync.smartadserver.com[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*sync.search.spotxchange.com[^/]*",
method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*qvdt3feo.com[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*sync.extend.tv[^/]*",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*tr.outbrain.com[^/]*",method:".*",toUnblock:!1}}]},dom:{hiddenElement:[{trafficTypes:["ADBLOCK"],rule:{selector:".ad-element",toUnblock:!0}},{trafficTypes:["ADBLOCK"],rule:{selector:"#content_video_ima-ad-container",
toUnblock:!1}},{trafficTypes:["ADBLOCK"],rule:{selector:".fp-engine",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{selector:"header .wrapper + .text-white.bg-black.box-content",toUnblock:!1}}],blockedBackgroundImage:[{trafficTypes:["ADBLOCK"],rule:{selector:".GUI-module__container__thumbnail",toUnblock:!0}}],iframe:[],anchor:[],playerContainer:[]}},specific:{dn:{v1:{network:{script:[],image:[],video:[],iframe:[],xhr:[],css:[{trafficTypes:["ADBLOCK"],rule:{urlRegExp:"www.dianomi.com.*dianomi-context.css",
method:".*",toUnblock:!0}}],all:[]},dom:{hiddenElement:[],blockedBackgroundImage:[{trafficTypes:["ADBLOCK"],rule:{selector:".dianomi-video-background",toUnblock:!0}}],iframe:[],anchor:[{trafficTypes:["ADBLOCK"],rule:{selector:".dianomihref",toUnblock:!0}}],playerContainer:[]}}},tv:{v1:{network:{script:[{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"doubleclick.net/gampad/adx.+target-video",method:".*",toUnblock:!0}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"target-video.com/player/build/plugins/adunit.js",
method:".*",toUnblock:!0}}],image:[],video:[],iframe:[],xhr:[],css:[],all:[]},dom:{hiddenElement:[],blockedBackgroundImage:[],iframe:[],anchor:[],playerContainer:[]}}},vi:{v1:{network:{script:[{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"vi-serve.com",method:".*",toUnblock:!0}}],image:[{trafficTypes:["PM"],rule:{urlRegExp:"t.vi-serve.com",method:".*",toUnblock:!1}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"pixel.inforsea.com",method:".*",toUnblock:!1}}],video:[],iframe:[],xhr:[],css:[],all:[]},
dom:{hiddenElement:[],blockedBackgroundImage:[],iframe:[],anchor:[],playerContainer:[]}}},sh:{v2:{network:{script:[],image:[{trafficTypes:["ADBLOCK"],rule:{urlRegExp:"ib.adnxs.com/getuid",method:".*",toUnblock:!1}}],video:[],iframe:[],xhr:[],css:[],all:[{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*smartadserver.com[^/]*",method:".*",toUnblock:!0}},{trafficTypes:["ADBLOCK"],rule:{urlRegExp:"https?://[^/]*ads.stickyadstv.com[^/]*",method:".*",toUnblock:!0}},{trafficTypes:["ADBLOCK",
"PM"],rule:{urlRegExp:"https?://[^/]*ad.yieldlab.net[^/]*",method:".*",toUnblock:!0}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*rubiconproject.com[^/]*",method:".*",toUnblock:!0}}]},dom:{hiddenElement:[],blockedBackgroundImage:[],iframe:[],anchor:[],playerContainer:[]}},v3:{network:{script:[],image:[{trafficTypes:["ADBLOCK"],rule:{urlRegExp:"ib.adnxs.com/getuid",method:".*",toUnblock:!1}}],video:[],iframe:[],xhr:[],css:[],all:[{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*smartadserver.com[^/]*",
method:".*",toUnblock:!0}},{trafficTypes:["ADBLOCK"],rule:{urlRegExp:"https?://[^/]*ads.stickyadstv.com[^/]*",method:".*",toUnblock:!0}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*ad.yieldlab.net[^/]*",method:".*",toUnblock:!0}},{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"https?://[^/]*rubiconproject.com[^/]*",method:".*",toUnblock:!0}}]},dom:{hiddenElement:[],blockedBackgroundImage:[],iframe:[],anchor:[],playerContainer:[]}}},ip:{v1:{network:{script:[{trafficTypes:["ADBLOCK",
"PM"],rule:{urlRegExp:"\\.impactify\\..*/.*\\.js",method:".*",toUnblock:!0}}],image:[],video:[],iframe:[],xhr:[],css:[],all:[]},dom:{hiddenElement:[],blockedBackgroundImage:[],iframe:[],anchor:[],playerContainer:[{trafficTypes:["ADBLOCK","PM"],rule:{selector:".impactify-AM-player",toUnblock:!0}}]}}},vb:{v1:{network:{script:[],image:[],video:[],iframe:[],xhr:[{trafficTypes:["ADBLOCK","PM"],rule:{urlRegExp:"ads.smartstream.tv.+alternative\x3dprebid_js",method:".*",toUnblock:!0}}],css:[],all:[{trafficTypes:["ADBLOCK"],
rule:{urlRegExp:"https?://[^/]*\\.vlyby\\.com",method:".*",toUnblock:!0}}]},dom:{hiddenElement:[{trafficTypes:["ADBLOCK"],rule:{selector:"#qimad_0_ima-adf-container",toUnblock:!1}}],blockedBackgroundImage:[],iframe:[],anchor:[{trafficTypes:["ADBLOCK"],rule:{selector:"#adspdl-container \x3e a",toUnblock:!0}},{trafficTypes:["ADBLOCK"],rule:{selector:"#st-ad a.banner",toUnblock:!0}}],playerContainer:[{trafficTypes:["ADBLOCK","PM"],rule:{selector:"#videowrapper_0",toUnblock:!0}}]}}}}},Oa=b.location.protocol+
"//"+m("mxeelh1gh",-3),Nb=S("dW5pdGVkaW50ZXJuZXQ\x3d"),Ob=S("d2ViZGU\x3d"),nb=0,vb="",ec=RegExp("^(?!.*)","i"),fb="main",zb="video",Ea="UABP"+S("YWRmX2lnbm9yZQ\x3d\x3d"),fc=$a(),gc=RegExp("googlebot/|Googlebot-Mobile|Googlebot-Image|Google favicon|Mediapartners-Google|bingbot|slurp|java|wget|curl|Commons-HttpClient|Python-urllib|libwww|httpunit|nutch|phpcrawl|msnbot|jyxobot|FAST-WebCrawler|FAST Enterprise Crawler|biglotron|teoma|convera|seekbot|gigablast|exabot|ngbot|ia_archiver|GingerCrawler|webmon |httrack|webcrawler|grub.org|UsineNouvelleCrawler|antibot|netresearchserver|speedy|fluffy|bibnum.bnf|findlink|msrbot|panscient|yacybot|AISearchBot|IOI|ips-agent|tagoobot|MJ12bot|dotbot|woriobot|yanga|buzzbot|mlbot|yandexbot|purebot|Linguee Bot|Voyager|CyberPatrol|voilabot|baiduspider|citeseerxbot|spbot|twengabot|postrank|turnitinbot|scribdbot|page2rss|sitebot|linkdex|Adidxbot|blekkobot|ezooms|dotbot|Mail.RU_Bot|discobot|heritrix|findthatfile|europarchive.org|NerdByNature.Bot|sistrix crawler|ahrefsbot|Aboundex|domaincrawler|wbsearchbot|summify|ccbot|edisterbot|seznambot|ec2linkfinder|gslfbot|aihitbot|intelium_bot|facebookexternalhit|yeti|RetrevoPageAnalyzer|lb-spider|sogou|lssbot|careerbot|wotbox|wocbot|ichiro|DuckDuckBot|lssrocketcrawler|drupact|webcompanycrawler|acoonbot|openindexspider|gnam gnam spider|web-archive-net.com.bot|backlinkcrawler|coccoc|integromedb|content crawler spider|toplistbot|seokicks-robot|it2media-domain-crawler|ip-web-crawler.com|siteexplorer.info|elisabot|proximic|changedetection|blexbot|arabot|WeSEE:Search|niki-bot|CrystalSemanticsBot|rogerbot|360Spider|psbot|InterfaxScanBot|Lipperhey SEO Service|CC Metadata Scaper|g00g1e.net|GrapeshotCrawler|urlappendbot|brainobot|fr-crawler|binlar|SimpleCrawler|Livelapbot|Twitterbot|cXensebot|smtbot|bnf.fr_bot|A6-Indexer|ADmantX|Facebot|Twitterbot|OrangeBot|memorybot|AdvBot|MegaIndex|SemanticScholarBot|ltx71|nerdybot|xovibot|BUbiNG|Qwantify|archive.org_bot|Applebot|TweetmemeBot|crawler4j|findxbot|SemrushBot|yoozBot|lipperhey|y!j-asr|Domain Re-Animator Bot|AddThis|unknown|ysearch|web spider|Oberforstmeister|BingPreview|PhantomJS|misc crawler",
"i"),cc=f(Oa),Ba={consentString:"",gdprApplies:"1"};if(b.callNextAdTag=null,Ua(b.uabpRnd,mb),-1===b.location.search.indexOf("forceVideoOn\x3dtrue"))if(gc.test(fc)||100<=J(100*(Ra()/2147483647)))return;b.addEventListener("message",function(g){var k=g&&g.data;if(k&&k.to===zb){var q,r=g.source;g=k.message&&k.message.type;var w=k.message&&k.message.value;switch(g){case "noAdNoContent":if("iframeAgent"!==k.from)break;ib(w);break;case "loadVideoTag":if(k.from!==fb)break;switch(pb){case "toBePrepared":db.push({videoTagParameters:w,
caller:r});pb="preparing";g=Ja(null,null,w.currentTrafficTypes.join(","),!0);var D=null;(q=new XMLHttpRequest).onload=function(){if(q.response&&"json"===q.responseType)if("// ad tag error"===q.response.content)D="Ad tag error";else{var E;for(pb="prepared";0<db.length;)ab((E=db.shift()).videoTagParameters,E=E.caller)}else D="Invalid response";Ca("prepareVideoTags",w.positionId,r,D)};q.onerror=function(){D="Failed request";Ca("prepareVideoTags",w.positionId,r,D)};q[Ea]=!0;q.responseType="json";q.open("GET",
g,!0);q.send();break;case "preparing":db.push({videoTagParameters:w,caller:r});break;case "prepared":ab(w,r)}break;case "detection":if(k.from!==fb)break;Z=[];w.nc&&Z.push("NC");w.pm&&Z.push("PM");w.ab&&(Z.push("ADBLOCK"),c&&c.adf_hidden&&c.style.removeProperty("display"));0===Z.length&&Z.push("NONE");break;case "newImp":k.from===fb&&Ua(w)}}});b.top.postMessage({from:zb,to:fb,message:{type:"detection",value:"request"}},"*");(function(){try{var g=b.top.__tcfapi}catch(k){return}"function"==typeof g&&
g("addEventListener",2,function(k,q){q&&/tcloaded|useractioncomplete/.test(k.eventStatus)&&k.tcString!==Ba.consentString&&(Ba.consentString=k.tcString||Ba.consentString,Ba.gdprApplies=k.gdprApplies?"1":Ba.gdprApplies,eb=!0,ha()&&(ra(),eb=!1))})})();Na(d)}}(window,document);var tb=P("head"),ya=null;a.uabpdtc={};a.uabpdtc.pm=!1;a.uabpdtc.pmd=!1;if(/Firefox/.test($a())){function b(h,v,y){function A(G){for(var H="",T=0;T<G.length;T++)""!=H&&(H+=","),H+='"'+G[T]+'"';return H}var B=new XMLHttpRequest;B[S("YWRmX2lnbm9yZQ\x3d\x3d")]=
"PM";B.responseType="text";B.open("POST",y,!0);B.setRequestHeader("Content-Type","text/plain");B.onreadystatechange=function(){4===B.readyState&&(200===B.status?JSON.parse(B.responseText).privateMode&&(a.uabpnl=!0,a.uabpdtc.pm=!0):a.uabpnl=!1,a.uabpdtc.pmd=!0,Da())};B.send('{"failedRequests":['+A(h)+'],"successfulRequests":['+A(v)+"]}")}function d(h,v){for(var y=0;y<v.length;y++)if(v[y]===h)return y;return-1}function f(){function h(G,H){H.target&&(H=H.target.src||"",""!==H&&-1==H.indexOf("chrome-extension://")&&
(H=(new URL(H)).hostname||"",""!==H&&0>d(H,G)&&G.push(H)))}var v=[],y=[],A=h.bind(null,v),B=h.bind(null,y);L(document,"error",A,!0);L(document,"load",B,!0);a.uabPnwld={error:{events:v,listener:A},load:{events:y,listener:B}};(function(G){document.createElement=function(){var H=G.apply(this,arguments);L(H,"error",a.uabPnwld.error.listener,!0);L(H,"load",a.uabPnwld.load.listener,!0);return H}})(document.createElement)}function p(){function h(){for(var ia=0;ia<a.uabPnwld.load.events.length;ia++){var ma=
d(a.uabPnwld.load.events[ia],a.uabPnwld.error.events);-1<ma&&a.uabPnwld.error.events.splice(ma,1)}0<a.uabPnwld.error.events.length&&0<a.uabPnwld.load.events.length?b(a.uabPnwld.error.events,a.uabPnwld.load.events,m("22l31zhe1gh2lpdjh267924;689679\x3c/sg@4/i@whdvhu0{o2"+a.uabpRnd+"0gudj0jdq}h0exvfk0}dkq1eps",-3)):(a.uabpdtc.pmd=!0,Da())}var v=0,y=0,A=0,B=0,G=0,H=0,T=Fa(function(){A=a.uabPnwld.error.events.length;B=a.uabPnwld.load.events.length;v=A+B;10>=G?(0===v-y&&0<G&&H++,4<H&&(ua[T]=!1,h(),H=0)):
(ua[T]=!1,h());y=v;G++},500)}if(-1==$a().indexOf("Safari"))if(a.uabpFlags.networkListener){var Vb=!1;Object.keys(t).forEach(function(h){t.hasOwnProperty(h)&&h.match(/^uabp.{3}NLRun$/g)&&(Vb=t[h])});Vb?(a.uabpnl=!0,a.uabpdtc.pmd=!0,Da()):(a.uabpNLRun=!0,f(),p())}else a.uabpnl=!0,a.uabpdtc.pmd=!0,Da()}else a.uabpdtc.pmd=!0,Da();try{t.addEventListener?t.addEventListener(S("YWRuZGRuZC5pbml0"),Aa,!1):t.attachEvent&&t.attachEvent(S("YWRuZGRuZC5pbml0"),Aa),"complete"===W.readyState?Aa():(-1==$a().search("Firefox")&&
(W.addEventListener?W.addEventListener(S("RE9NQ29udGVudExvYWRlZA\x3d\x3d"),Aa,!1):W.attachEvent&&W.attachEvent("onreadystatechange",function(){"complete"===W.readyState&&Aa()})),t.addEventListener?t.addEventListener("load",Aa,!1):t.attachEvent&&t.attachEvent("onload",Aa))}catch(b){Aa()}}}catch(aa){}})(window,document);</script>

</body>
</html>
